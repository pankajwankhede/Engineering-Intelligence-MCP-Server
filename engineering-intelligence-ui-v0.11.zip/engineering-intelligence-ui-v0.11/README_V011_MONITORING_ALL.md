# v0.11 Monitoring All-Panels Update

- Panel dropdown defaults to **All** after dashboard selection.
- **All** loads every backend-configured panel and renders each as an independent monitoring card.
- Selecting a specific panel switches to a larger detailed table view.
- Actionable metrics remain clickable in both views.
- `INVESTIGATE` opens EIPA investigation mode; `DRILLDOWN` opens Logs.
- Time range defaults to **Last 15 minutes** and stays bounded.
- Refresh reloads the currently selected All/specific-panel view.
- No service, class, API, consumer, or metric values are hardcoded by this change; panel definitions and data remain backend-driven.
