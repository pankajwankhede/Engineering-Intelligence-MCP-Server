import type {
  InvestigationRequest, InvestigationResult, MonitoringDashboard,
  MonitoringDashboardDefinition, MonitoringDashboardSummary, MonitoringPanel,
  MonitoringRow, CodeFileInfo, CodeFileContent, ServiceChangeHistory,
  LogSearchResponse
} from '../types';

async function json<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const body = await response.text().catch(() => '');
    throw new Error(`Backend returned ${response.status}${body ? `: ${body}` : ''}`);
  }
  return response.json() as Promise<T>;
}

export async function startInvestigation(request: InvestigationRequest): Promise<InvestigationResult> {
  return json<InvestigationResult>(await fetch('/api/investigations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(request)
  }));
}

export async function getMonitoringDashboards(): Promise<MonitoringDashboardSummary[]> {
  return json<MonitoringDashboardSummary[]>(await fetch('/api/monitoring/dashboards'));
}

export async function getMonitoringDashboardDefinition(dashboardId: string): Promise<MonitoringDashboardDefinition> {
  return json<MonitoringDashboardDefinition>(await fetch(`/api/monitoring/dashboards/${encodeURIComponent(dashboardId)}/definition`));
}

export async function getMonitoringPanel(dashboardId: string, panelId: string, environment: string, timeRange: string): Promise<MonitoringPanel> {
  const params = new URLSearchParams({ environment, timeRange });
  return json<MonitoringPanel>(await fetch(`/api/monitoring/dashboards/${encodeURIComponent(dashboardId)}/panels/${encodeURIComponent(panelId)}?${params}`));
}

export async function getMonitoringDashboard(dashboardId: string, environment: string, timeRange: string): Promise<MonitoringDashboard> {
  const params = new URLSearchParams({ environment, timeRange });
  return json<MonitoringDashboard>(await fetch(`/api/monitoring/dashboards/${encodeURIComponent(dashboardId)}?${params}`));
}


export async function getMonitoringPanels(dashboardId: string, environment: string, timeRange: string): Promise<MonitoringDashboard> {
  const params = new URLSearchParams({ environment, timeRange });
  return json<MonitoringDashboard>(await fetch(`/api/monitoring/dashboards/${encodeURIComponent(dashboardId)}/panels?${params}`));
}

export async function investigateMonitoringMetric(input: {
  dashboardId: string;
  panelId: string;
  row: MonitoringRow;
  environment: string;
  timeRange: string;
}): Promise<InvestigationResult> {
  return json<InvestigationResult>(await fetch('/api/monitoring/investigate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      dashboardId: input.dashboardId,
      panelId: input.panelId,
      metricLabel: input.row.label,
      investigationCategory: input.row.investigationCategory,
      environment: input.environment,
      timeRange: input.timeRange
    })
  }));
}

export async function getCodeFiles(service: string): Promise<CodeFileInfo[]> {
  return json<CodeFileInfo[]>(await fetch(`/api/code/services/${encodeURIComponent(service)}/files`));
}

export async function getCodeFile(service: string, path: string, highlightedLine?: number): Promise<CodeFileContent> {
  const params = new URLSearchParams({ path });
  if (highlightedLine) params.set('highlightedLine', String(highlightedLine));
  return json<CodeFileContent>(await fetch(`/api/code/services/${encodeURIComponent(service)}/file?${params}`));
}

export async function getServiceChangeHistory(service: string, limit = 10): Promise<ServiceChangeHistory> {
  return json<ServiceChangeHistory>(await fetch(`/api/changes/services/${encodeURIComponent(service)}?limit=${limit}`));
}

export async function searchRelatedLogs(input: {
  services: string[];
  service?: string;
  level?: string;
  query?: string;
  timeRange?: string;
  trackingId?: string;
  requestId?: string;
}): Promise<LogSearchResponse> {
  const params = new URLSearchParams();
  input.services.forEach(s => params.append('services', s));
  if (input.service) params.set('service', input.service);
  if (input.level) params.set('level', input.level);
  if (input.query) params.set('query', input.query);
  if (input.timeRange) params.set('timeRange', input.timeRange);
  if (input.trackingId) params.set('trackingId', input.trackingId);
  if (input.requestId) params.set('requestId', input.requestId);
  return json<LogSearchResponse>(await fetch(`/api/logs/search?${params}`));
}
