import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Badge, Card } from '../../components/Ui';
import {
  getMonitoringPanels,
  getMonitoringDashboardDefinition,
  getMonitoringDashboards,
  getMonitoringPanel,
  investigateMonitoringMetric
} from '../../services/api';
import { useInvestigation } from '../../state';
import type {
  MonitoringDashboard,
  MonitoringDashboardDefinition,
  MonitoringDashboardSummary,
  MonitoringPanel,
  MonitoringRow
} from '../../types';

const ALL_PANELS = 'ALL';

function tone(severity: string): 'red' | 'orange' | 'green' | 'blue' | 'purple' {
  const value = (severity || '').toUpperCase();
  if (value === 'CRITICAL') return 'red';
  if (value === 'HIGH' || value === 'WARNING') return 'orange';
  if (value === 'INFO') return 'blue';
  return 'green';
}

function MonitoringPanelCard({
  panel,
  compact,
  onSelect
}: {
  panel: MonitoringPanel;
  compact: boolean;
  onSelect: (panel: MonitoringPanel, row: MonitoringRow) => void;
}) {
  return <Card title={panel.title} className={compact ? 'monitor-panel' : 'monitor-panel selected-monitor-panel'}>
    {panel.description && <div className="panel-description">{panel.description}</div>}
    <div className="query-ref">Query ref: <code>{panel.queryReference}</code></div>
    <table className="monitor-table">
      <thead><tr><th>#</th><th>Metric</th><th>Count</th><th>Action</th></tr></thead>
      <tbody>
        {panel.rows.map((row, idx) => {
          const actionable = row.count > 0 && (row.action === 'INVESTIGATE' || row.action === 'DRILLDOWN');
          return <tr
            key={`${panel.panelId}-${row.label}-${idx}`}
            className={actionable ? 'clickable-failure' : ''}
            onClick={() => actionable && onSelect(panel, row)}
          >
            <td>{idx + 1}</td>
            <td>{row.label}</td>
            <td><b>{row.count}</b></td>
            <td><Badge tone={tone(row.severity)}>{row.action}</Badge></td>
          </tr>;
        })}
      </tbody>
    </table>
  </Card>;
}

export function MonitoringPage() {
  const [environment, setEnvironment] = useState('');
  const [timeRange, setTimeRange] = useState('15m');
  const [dashboards, setDashboards] = useState<MonitoringDashboardSummary[]>([]);
  const [dashboardId, setDashboardId] = useState('');
  const [dashboard, setDashboard] = useState<MonitoringDashboardDefinition | null>(null);
  const [dashboardData, setDashboardData] = useState<MonitoringDashboard | null>(null);
  const [selectedPanel, setSelectedPanel] = useState<MonitoringPanel | null>(null);
  const [panelId, setPanelId] = useState(ALL_PANELS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<{panel: MonitoringPanel; row: MonitoringRow} | null>(null);
  const [investigating, setInvestigating] = useState(false);
  const [refreshVersion, setRefreshVersion] = useState(0);
  const { setResult } = useInvestigation();
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    setError('');
    getMonitoringDashboards()
      .then(items => {
        setDashboards(items);
        setDashboardId(items[0]?.dashboardId || '');
      })
      .catch(e => setError(e instanceof Error ? e.message : 'Unable to load monitoring dashboards'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!dashboardId) {
      setDashboard(null);
      setDashboardData(null);
      setSelectedPanel(null);
      setPanelId(ALL_PANELS);
      return;
    }
    setLoading(true);
    setError('');
    getMonitoringDashboardDefinition(dashboardId)
      .then(next => {
        setDashboard(next);
        setPanelId(ALL_PANELS);
        setSelectedPanel(null);
      })
      .catch(e => setError(e instanceof Error ? e.message : 'Unable to load dashboard definition'))
      .finally(() => setLoading(false));
  }, [dashboardId]);

  useEffect(() => {
    if (!dashboardId) return;
    setLoading(true);
    setError('');

    if (panelId === ALL_PANELS) {
      setSelectedPanel(null);
      getMonitoringPanels(dashboardId, environment, timeRange)
        .then(setDashboardData)
        .catch(e => {
          setDashboardData(null);
          setError(e instanceof Error ? e.message : 'Unable to load monitoring dashboard');
        })
        .finally(() => setLoading(false));
      return;
    }

    setDashboardData(null);
    getMonitoringPanel(dashboardId, panelId, environment, timeRange)
      .then(setSelectedPanel)
      .catch(e => {
        setSelectedPanel(null);
        setError(e instanceof Error ? e.message : 'Unable to load monitoring panel');
      })
      .finally(() => setLoading(false));
  }, [dashboardId, panelId, environment, timeRange, refreshVersion]);

  const displayedPanels = useMemo(() => {
    if (panelId === ALL_PANELS) return dashboardData?.panels || [];
    return selectedPanel ? [selectedPanel] : [];
  }, [panelId, dashboardData, selectedPanel]);

  const summary = useMemo(() => {
    const rows = displayedPanels.flatMap(panel => panel.rows || []);
    const actionableRows = rows.filter(row => row.count > 0 && (row.action === 'INVESTIGATE' || row.action === 'DRILLDOWN'));
    return {
      panels: dashboard?.panels.length || 0,
      visiblePanels: displayedPanels.length,
      metrics: rows.length,
      actionable: actionableRows.length,
      totalEvents: actionableRows.reduce((sum, row) => sum + row.count, 0)
    };
  }, [dashboard, displayedPanels]);

  const investigate = async () => {
    if (!dashboard || !selected) return;
    setInvestigating(true);
    setError('');
    try {
      const result = await investigateMonitoringMetric({
        dashboardId: dashboard.dashboardId,
        panelId: selected.panel.panelId,
        row: selected.row,
        environment,
        timeRange
      });
      setResult(result);
      setSelected(null);
      navigate('/overview');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to start investigation');
    } finally {
      setInvestigating(false);
    }
  };

  return <div className="page monitoring-page">
    <div className="page-heading">
      <div>
        <h1>Monitoring <span className="breadcrumb">{dashboard?.title ? `/ ${dashboard.title}` : ''}</span></h1>
        <p>Dashboard panels and metrics come from backend configuration and Splunk results. Select All to view every configured panel.</p>
      </div>
      <button disabled={!dashboardId || loading} onClick={() => setRefreshVersion(v => v + 1)}>↻ Refresh</button>
    </div>

    <Card className="monitor-filter-card">
      <div className="monitor-selector-grid">
        <label className="field">
          <span>Dashboard</span>
          <select value={dashboardId} onChange={e => setDashboardId(e.target.value)} disabled={!dashboards.length}>
            <option value="">Select dashboard</option>
            {dashboards.map(item => <option key={item.dashboardId} value={item.dashboardId}>{item.title}</option>)}
          </select>
        </label>

        <label className="field">
          <span>Panel</span>
          <select value={panelId} onChange={e => setPanelId(e.target.value)} disabled={!dashboard?.panels?.length}>
            <option value={ALL_PANELS}>All</option>
            {dashboard?.panels?.map(panel => <option key={panel.panelId} value={panel.panelId}>{panel.title}</option>)}
          </select>
        </label>

        <label className="field">
          <span>Environment</span>
          <input value={environment} onChange={e => setEnvironment(e.target.value)} placeholder="Optional, e.g. PRODUCTION" />
        </label>

        <label className="field">
          <span>Time Range</span>
          <select value={timeRange} onChange={e => setTimeRange(e.target.value)}>
            <option value="15m">Last 15 minutes</option>
            <option value="30m">Last 30 minutes</option>
            <option value="1h">Last 1 hour</option>
            <option value="2h">Last 2 hours</option>
            <option value="6h">Last 6 hours</option>
            <option value="24h">Last 24 hours</option>
          </select>
        </label>
      </div>
    </Card>

    {error && <div className="error-banner">{error}</div>}

    <div className="metrics-grid four monitoring-summary">
      <Card><div className="metric-label">Available Panels</div><div className="metric-value">{summary.panels}</div></Card>
      <Card><div className="metric-label">Visible Panels</div><div className="metric-value">{summary.visiblePanels}</div></Card>
      <Card><div className="metric-label">Visible Metrics</div><div className="metric-value">{summary.metrics}</div></Card>
      <Card className="tone-red"><div className="metric-label">Actionable Events</div><div className="metric-value">{summary.totalEvents}</div></Card>
    </div>

    {loading ? <Card><div className="empty">Loading monitoring data…</div></Card> :
      displayedPanels.length ? (
        panelId === ALL_PANELS
          ? <div className="monitor-panel-grid all-panels-grid">
              {displayedPanels.map(panel => <MonitoringPanelCard key={panel.panelId} panel={panel} compact={true} onSelect={(p, row) => setSelected({panel: p, row})} />)}
            </div>
          : <MonitoringPanelCard panel={displayedPanels[0]} compact={false} onSelect={(p, row) => setSelected({panel: p, row})} />
      ) : <Card><div className="empty">No monitoring data returned for the selected filters.</div></Card>}

    {selected && <div className="investigation-overlay" onClick={() => !investigating && setSelected(null)}>
      <aside className="investigation-drawer" onClick={e => e.stopPropagation()}>
        <button className="drawer-close" onClick={() => setSelected(null)}>×</button>
        <div className="drawer-kicker">Investigation Mode</div>
        <h2>{selected.row.label}</h2>
        <Badge tone={tone(selected.row.severity)}>{selected.row.severity}</Badge>
        <dl className="drawer-details">
          <dt>Count</dt><dd>{selected.row.count}</dd>
          <dt>Dashboard</dt><dd>{dashboard?.title || dashboardId}</dd>
          <dt>Panel</dt><dd>{selected.panel.title}</dd>
          <dt>Environment</dt><dd>{environment || dashboardData?.environment || 'Backend default'}</dd>
          <dt>Time Range</dt><dd>{timeRange || dashboardData?.timeRange || 'Backend default'}</dd>
          <dt>Category</dt><dd>{selected.row.investigationCategory || 'General'}</dd>
        </dl>
        {selected.row.action === 'INVESTIGATE'
          ? <button className="primary-button drawer-action" onClick={investigate} disabled={investigating}>{investigating ? 'Investigating…' : 'Investigate with EIPA →'}</button>
          : <button className="primary-button drawer-action" onClick={() => { setSelected(null); navigate('/logs'); }}>Open Drilldown →</button>}
      </aside>
    </div>}
  </div>;
}
