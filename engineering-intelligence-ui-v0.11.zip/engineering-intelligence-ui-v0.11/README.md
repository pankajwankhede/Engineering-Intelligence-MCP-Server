# Engineering Intelligence UI v0.8

React + Vite + TypeScript UI for Monitoring and EIPA Production Investigation.

## Fully dynamic UI

The React source contains no service-specific investigation data. It does not hardcode service names, repositories, class names, methods, API endpoints, consumers, commit IDs, tracking IDs, root causes, or log events.

All operational content is loaded from the backend:

- Monitoring dashboards/panels/metrics → `/api/monitoring/...`
- Investigation result/service flow → `/api/investigations`
- Correlated logs → `/api/logs/search`
- Repository file list → `/api/code/services/{service}/files`
- Selected source file → `/api/code/services/{service}/file`
- Last commits and pull requests → `/api/changes/services/{service}`

If the backend is unavailable, the UI displays an error or empty state. It does **not** fabricate a demo investigation.

The last real investigation response is cached in `sessionStorage` so page navigation/refresh does not lose the result.

## Run

```bash
npm install
npm run dev
```

Vite proxies `/api` to `http://localhost:8080` by default; change `vite.config.ts` for another backend URL.
