export type Page =
  | 'overview' | 'start' | 'serviceFlow' | 'serviceDetail' | 'logs' | 'callFlow' | 'api'
  | 'monitoring'
  | 'splunkExisting' | 'splunkPanelDetail' | 'splunkFailures' | 'splunkInvestigation'
  | 'newRelic' | 'newRelicTransactions' | 'newRelicErrors'
  | 'jvm' | 'jvmThreads' | 'jvmGc'
  | 'pcfOverview' | 'pcfInstances' | 'pcfInstanceDetail' | 'pcfEvents'
  | 'database' | 'databaseQueryDetail'
  | 'code' | 'codeFileDetail'
  | 'changes' | 'changeDetail' | 'blastRadius' | 'timeline' | 'recommendations' | 'rcaSummary' | 'similarIncidents'
  | 'reports' | 'integrations' | 'settings'

export const pageTitle = (page: Page) => ({
  overview:'Investigation Overview', start:'Start Investigation', serviceFlow:'Service Flow', serviceDetail:'Service Details',
  logs:'Logs & Trace', callFlow:'Call Flow', api:'API & Consumers', monitoring:'Monitoring Overview',
  splunkExisting:'Existing Splunk Dashboard', splunkPanelDetail:'Splunk Panel Details', splunkFailures:'Splunk Failure Investigation', splunkInvestigation:'Splunk Investigation Analysis',
  newRelic:'New Relic APM Overview', newRelicTransactions:'New Relic Transactions', newRelicErrors:'New Relic Errors',
  jvm:'JVM / Application Health', jvmThreads:'JVM Threads', jvmGc:'JVM Memory & GC',
  pcfOverview:'PCF / Tanzu Runtime Overview', pcfInstances:'PCF Instances', pcfInstanceDetail:'PCF Instance Details', pcfEvents:'PCF Events & Deployments',
  database:'Database Analysis', databaseQueryDetail:'Database Query Details', code:'Code Analysis', codeFileDetail:'Code File Details',
  changes:'Recent Changes', changeDetail:'Change Details', blastRadius:'Blast Radius', timeline:'Evidence Timeline', recommendations:'Recommendations', rcaSummary:'RCA Summary', similarIncidents:'Similar Incidents',
  reports:'Reports', integrations:'Integrations', settings:'Settings'
})[page]
