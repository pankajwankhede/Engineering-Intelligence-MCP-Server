import { AlertTriangle, Box, Clock3, ShieldAlert } from 'lucide-react'
import type { InvestigationResult } from '../types'
export default function InvestigationContext({investigation}:{investigation:InvestigationResult|null}){
 if(!investigation)return null
 const u=investigation.understanding
 return <div className="incident-context">
  <div className="incident-main"><AlertTriangle size={18}/><div><span>ACTIVE INVESTIGATION</span><strong>{u.service}</strong></div></div>
  <div className="context-item"><ShieldAlert size={15}/><div><span>Issue</span><b>{u.exception||investigation.rootCause.title}</b></div></div>
  <div className="context-item"><Box size={15}/><div><span>Environment</span><b>{u.environment}</b></div></div>
  <div className="context-item"><Clock3 size={15}/><div><span>Window</span><b>{u.timeRange}</b></div></div>
  <div className="severity critical">CRITICAL · {investigation.impact.failedRequestPercent}% failures</div>
 </div>
}
