import {GitCommit, Search, ShieldAlert} from 'lucide-react'
import type {CodeAnalysis,InvestigationResult} from '../types'
import type {Page} from '../navigation'
import {Action,Card,Metric,StatusPill} from '../components/ui'

export default function CodeAnalysisPage({investigation,data,onNavigate}:{investigation:InvestigationResult|null;data:CodeAnalysis|null;onNavigate:(p:Page)=>void}){
  if(!data)return <div className="empty"/>
  const fileName=data.selectedFile.split('/').pop()||data.selectedFile
  return <div className="page code-analysis-rich">
    <div className="page-heading">
      <div>
        <h1>Code Analysis – Overview</h1>
        <p>{data.service} · investigation {investigation?.investigationId??'—'}</p>
      </div>
      <div className="card-footer">
        <Action secondary onClick={()=>onNavigate('changes')}>View Recent Changes</Action>
        <Action onClick={()=>onNavigate('codeFileDetail')}>View File Details</Action>
      </div>
    </div>

    <div className="code-toolbar">
      <label>Service<select value={data.service} disabled><option>{data.service}</option></select></label>
      <label>Repository<select value={data.repository} disabled><option>{data.repository}</option></select></label>
      <label>Branch<select value={data.branch} disabled><option>{data.branch}</option></select></label>
      <label>File<select value={data.selectedFile} disabled><option>{fileName}</option></select></label>
      <span className="filter-chip">{data.language}</span>
      <StatusPill value={data.severity}/>
    </div>

    <div className="code-layout code-layout-rich">
      <aside className="file-pane">
        <div className="code-search"><Search size={13}/><span>Search files…</span></div>
        <strong>File Explorer</strong>
        <div className="file-tree rich-tree">
          {data.fileTree.map(path=>{
            const selected=path===data.selectedFile
            return <button key={path} className={selected?'selected-file':''} onClick={()=>selected&&onNavigate('codeFileDetail')} title={path}>
              <span>{path.split('/').pop()}</span><small>{path}</small>
            </button>
          })}
        </div>
        <div className="file-meta">
          <span>Package</span><b>{data.packageName}</b>
          <span>Owner</span><b>{data.owner}</b>
          <span>Last modified</span><b>{data.lastModified}</b>
        </div>
      </aside>

      <section className="code-pane">
        <div className="code-head"><span>{data.selectedFile}</span><span>Issue line {data.line}</span></div>
        <pre>{data.snippet.map((line,index)=><div key={`${index}-${line}`} className={line.trimStart().startsWith(String(data.line))?'bad-line':''}>{line}</div>)}</pre>
        <div className="code-bottom-tabs"><button className="active">Issues (2)</button><button onClick={()=>onNavigate('changes')}>Recent Changes ({data.commits.length})</button><button onClick={()=>onNavigate('splunkInvestigation')}>Related Logs</button></div>
      </section>

      <aside className="analysis-pane">
        <div className="row-between"><span className="issue-pill"><ShieldAlert size={12}/> Issue Detected</span><StatusPill value={data.severity}/></div>
        <h2>{data.issueType}</h2>
        <p>{data.finding}</p>
        <dl>
          <dt>Class</dt><dd>{data.className}</dd>
          <dt>Method</dt><dd>{data.methodName}</dd>
          <dt>Line</dt><dd>{data.line}</dd>
          <dt>Category</dt><dd>{data.issueCategory}</dd>
        </dl>
        <Metric label="Confidence" value={`${data.confidence}%`}/>
        <h3>Related Evidence</h3>
        <div className="code-evidence">{data.relatedEvidence.map(e=><button key={e.source} onClick={()=>e.source==='Splunk'?onNavigate('splunkInvestigation'):e.source==='Recent Change'?onNavigate('changes'):onNavigate('newRelic')}><b>{e.source}</b><span>{e.summary}</span><em>{e.status}</em></button>)}</div>
      </aside>
    </div>

    <div className="grid2 code-lower-grid">
      <Card title="Recent Changes">
        {data.commits.map(c=><button className="commit rich-commit" key={c.id} onClick={()=>onNavigate('changes')}><GitCommit size={14}/><code>{c.id}</code><span>{c.message}<small>{c.author} · {c.time}</small></span><em>View →</em></button>)}
        <div className="card-footer"><Action secondary onClick={()=>onNavigate('changes')}>View All Changes</Action></div>
      </Card>
      <Card title="Investigation Actions">
        <p>Every action opens a real internal drill-down page and preserves the current investigation/service context.</p>
        <div className="stack-actions">
          <Action onClick={()=>onNavigate('codeFileDetail')}>View Full File</Action>
          <Action secondary onClick={()=>onNavigate('splunkInvestigation')}>Correlate with Splunk</Action>
          <Action secondary onClick={()=>onNavigate('newRelic')}>Correlate with New Relic</Action>
          <Action secondary onClick={()=>onNavigate('rcaSummary')}>Open RCA Summary</Action>
        </div>
      </Card>
    </div>
  </div>
}
