import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function EvidenceTimelinePage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Evidence Timeline"><ul className="generic-list"><li>10:23:10 First error detected</li><li>10:23:15 New Relic error rate increased</li><li>10:24:08 PCF instance restarted</li><li>10:24:15 Root cause candidate generated</li></ul></Card></div>}
