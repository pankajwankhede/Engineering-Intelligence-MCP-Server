import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function BlastRadiusPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Blast Radius"><ul className="generic-list"><li>bc-login-service: high impact</li><li>customer-profile-service: medium impact</li><li>3 consumers and ~12,800 users potentially affected</li></ul></Card></div>}
