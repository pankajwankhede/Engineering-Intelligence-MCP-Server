import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function LogsTracePage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Logs & Trace"><ul className="generic-list"><li>45 ERROR events matched NullPointerException</li><li>Tracking ID correlation across bc-login-service and downstream services</li><li>Splunk search results are normalized by backend connector</li></ul></Card></div>}
