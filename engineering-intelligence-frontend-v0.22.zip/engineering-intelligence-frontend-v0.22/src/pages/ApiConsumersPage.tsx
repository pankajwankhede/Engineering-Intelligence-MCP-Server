import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function ApiConsumersPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="API & Consumers"><ul className="generic-list"><li>3 downstream consumers impacted</li><li>Failed request percentage: 25.4%</li><li>Consumer mapping from service catalog and distributed traces</li></ul></Card></div>}
