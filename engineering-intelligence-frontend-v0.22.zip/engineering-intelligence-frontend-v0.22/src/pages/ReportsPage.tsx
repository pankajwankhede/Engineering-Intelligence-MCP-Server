import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function ReportsPage({investigation}:{investigation:InvestigationResult|null}){return <div className="page"><Card title="Reports"><ul className="generic-list"><li>Executive RCA summary</li><li>Technical evidence report</li><li>Export-ready incident timeline</li></ul></Card></div>}
