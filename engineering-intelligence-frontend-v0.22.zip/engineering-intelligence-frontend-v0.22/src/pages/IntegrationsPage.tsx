import { Card } from '../components/ui'
import type { IntegrationItem } from '../types'
export default function IntegrationsPage({data}:{data:IntegrationItem[]}){return <div className="page"><div className="integration-grid">{data.map(x=><Card key={x.key} title={x.name}><div className="integration"><span>{x.category}</span><b className={`pill ${x.status.toLowerCase()}`}>{x.status}</b><p>{x.details}</p></div></Card>)}</div></div>}
