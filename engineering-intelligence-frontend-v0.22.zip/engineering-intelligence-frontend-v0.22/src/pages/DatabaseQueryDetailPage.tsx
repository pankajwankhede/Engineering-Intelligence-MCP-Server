import {useState} from 'react'
import type {DatabaseAnalysis} from '../types'
import type {Page} from '../navigation'
import {Action,Card,Metric} from '../components/ui'

export default function DatabaseQueryDetailPage({data,queryId,onNavigate}:{data:DatabaseAnalysis|null;queryId?:string;onNavigate:(p:Page)=>void}){
  const [showPlan,setShowPlan]=useState(false)
  const q=data?.longRunningQueries.find(x=>x.sqlId===queryId)||data?.longRunningQueries[0]
  if(!data||!q)return <div className="empty"/>
  return <div className="page">
    <div className="page-heading"><div><h1>Database Query Details</h1><p>{data.database} · {data.schema} · read-only diagnostics</p></div><Action secondary onClick={()=>onNavigate('database')}>Back</Action></div>
    <div className="summary-strip"><Metric label="Query ID" value={q.sqlId}/><Metric label="Duration" value={q.duration} tone="bad"/><Metric label="Avg Time" value={`${q.avgMs??0} ms`}/><Metric label="Rows" value={String(q.rows??'-')}/></div>
    <Card title="SQL"><pre className="spl-box">{q.sql||'SQL text supplied by backend / DB MCP'}</pre></Card>
    <div className="grid2">
      <Card title="Execution Plan"><p>Production diagnostics stay read-only. The live connector should return EXPLAIN/plan output without executing write operations.</p><Action secondary onClick={()=>setShowPlan(v=>!v)}>{showPlan?'Hide Execution Plan':'View Execution Plan'}</Action>{showPlan&&<pre className="spl-box">SELECT STATEMENT\n  TABLE ACCESS BY INDEX ROWID CUSTOMER_PROFILE\n    INDEX RANGE SCAN IDX_CUSTOMER_PROFILE_CUSTOMER_ID</pre>}</Card>
      <Card title="Investigation"><p>Correlate this query with request/trace IDs, service latency and recent changes.</p><Action onClick={()=>onNavigate('splunkInvestigation')}>Investigate Slow Query</Action></Card>
    </div>
  </div>
}
