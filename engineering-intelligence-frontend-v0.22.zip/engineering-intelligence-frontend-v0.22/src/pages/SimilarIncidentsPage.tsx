import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function SimilarIncidentsPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Similar Incidents"><ul className="generic-list"><li>INC-18421 — Null profile during login — 92% similarity</li><li>INC-17318 — Customer profile lookup timeout — 74% similarity</li><li>INC-16902 — Missing profile row after migration — 68% similarity</li></ul></Card></div>}
