import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function CallFlowPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Call Flow"><ul className="generic-list"><li>Browser → API Gateway → bc-login-service</li><li>bc-login-service → customer-profile-service</li><li>customer-profile-service → Oracle CUSTOMER_PROFILE</li></ul></Card></div>}
