import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function SettingsPage({investigation}:{investigation:InvestigationResult|null}){return <div className="page"><Card title="Settings"><ul className="generic-list"><li>Demo mode controlled by VITE_DEMO_MODE</li><li>Backend URL controlled by VITE_API_BASE_URL</li><li>Connector credentials stay in backend / Vault, never in React</li></ul></Card></div>}
