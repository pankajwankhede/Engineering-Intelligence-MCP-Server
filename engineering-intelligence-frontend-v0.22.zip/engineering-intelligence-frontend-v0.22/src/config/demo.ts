const rawDemoMode = import.meta.env.VITE_DEMO_MODE ?? 'true'

export const DEMO_CONFIG = {
  enabled: rawDemoMode.toLowerCase() === 'true',
  delayMs: 450,
  showModeBadge: true,
  backendBaseUrl: import.meta.env.VITE_API_BASE_URL || '',
} as const

export const isDemoMode = () => DEMO_CONFIG.enabled
