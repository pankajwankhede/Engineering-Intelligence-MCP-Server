# Apply Filters behavior (v0.21)

## Fixed behavior

Dropdown changes are draft values only. They do not execute backend calls.

Clicking **Apply Filters** now explicitly refreshes the currently displayed page.

- Existing Splunk Dashboard: reloads the selected dashboard definition and every configured panel with `service`, `environment`, and `timeRange`.
- Splunk Investigation: refreshes Splunk investigation analysis.
- New Relic pages: refresh New Relic analysis.
- JVM pages: refresh JVM analysis.
- PCF/Tanzu pages: refresh PCF analysis.
- Database pages: refresh database analysis using selected database type.
- Code/Changes pages: refresh code analysis.
- Monitoring Overview: refreshes the related observability sources.
- Other investigation pages: refresh the aggregate investigation data.

## Existing Splunk Dashboard

Changing Dashboard / Service / Environment / Time does nothing until a button is clicked.

- **Load Dashboard** uses the values in the Splunk page toolbar.
- **Apply Filters** uses the global header values and reloads the currently selected Splunk dashboard.

In live mode this causes calls to:

`GET /api/v1/monitoring/dashboards/{dashboardId}`

and for each panel:

`GET /api/v1/monitoring/dashboards/{dashboardId}/panels/{panelId}?service=...&environment=...&timeRange=...`

## Demo mode

When `VITE_DEMO_MODE=true`, the same click path executes but data is generated locally, so there is no browser XHR request to Spring Boot. The page still refreshes using the selected filters.

For Network-tab verification use:

```env
VITE_DEMO_MODE=false
VITE_API_BASE_URL=http://localhost:8080
```
