# Pre-Investigation Apply Filters — v0.22

## Problem fixed
Earlier versions returned early when `investigation == null`. As a result, clicking **Apply Filters** on a page showing **No investigation loaded** produced no backend request.

## v0.22 behavior
Dropdown changes are local only. A backend request is sent only when the user clicks **Apply Filters**.

When no investigation exists, the UI calls operational APIs that do not require an investigation ID:

- `GET /api/v1/operational/monitoring`
- `GET /api/v1/operational/runtime`
- `GET /api/v1/operational/splunk`
- `GET /api/v1/operational/new-relic`
- `GET /api/v1/operational/jvm`
- `GET /api/v1/operational/pcf`
- `GET /api/v1/operational/database`
- `GET /api/v1/operational/code`
- `GET /api/v1/operational/services`

Common query parameters are `service`, `environment`, and `timeRange`. Database also receives `databaseType`.

After an investigation is started, the existing `/api/v1/investigations/{id}/...` endpoints are used for correlated RCA data.

## Important demo/live note
With `VITE_DEMO_MODE=true`, the API layer intentionally returns local demo data, so the browser Network tab will not show these XHR calls. To verify real network calls use:

```env
VITE_DEMO_MODE=false
VITE_API_BASE_URL=http://localhost:8080
```

Then restart Vite.
