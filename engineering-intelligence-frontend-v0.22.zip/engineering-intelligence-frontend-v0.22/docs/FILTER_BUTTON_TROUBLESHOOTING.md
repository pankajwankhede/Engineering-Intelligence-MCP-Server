# Apply Filters / Load Dashboard behavior

## Important: DEMO versus LIVE

When `VITE_DEMO_MODE=true`, `platformApi.ts` intentionally returns local demo data. Browser DevTools will not show a backend XHR/fetch request.

To test real backend calls:

```env
VITE_DEMO_MODE=false
VITE_API_BASE_URL=http://localhost:8080
```

Restart Vite after changing environment variables.

## Apply Filters

Changing Service, Environment, or Time only updates draft UI values. Clicking **Apply Filters** commits the values and forces an analysis refresh. v0.20 includes a refresh counter so clicking Apply Filters again with the same values still re-runs the data loaders.

## Existing Splunk Dashboard

Changing Dashboard, Service, Environment, or Time does not execute a panel query. Clicking **Load Dashboard** executes the dashboard and panel API calls.

In LIVE mode, expected calls include:

- `GET /api/v1/monitoring/dashboards/{dashboardId}`
- `GET /api/v1/monitoring/dashboards/{dashboardId}/panels/{panelId}?service=...&environment=...&timeRange=...`
- investigation component APIs when **Apply Filters** is clicked
