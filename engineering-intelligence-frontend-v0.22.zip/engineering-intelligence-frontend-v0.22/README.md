# Engineering Intelligence Frontend v0.19

Image-2 baseline UI with detailed, flexible drill-down pages.

## Demo / live switch

```env
VITE_DEMO_MODE=true
VITE_API_BASE_URL=http://localhost:8080
```

Set `VITE_DEMO_MODE=false` after the backend is deployed. The same pages then call the REST APIs.

## Key additions
- Business-friendly Investigation Overview + Technical Monitoring Overview.
- Multiple-service selector and service-specific details.
- Splunk split into **Existing Splunk Dashboard** and **Investigation Splunk Analysis**.
- Existing Splunk panels are configuration-driven from backend `application.yml` using `query-ref`.
- Working drill-down pages: panel details, failure investigation, New Relic transactions/errors, JVM memory/GC/threads, PCF instance details/events, DB query details, code file details, change details, RCA summary.
- All displayed action buttons navigate to real demo pages; live mode calls backend endpoints.

## v0.19 UI baseline

The UI follows the selected dark Image 1 baseline. `CodeAnalysisPage.tsx` uses the richer Image 2-style file explorer, highlighted source, issue details, evidence and recent changes. See `docs/UI_UX_GUIDELINES.md` and `docs/ROUTING_AND_ACTIONS.md`.


## v0.20 filter execution fix

`Apply Filters` now forces a refresh on every click, even when the selected values are unchanged. In `VITE_DEMO_MODE=true`, refreshes use local demo providers and therefore do not create browser Network/XHR calls. Set `VITE_DEMO_MODE=false` and `VITE_API_BASE_URL` to verify real backend calls.
