# Engineering Intelligence Backend v0.4

Spring Boot + MCP backend for Monitoring and EIPA Production Investigation.

## What v0.4 adds

- Monitoring dashboard API that can represent an existing Splunk dashboard.
- Five sample monitoring panels: Authentication Service Calls, IDP Authentication, Login User Authentication, Portal Launch and Partner Identity.
- Clickable monitoring failure categories can launch the EIPA investigation orchestrator.
- Multi-service A -> B -> C traversal across different Bitbucket projects/teams remains supported.
- Recent commit/resource impact analysis remains supported.

## IMPORTANT: Splunk queries in this ZIP are DUMMY ONLY

No proprietary/original Splunk query supplied by the user is included.

See `src/main/resources/application.yml` under `eipa.monitoring.queries`. Each query has a description explaining which kind of existing dashboard query it represents. Replace the dummy SPL with your organization-approved SPL or, preferably, adapt the implementation to reference approved Splunk saved searches.

### Dummy query mappings

| Query Ref | Represents |
|---|---|
| `authentication-service-calls-demo` | High-level authentication service/portal/partner request counts and login/network exceptions |
| `idp-authentication-calls-demo` | IDP request, success, failure, transmit and session/cache exception metrics |
| `login-user-authentication-demo` | Login request, database success, disabled/locked/invalid user and exception metrics |
| `portal-launch-demo` | Portal IDP launch, session-not-found and OAuth request/success/exception metrics |
| `partner-identity-demo` | Partner identity request/response/failure metrics |

## Monitoring APIs

```text
GET  /api/monitoring/dashboards/sso-idp-login
GET  /api/monitoring/dashboards/sso-idp-login/panels/{panelId}
POST /api/monitoring/investigate
```

The current POC returns deterministic demo rows from `MonitoringService`. In production, replace the `demoRows(...)` section with a call to your Splunk connector using the approved query definition/saved search.

## Monitoring -> Investigation flow

```text
Existing/approved Splunk query
  -> Monitoring panel
  -> User clicks actionable failure metric
  -> POST /api/monitoring/investigate
  -> EIPA investigation orchestrator
  -> Splunk detail evidence + Bitbucket code + callers + APIs + consumers + changes
  -> RCA response
```

## Run

Configure connector environment variables when real integrations are enabled:

```text
SPLUNK_URL
SPLUNK_TOKEN
BITBUCKET_URL
BITBUCKET_USERNAME
BITBUCKET_TOKEN
```

Then run the Spring Boot application from IntelliJ using Java 21.
