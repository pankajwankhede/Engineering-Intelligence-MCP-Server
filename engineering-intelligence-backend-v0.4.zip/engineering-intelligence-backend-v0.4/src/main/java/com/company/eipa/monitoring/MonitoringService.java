package com.company.eipa.monitoring;

import com.company.eipa.monitoring.model.MonitoringDashboardResponse;
import com.company.eipa.monitoring.model.MonitoringPanelResponse;
import com.company.eipa.monitoring.model.MonitoringRow;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class MonitoringService {

    private final MonitoringProperties properties;

    public MonitoringService(MonitoringProperties properties) {
        this.properties = properties;
    }

    public MonitoringDashboardResponse dashboard(String dashboardId, String environment, String timeRange) {
        var dashboard = properties.dashboards().get(dashboardId);
        if (dashboard == null) {
            throw new IllegalArgumentException("Unknown monitoring dashboard: " + dashboardId);
        }

        var panels = dashboard.panels() == null ? List.<MonitoringPanelResponse>of() : dashboard.panels().stream()
                .map(panel -> panel(dashboardId, panel.id(), environment, timeRange))
                .toList();

        return new MonitoringDashboardResponse(
                dashboardId,
                dashboard.title(),
                dashboard.description(),
                valueOrDefault(environment, properties.defaultEnvironment(), "PRODUCTION"),
                valueOrDefault(timeRange, properties.defaultTimeRange(), "15m"),
                panels
        );
    }

    public MonitoringPanelResponse panel(String dashboardId, String panelId, String environment, String timeRange) {
        var dashboard = properties.dashboards().get(dashboardId);
        if (dashboard == null || dashboard.panels() == null) {
            throw new IllegalArgumentException("Unknown monitoring dashboard: " + dashboardId);
        }

        var panel = dashboard.panels().stream()
                .filter(p -> p.id().equals(panelId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown monitoring panel: " + panelId));

        var query = properties.queries().get(panel.queryRef());
        if (query == null) {
            throw new IllegalArgumentException("Unknown monitoring query reference: " + panel.queryRef());
        }

        // POC/Demo mode: return deterministic sample rows. In production replace this block
        // with SplunkSearchService.execute(query.spl(), environment, timeRange) and map the results.
        List<MonitoringRow> rows = demoRows(panel.id());

        return new MonitoringPanelResponse(
                dashboardId,
                panel.id(),
                panel.title(),
                query.description(),
                panel.visualization(),
                panel.queryRef(),
                Instant.now(),
                rows
        );
    }

    public String queryDescription(String queryRef) {
        var query = properties.queries().get(queryRef);
        if (query == null) throw new IllegalArgumentException("Unknown monitoring query: " + queryRef);
        return query.description();
    }

    private List<MonitoringRow> demoRows(String panelId) {
        var rows = new ArrayList<MonitoringRow>();
        switch (panelId) {
            case "authentication-service-calls" -> {
                rows.add(row("Portal authentication launch", 298, "DRILLDOWN", null, "INFO"));
                rows.add(row("Partner identity request", 137, "DRILLDOWN", null, "INFO"));
                rows.add(row("Partner identity response", 137, "DRILLDOWN", null, "INFO"));
                rows.add(row("Login service exceptions", 6, "INVESTIGATE", "LOGIN_SERVICE_EXCEPTION", "HIGH"));
                rows.add(row("Unknown host exceptions", 0, "INVESTIGATE", "NETWORK_EXCEPTION", "CRITICAL"));
            }
            case "idp-authentication-calls" -> {
                rows.add(row("Authentication requests", 119, "DRILLDOWN", null, "INFO"));
                rows.add(row("IDP success responses", 116, "DRILLDOWN", null, "INFO"));
                rows.add(row("IDP failure responses", 3, "INVESTIGATE", "IDP_FAILURE_RESPONSE", "CRITICAL"));
                rows.add(row("Transmit requests", 112, "DRILLDOWN", null, "INFO"));
                rows.add(row("Transmit responses", 112, "DRILLDOWN", null, "INFO"));
                rows.add(row("Session-cache exceptions", 1, "INVESTIGATE", "SESSION_CACHE_EXCEPTION", "HIGH"));
            }
            case "login-user-authentication" -> {
                rows.add(row("User login requests", 121, "DRILLDOWN", null, "INFO"));
                rows.add(row("Database success responses", 113, "DRILLDOWN", null, "INFO"));
                rows.add(row("Disabled user", 1, "DRILLDOWN", "DISABLED_USER", "WARNING"));
                rows.add(row("Locked user", 1, "DRILLDOWN", "LOCKED_USER", "WARNING"));
                rows.add(row("Invalid user", 7, "DRILLDOWN", "INVALID_USER", "WARNING"));
                rows.add(row("Unhandled exceptions", 2, "INVESTIGATE", "LOGIN_EXCEPTION", "HIGH"));
            }
            case "portal-launch" -> {
                rows.add(row("IDP launches in portal", 140, "DRILLDOWN", null, "INFO"));
                rows.add(row("IDP launch successful", 138, "DRILLDOWN", null, "INFO"));
                rows.add(row("Portal session not found", 2, "INVESTIGATE", "SESSION_NOT_FOUND", "HIGH"));
                rows.add(row("OAuth requests", 117, "DRILLDOWN", null, "INFO"));
                rows.add(row("OAuth success responses", 116, "DRILLDOWN", null, "INFO"));
                rows.add(row("OAuth exceptions", 1, "INVESTIGATE", "OAUTH_EXCEPTION", "CRITICAL"));
            }
            case "partner-identity" -> {
                rows.add(row("Partner identity requests", 420, "DRILLDOWN", null, "INFO"));
                rows.add(row("Partner identity responses", 416, "DRILLDOWN", null, "INFO"));
                rows.add(row("Partner identity failures", 4, "INVESTIGATE", "PARTNER_IDENTITY_FAILURE", "HIGH"));
            }
            default -> rows.add(row("Sample metric", 1, "DRILLDOWN", null, "INFO"));
        }
        return rows;
    }

    private MonitoringRow row(String label, long count, String action, String category, String severity) {
        return new MonitoringRow(label, count, action, category, severity);
    }

    private String valueOrDefault(String value, String configured, String fallback) {
        if (value != null && !value.isBlank()) return value;
        if (configured != null && !configured.isBlank()) return configured;
        return fallback;
    }
}
