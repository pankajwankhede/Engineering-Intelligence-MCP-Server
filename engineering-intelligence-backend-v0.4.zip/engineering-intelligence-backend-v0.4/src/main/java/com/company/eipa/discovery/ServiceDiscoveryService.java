package com.company.eipa.discovery;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.model.InvestigationRequest;
import org.springframework.stereotype.Service;

import java.util.Locale;

/**
 * POC discovery layer. Replace demo heuristics with a bounded enterprise Splunk discovery search
 * over common metadata fields: serviceName, trackingId, requestId, traceId, api path and error text.
 */
@Service
public class ServiceDiscoveryService {
    private final ServiceCatalog catalog;

    public ServiceDiscoveryService(ServiceCatalog catalog) {
        this.catalog = catalog;
    }

    public String discoverEntryService(InvestigationRequest request) {
        if (request.service() != null && !request.service().isBlank()) {
            catalog.required(request.service());
            return request.service();
        }

        String text = String.join(" ", safe(request.trackingId()), safe(request.requestId()),
                safe(request.traceId()), safe(request.apiUrl()), safe(request.errorOrException()),
                safe(request.description())).toLowerCase(Locale.ROOT);

        if (text.contains("merchant")) return "merchant-service";
        if (text.contains("payment")) return "payment-service";
        if (text.contains("account") || text.contains("sqltimeout")) return "service-c";

        // Demo default for unknown tracking IDs: discovery search finds service-a as entry point.
        return catalog.serviceNames().contains("service-a") ? "service-a" : catalog.serviceNames().stream().findFirst()
                .orElseThrow(() -> new IllegalStateException("No services registered"));
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
