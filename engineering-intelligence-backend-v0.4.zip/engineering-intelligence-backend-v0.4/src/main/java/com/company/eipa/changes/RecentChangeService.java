package com.company.eipa.changes;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.model.ChangedResource;
import com.company.eipa.model.FailureInfo;
import com.company.eipa.model.RecentChangeInfo;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class RecentChangeService {
    private final ServiceCatalog catalog;

    public RecentChangeService(ServiceCatalog catalog) {
        this.catalog = catalog;
    }

    public List<RecentChangeInfo> findRecentChanges(String serviceName, FailureInfo failure) {
        var definition = catalog.required(serviceName);
        String rootFile = failure == null || failure.fileName() == null ? "Unknown.java" : failure.fileName();

        // POC data. Real implementation: call Bitbucket commits/file-history/diff APIs for the mapped repo.
        List<ChangedResource> resources = List.of(
                new ChangedResource("src/main/java/com/company/account/repository/" + rootFile, "JAVA_CLASS", "HIGH", true, 18, 6),
                new ChangedResource("src/main/java/com/company/account/service/AccountService.java", "JAVA_CLASS", "MEDIUM", true, 7, 2),
                new ChangedResource("src/main/resources/application.yml", "CONFIG", "HIGH", true, 3, 1),
                new ChangedResource("src/test/java/com/company/account/AccountRepositoryTest.java", "TEST", "LOW", false, 28, 0),
                new ChangedResource("openapi/account-api.yaml", "API_SPEC", "LOW", false, 4, 1),
                new ChangedResource("build.gradle", "BUILD", "LOW", false, 1, 1),
                new ChangedResource("config/account-prod.yml", "CONFIG", "MEDIUM", false, 2, 1),
                new ChangedResource("README.md", "DOCUMENTATION", "LOW", false, 5, 0));

        Map<String, Integer> counts = new LinkedHashMap<>();
        resources.forEach(r -> counts.merge(r.type(), 1, Integer::sum));
        int related = (int) resources.stream().filter(ChangedResource::incidentRelated).count();

        return List.of(new RecentChangeInfo(
                "e539dc2",
                "developer1",
                "2026-08-16T16:32:00Z",
                "Handle account query timeout and add retry logic",
                "HIGH",
                "HIGH",
                resources.size(),
                related,
                counts,
                resources));
    }
}
