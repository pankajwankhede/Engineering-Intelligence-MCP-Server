package com.company.eipa.api;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.investigation.InvestigationOrchestrator;
import com.company.eipa.model.InvestigationRequest;
import com.company.eipa.model.InvestigationResult;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:5173"})
public class InvestigationController {
    private final InvestigationOrchestrator orchestrator;
    private final ServiceCatalog catalog;

    public InvestigationController(InvestigationOrchestrator orchestrator, ServiceCatalog catalog) {
        this.orchestrator = orchestrator;
        this.catalog = catalog;
    }

    @PostMapping("/investigations")
    public ResponseEntity<InvestigationResult> investigate(@RequestBody InvestigationRequest request) {
        return ResponseEntity.ok(orchestrator.investigate(request));
    }

    @GetMapping("/catalog/services")
    public Set<String> services() {
        return catalog.serviceNames();
    }
}
