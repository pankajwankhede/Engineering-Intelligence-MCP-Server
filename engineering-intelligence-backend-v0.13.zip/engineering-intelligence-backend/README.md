# Engineering Intelligence Backend v0.13.0

Spring Boot backend for the Engineering Intelligence UI.

## Current implementation

- Natural-language investigation endpoint
- LLM Gateway abstraction with deterministic fallback parser
- Connector registry for Splunk, Bitbucket, New Relic, PCF/Tanzu, Oracle MCP, SQL Server MCP, and JDBC/ORM analyzer
- REST contracts used by the frontend
- Separate backend demo flag so you can deploy the API before live enterprise connections are ready
- Actuator health endpoint
- PCF `manifest.yml`

## Java / Spring

This project uses Java 21 and Spring Boot 4.1.0.

## Run

```bash
mvn spring-boot:run
```

## Important flags

### Backend sandbox/demo data

```bash
export EIPA_DEMO_ENABLED=true
```

### Full live backend

```bash
export EIPA_DEMO_ENABLED=false
export EIPA_LLM_ENABLED=true
export EIPA_LLM_BASE_URL=https://your-llm-gateway
export EIPA_SPLUNK_ENABLED=true
export EIPA_SPLUNK_BASE_URL=https://your-splunk-mcp
# ...enable the other connector variables from application.yml
```

## Frontend rollout

While UI-only demoing:

```properties
VITE_DEMO_MODE=true
```

After this backend is deployed:

```properties
VITE_DEMO_MODE=false
VITE_API_BASE_URL=https://engineering-intelligence-backend.apps.company.com
```

That is the key frontend switch. No React page needs to be rewritten.

## API contracts

- `GET /api/v1/status`
- `GET /api/v1/integrations`
- `POST /api/v1/ai/interpret`
- `POST /api/v1/investigations`
- `GET /api/v1/investigations/{id}`
- `GET /api/v1/investigations/{id}/database`
- `GET /api/v1/investigations/{id}/monitoring`
- `GET /api/v1/investigations/{id}/runtime`
- `GET /actuator/health`

## Production connector implementation

The included connector registry and configuration are intentionally adapter-oriented. Add your organization-specific MCP/REST request contracts behind interfaces without changing the frontend API. Keep Oracle/SQL Server access read-only for investigation use and route secrets through Vault/PCF environment bindings instead of source control.
