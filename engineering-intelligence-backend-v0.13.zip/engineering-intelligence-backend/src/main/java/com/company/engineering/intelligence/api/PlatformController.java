package com.company.engineering.intelligence.api;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.*;
import com.company.engineering.intelligence.service.ConnectorRegistry;
import com.company.engineering.intelligence.service.InvestigationService;
import com.company.engineering.intelligence.service.LlmGateway;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class PlatformController {
    private final PlatformProperties properties;
    private final ConnectorRegistry registry;
    private final InvestigationService investigations;
    private final LlmGateway llmGateway;

    public PlatformController(PlatformProperties properties, ConnectorRegistry registry, InvestigationService investigations, LlmGateway llmGateway) {
        this.properties = properties; this.registry = registry; this.investigations = investigations; this.llmGateway = llmGateway;
    }

    @GetMapping("/status")
    public PlatformStatus status() {
        return new PlatformStatus("HEALTHY", properties.demo().enabled() ? "DEMO" : "LIVE", registry.status("splunk"), registry.status("bitbucket"), registry.status("newrelic"), registry.status("pcf"), registry.status("oracle"), registry.status("sqlserver"), properties.demo().enabled() ? "DEMO" : (properties.llm().enabled()?"CONNECTED":"DISABLED"));
    }

    @GetMapping("/integrations") public List<IntegrationItem> integrations() { return registry.integrations(); }
    @PostMapping("/ai/interpret") public Interpretation interpret(@RequestBody Map<String,String> body) { return llmGateway.interpret(body.getOrDefault("query", "")); }
    @PostMapping("/investigations") public InvestigationResult start(@Valid @RequestBody InvestigationRequest request) { return investigations.start(request); }
    @GetMapping("/investigations/{id}") public InvestigationResult get(@PathVariable String id) { return investigations.start(new InvestigationRequest("Find NullPointerException in bc-login-service", "PRODUCTION", "Last 2 Hours")); }
    @GetMapping("/investigations/{id}/database") public DatabaseAnalysis database(@PathVariable String id) { return investigations.database(); }
    @GetMapping("/investigations/{id}/monitoring") public MonitoringAnalysis monitoring(@PathVariable String id) { return investigations.monitoring(); }
    @GetMapping("/investigations/{id}/runtime") public RuntimeAnalysis runtime(@PathVariable String id) { return investigations.runtime(); }
}
