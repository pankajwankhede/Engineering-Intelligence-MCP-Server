package com.company.engineering.intelligence.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

@ConfigurationProperties(prefix = "eipa")
public record PlatformProperties(
        Demo demo,
        Llm llm,
        Map<String, Connector> connectors
) {
    public record Demo(boolean enabled) {}
    public record Llm(boolean enabled, String baseUrl, String model, String apiKey) {}
    public record Connector(boolean enabled, String baseUrl, String token, String mode) {}
}
