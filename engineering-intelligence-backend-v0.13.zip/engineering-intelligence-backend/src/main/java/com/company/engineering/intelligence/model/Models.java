package com.company.engineering.intelligence.model;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public final class Models {
    private Models() {}

    public record InvestigationRequest(@NotBlank String query, String environment, String timeRange) {}
    public record Understanding(String intent, String service, String exception, String environment, String timeRange, int confidence) {}
    public record RootCause(String title, String description, int confidence, String file, Integer line) {}
    public record Impact(int services, double failedRequestPercent, int usersImpacted) {}
    public record Evidence(String source, String summary, String status) {}
    public record InvestigationResult(String investigationId, String status, Understanding understanding, RootCause rootCause, Impact impact, List<Evidence> evidence) {}

    public record PlatformStatus(String backend, String mode, String splunk, String bitbucket, String newRelic, String pcf, String oracle, String sqlServer, String llmGateway) {}
    public record LongQuery(String sqlId, String duration, String status) {}
    public record BlockingSession(String sid, int blocked, String duration) {}
    public record DatabaseAnalysis(String type, String database, String schema, String connectionRef, String persistenceTechnology, int active, int idle, int waiting, int maxConnections, List<LongQuery> longRunningQueries, List<BlockingSession> blockingSessions, List<String> recommendations) {}
    public record MonitoringAnalysis(int requestRate, double errorRate, int failedRequests, int p95LatencyMs, List<Integer> throughputTrend, List<Integer> errorTrend) {}
    public record RuntimeAnalysis(String platform, String org, String space, String app, int instances, int healthyInstances, int memoryMb, int restartsLastHour, List<String> recentEvents) {}
    public record IntegrationItem(String key, String name, String category, String status, String endpoint, String details) {}
    public record Interpretation(String intent, String service, String exception, int confidence) {}
}
