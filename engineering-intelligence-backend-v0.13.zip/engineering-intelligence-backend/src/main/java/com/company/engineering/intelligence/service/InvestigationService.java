package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.model.Models.*;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class InvestigationService {
    private final LlmGateway llmGateway;
    private final AtomicInteger counter = new AtomicInteger(17);

    public InvestigationService(LlmGateway llmGateway) { this.llmGateway = llmGateway; }

    public InvestigationResult start(InvestigationRequest request) {
        Interpretation p = llmGateway.interpret(request.query());
        String id = "INV-" + LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE) + "-" + String.format("%04d", counter.getAndIncrement());
        String exception = p.exception() == null ? "RuntimeException" : p.exception();
        String service = p.service();
        return new InvestigationResult(
                id, "COMPLETED",
                new Understanding(p.intent(), service, exception, defaulted(request.environment(), "PRODUCTION"), defaulted(request.timeRange(), "Last 2 Hours"), p.confidence()),
                new RootCause(exception + " in UserService", "customer.getProfile() can return null before getAddress() is called. Evidence should be replaced by live connector results when connectors are enabled.", 94, "src/main/java/com/company/login/service/UserService.java", 187),
                new Impact(3, 25.4, 12800),
                List.of(
                        new Evidence("Splunk", "45 matching error events in selected window", "MATCH"),
                        new Evidence("New Relic", "Error rate increased to 25.4%; p95 latency 840 ms", "MATCH"),
                        new Evidence("PCF / Tanzu", "One instance restart correlated with the incident", "MATCH"),
                        new Evidence("Bitbucket", "Potential null dereference found at UserService.java:187", "MATCH"),
                        new Evidence("Oracle", "Profile data anomaly available for correlation", "MATCH")
                )
        );
    }

    public DatabaseAnalysis database() {
        return new DatabaseAnalysis("ORACLE", "ORCL", "BCLOGIN", "logical-prod-readonly", "SPRING DATA JPA", 18, 12, 20, 50,
                List.of(new LongQuery("a1b2c3d4", "00:12:45", "RUNNING"), new LongQuery("d4e5f6a7", "00:08:31", "RUNNING"), new LongQuery("f7e6d5c4", "00:06:02", "RUNNING")),
                List.of(new BlockingSession("12345", 15, "00:05:12"), new BlockingSession("23456", 8, "00:03:47")),
                List.of("Consider adding an index on BC_USER.LOGIN_ID.", "Review long running query a1b2c3d4.", "Connection pool utilization is within configured capacity."));
    }

    public MonitoringAnalysis monitoring() { return new MonitoringAnalysis(256, 25.4, 1245, 840, List.of(510,488,470,430,390,360,300,256), List.of(10,15,18,28,55,105,180,256)); }
    public RuntimeAnalysis runtime() { return new RuntimeAnalysis("PCF / Tanzu", "engineering", "production", "bc-login-service", 4, 3, 1024, 1, List.of("10:19:45 Deployment completed", "10:20:10 All 4 instances healthy", "10:23:28 Health check latency increased", "10:24:08 Instance 2 restarted")); }
    private String defaulted(String value, String fallback) { return value == null || value.isBlank() ? fallback : value; }
}
