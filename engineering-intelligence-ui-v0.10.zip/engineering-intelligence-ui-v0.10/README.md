# Engineering Intelligence UI v0.9

React + Vite + TypeScript UI for Monitoring and EIPA Production Investigation.

## Fully dynamic UI

The React source contains no service-specific investigation data. It does not hardcode service names, repositories, class names, methods, API endpoints, consumers, commit IDs, tracking IDs, root causes, or log events.

All operational content is loaded from the backend:

- Monitoring dashboards/panels/metrics → `/api/monitoring/...`
- Investigation result/service flow → `/api/investigations`
- Correlated logs → `/api/logs/search`
- Repository file list → `/api/code/services/{service}/files`
- Selected source file → `/api/code/services/{service}/file`
- Last commits and pull requests → `/api/changes/services/{service}`

If the backend is unavailable, the UI displays an error or empty state. It does **not** fabricate a demo investigation.

The last real investigation response is cached in `sessionStorage` so page navigation/refresh does not lose the result.

## Run

```bash
npm install
npm run dev
```

Vite proxies `/api` to `http://localhost:8080` by default; change `vite.config.ts` for another backend URL.


## Temporary Demo Mode

The UI has one isolated demo data source at `src/demo/demo.ts`. No page contains hardcoded domain data.

### Run with demo data

Create `.env.local` (or copy `.env.demo`) with:

```properties
VITE_DEMO_MODE=true
VITE_DEMO_DELAY_MS=250
```

Then run:

```bash
npm install
npm run dev
```

A visible **DEMO MODE** banner is shown. API functions in `src/services/api.ts` return `src/demo/demo.ts` data and do not require the Spring Boot backend.

### Run with live backend/MCP

Use:

```properties
VITE_DEMO_MODE=false
```

or remove the local demo flag. The same pages then call the real `/api/...` endpoints.

Do not add sample service/class/method values directly to React pages. Add temporary presentation data only in `src/demo/demo.ts`.
