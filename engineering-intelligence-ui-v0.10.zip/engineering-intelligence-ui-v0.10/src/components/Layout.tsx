import { FormEvent, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { startInvestigation } from '../services/api';
import { useInvestigation } from '../state';
import type { InvestigationRequest } from '../types';
import { appConfig } from '../config/appConfig';

const nav = [
  ['/', 'Monitoring'], ['/overview', 'Investigation Overview'], ['/investigate', 'Start Investigation'], ['/service-flow', 'Service Flow'], ['/logs', 'Logs & Trace'],
  ['/code', 'Code Analysis'], ['/call-flow', 'Call Flow'], ['/consumers', 'API & Consumers'], ['/changes', 'Recent Changes'],
  ['/blast-radius', 'Blast Radius'], ['/timeline', 'Evidence Timeline'], ['/recommendations', 'Recommendations'],
  ['/similar', 'Similar Incidents'], ['/reports', 'Reports'], ['/settings', 'Settings']
];

function searchRequest(raw: string): InvestigationRequest {
  const value = raw.trim();
  const request: InvestigationRequest = { description: value };
  if (/^TRK[-_:]/i.test(value)) request.trackingId = value;
  else if (/^REQ[-_:]/i.test(value)) request.requestId = value;
  else if (/^(trace|traceid)[:=\s-]/i.test(value)) request.traceId = value.replace(/^(trace|traceid)[:=\s-]+/i, '');
  return request;
}

export function Layout() {
  const navigate = useNavigate();
  const { setResult } = useInvestigation();
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);

  const submitSearch = async (event: FormEvent) => {
    event.preventDefault();
    if (!query.trim() || searching) return;
    setSearching(true);
    navigate('/progress');
    try {
      const result = await startInvestigation(searchRequest(query));
      setResult(result);
      navigate('/overview');
    } finally {
      setSearching(false);
    }
  };

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-logo">AI</div><div><strong>Engineering Intelligence</strong><small>Monitoring + Investigation</small></div></div>
      <nav>{nav.map(([path, label]) => <NavLink key={path} to={path} end={path === '/'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>{label}</NavLink>)}</nav>
      <div className="side-tip"><b>Investigation Tips</b><span>Provide any ID, service, API, exception, or plain-English symptom.</span></div>
    </aside>
    <main className="main-area">
      <header className="topbar">
        <button className="mobile-brand" onClick={() => navigate('/')}>AI</button>
        <form className="global-search" onSubmit={submitSearch}>
          <span>⌕</span>
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search Request ID, Tracking ID, Trace ID, Service, Error or description..." aria-label="Global production investigation search" />
          <button type="submit" disabled={!query.trim() || searching}>{searching ? 'Searching…' : 'Investigate'}</button>
        </form>
        <div className="top-actions"><div className="avatar">EI</div></div>
      </header>
      {appConfig.demoMode && <div className="demo-mode-banner">DEMO MODE — Synthetic sample data. Set VITE_DEMO_MODE=false for live backend data.</div>}
      <div className="content"><Outlet /></div>
    </main>
  </div>;
}
