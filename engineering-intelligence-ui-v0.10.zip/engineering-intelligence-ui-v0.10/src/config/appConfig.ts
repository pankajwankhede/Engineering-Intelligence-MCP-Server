export const appConfig = {
  demoMode: import.meta.env.VITE_DEMO_MODE === 'true',
  demoDelayMs: Number(import.meta.env.VITE_DEMO_DELAY_MS ?? 250)
};

export async function demoDelay(): Promise<void> {
  if (!appConfig.demoMode || appConfig.demoDelayMs <= 0) return;
  await new Promise(resolve => window.setTimeout(resolve, appConfig.demoDelayMs));
}
