import type {
  InvestigationResult, MonitoringDashboard, MonitoringDashboardDefinition,
  MonitoringDashboardSummary, MonitoringPanel, CodeFileInfo, CodeFileContent,
  ServiceChangeHistory, LogSearchResponse, MonitoringRow
} from '../types';

export const demoInvestigation: InvestigationResult = {
  investigationId: 'DEMO-INV-001',
  status: 'COMPLETED',
  entryService: 'demo-entry-service',
  trackingId: 'TRK-DEMO-001',
  requestId: 'REQ-DEMO-001',
  traceId: 'TRACE-DEMO-001',
  environment: 'PRODUCTION',
  timeRange: '2h',
  traversalOrder: ['demo-entry-service', 'demo-downstream-service'],
  serviceFlow: [
    {
      service: 'demo-entry-service',
      team: 'Demo Platform Team A',
      businessDomain: 'Demo Domain',
      repository: 'DEMO/demo-entry-service',
      status: 'IMPACTED',
      issueFound: false,
      callers: [],
      apiEndpoints: ['POST /demo/process'],
      consumers: ['demo-consumer'],
      downstreamServices: ['demo-downstream-service']
    },
    {
      service: 'demo-downstream-service',
      team: 'Demo Platform Team B',
      businessDomain: 'Demo Domain',
      repository: 'DEMO/demo-downstream-service',
      status: 'FAILED',
      issueFound: true,
      failure: {
        exception: 'DemoProcessingException',
        className: 'DemoProcessor',
        methodName: 'process',
        fileName: 'src/main/java/demo/DemoProcessor.java',
        lineNumber: 42
      },
      componentAnalysis: {
        classPurpose: 'Demonstration component used only when UI demo mode is enabled.',
        methodPurpose: 'Demonstrates how dynamically returned code analysis is rendered.',
        issueFound: true,
        issue: 'Synthetic demo failure for UI presentation.'
      },
      callers: ['DemoService.execute'],
      apiEndpoints: ['POST /demo/process'],
      consumers: ['demo-entry-service'],
      downstreamServices: []
    }
  ],
  rootCause: {
    service: 'demo-downstream-service',
    ownerTeam: 'Demo Platform Team B',
    repository: 'DEMO/demo-downstream-service',
    className: 'DemoProcessor',
    methodName: 'process',
    lineNumber: 42,
    reason: 'Synthetic demo root cause. Disable VITE_DEMO_MODE to use live backend/MCP data.',
    confidence: 0.94
  },
  impactedTeams: ['Demo Platform Team A', 'Demo Platform Team B'],
  recentChanges: [
    {
      commit: 'd3m0c01',
      author: 'Demo Developer',
      timestamp: '2026-08-16T14:10:00Z',
      message: 'Demo change near the affected component',
      correlation: 'HIGH',
      risk: 'MEDIUM',
      totalResources: 3,
      incidentRelatedResources: 2,
      resourceTypeCounts: { JAVA: 1, TEST: 1, CONFIG: 1 },
      resources: [
        { path: 'src/main/java/demo/DemoProcessor.java', type: 'JAVA', relevance: 'HIGH', incidentRelated: true, additions: 12, deletions: 3 },
        { path: 'src/test/java/demo/DemoProcessorTest.java', type: 'TEST', relevance: 'MEDIUM', incidentRelated: true, additions: 18, deletions: 0 },
        { path: 'src/main/resources/application.yml', type: 'CONFIG', relevance: 'LOW', incidentRelated: false, additions: 1, deletions: 1 }
      ]
    }
  ],
  recommendations: [
    'Review the highlighted demo failure location.',
    'Validate the behavior with a regression test.',
    'Disable demo mode before connecting to production data.'
  ]
};

export const demoMonitoringSummaries: MonitoringDashboardSummary[] = [{
  dashboardId: 'demo-engineering-monitoring',
  title: 'Demo Engineering Monitoring',
  description: 'Synthetic monitoring dashboard shown only in UI demo mode.',
  panelCount: 2
}];

export const demoMonitoringDefinition: MonitoringDashboardDefinition = {
  dashboardId: 'demo-engineering-monitoring',
  title: 'Demo Engineering Monitoring',
  description: 'Synthetic monitoring definition.',
  panels: [
    { panelId: 'request-health', title: 'Request Health', visualization: 'table', queryReference: 'demo-request-health', description: 'Demo request success/failure metrics.' },
    { panelId: 'runtime-errors', title: 'Runtime Errors', visualization: 'table', queryReference: 'demo-runtime-errors', description: 'Demo error metrics with investigation actions.' }
  ]
};

const monitoringRows: Record<string, MonitoringRow[]> = {
  'request-health': [
    { label: 'Requests', count: 1240, action: 'METRIC', severity: 'INFO' },
    { label: 'Successful responses', count: 1218, action: 'METRIC', severity: 'INFO' },
    { label: 'Failed responses', count: 22, action: 'INVESTIGATE', investigationCategory: 'DEMO_FAILURE', severity: 'HIGH' }
  ],
  'runtime-errors': [
    { label: 'Application exceptions', count: 7, action: 'INVESTIGATE', investigationCategory: 'DEMO_EXCEPTION', severity: 'HIGH' },
    { label: 'Timeouts', count: 3, action: 'INVESTIGATE', investigationCategory: 'DEMO_TIMEOUT', severity: 'MEDIUM' }
  ]
};

export function demoMonitoringPanel(panelId: string): MonitoringPanel {
  const def = demoMonitoringDefinition.panels.find(p => p.panelId === panelId) ?? demoMonitoringDefinition.panels[0];
  return {
    dashboardId: demoMonitoringDefinition.dashboardId,
    panelId: def.panelId,
    title: def.title,
    description: def.description,
    visualization: def.visualization,
    queryReference: def.queryReference,
    generatedAt: new Date().toISOString(),
    rows: monitoringRows[def.panelId] ?? []
  };
}

export function demoMonitoringDashboard(environment: string, timeRange: string): MonitoringDashboard {
  return {
    dashboardId: demoMonitoringDefinition.dashboardId,
    title: demoMonitoringDefinition.title,
    description: demoMonitoringDefinition.description,
    environment,
    timeRange,
    panels: demoMonitoringDefinition.panels.map(p => demoMonitoringPanel(p.panelId))
  };
}

export const demoCodeFiles: CodeFileInfo[] = [
  { path: 'src/main/java/demo/DemoController.java', type: 'JAVA', displayName: 'DemoController.java' },
  { path: 'src/main/java/demo/DemoService.java', type: 'JAVA', displayName: 'DemoService.java' },
  { path: 'src/main/java/demo/DemoProcessor.java', type: 'JAVA', displayName: 'DemoProcessor.java' },
  { path: 'src/test/java/demo/DemoProcessorTest.java', type: 'TEST', displayName: 'DemoProcessorTest.java' }
];

const codeByPath: Record<string, string> = {
  'src/main/java/demo/DemoController.java': `package demo;

@RestController
class DemoController {
    private final DemoService service;

    @PostMapping("/demo/process")
    Object process(@RequestBody Object request) {
        return service.execute(request);
    }
}`,
  'src/main/java/demo/DemoService.java': `package demo;

@Service
class DemoService {
    private final DemoProcessor processor;

    Object execute(Object request) {
        return processor.process(request);
    }
}`,
  'src/main/java/demo/DemoProcessor.java': `package demo;

@Component
class DemoProcessor {

    Object process(Object request) {
        // Synthetic demo code only.
        if (request == null) {
            throw new DemoProcessingException("Demo request was null");
        }
        return request;
    }
}`,
  'src/test/java/demo/DemoProcessorTest.java': `package demo;

class DemoProcessorTest {
    // Demo test file for the Code Analysis page.
}`
};

export function demoCodeFile(service: string, path: string, highlightedLine?: number): CodeFileContent {
  return {
    service,
    repository: `DEMO/${service}`,
    branch: 'main',
    path,
    content: codeByPath[path] ?? '// Demo file content is not configured for this path.',
    highlightedLine
  };
}

export function demoChangeHistory(service: string): ServiceChangeHistory {
  return {
    service,
    team: 'Demo Platform Team',
    repository: `DEMO/${service}`,
    commits: [
      ...demoInvestigation.recentChanges,
      {
        ...demoInvestigation.recentChanges[0],
        commit: 'd3m0c02',
        timestamp: '2026-08-15T18:20:00Z',
        message: 'Demo refactoring change',
        correlation: 'LOW',
        risk: 'LOW',
        incidentRelatedResources: 0
      }
    ],
    pullRequests: [
      {
        id: 'PR-DEMO-101',
        title: 'Demo processing update',
        author: 'Demo Developer',
        sourceBranch: 'feature/demo-processing',
        destinationBranch: 'main',
        state: 'MERGED',
        updatedAt: '2026-08-16T13:50:00Z',
        service,
        repository: `DEMO/${service}`
      }
    ]
  };
}

export function demoLogs(services: string[], service?: string, level?: string, query?: string, timeRange = '2h'): LogSearchResponse {
  const all = [
    {
      time: '2026-08-16T14:15:01Z',
      service: 'demo-entry-service',
      environment: 'PRODUCTION',
      level: 'INFO',
      trackingId: 'TRK-DEMO-001',
      requestId: 'REQ-DEMO-001',
      traceId: 'TRACE-DEMO-001',
      httpStatus: 200,
      className: 'DemoController',
      methodName: 'process',
      lineNumber: 18,
      message: 'Demo request received.',
      format: 'STANDARD_JSON',
      parseConfidence: 1,
      raw: '{"level":"INFO","message":"Demo request received."}'
    },
    {
      time: '2026-08-16T14:15:02Z',
      service: 'demo-downstream-service',
      environment: 'PRODUCTION',
      level: 'ERROR',
      trackingId: 'TRK-DEMO-001',
      requestId: 'REQ-DEMO-001',
      traceId: 'TRACE-DEMO-001',
      httpStatus: 500,
      className: 'DemoProcessor',
      methodName: 'process',
      lineNumber: 42,
      errorCode: 'DEMO_PROCESSING_FAILED',
      exceptionType: 'DemoProcessingException',
      message: 'Synthetic demo processing failure.',
      format: 'JAVA_TEXT',
      parseConfidence: 0.92,
      raw: 'ERROR demo.DemoProcessor.process-Line:42 - Synthetic demo processing failure.'
    }
  ];
  const q = (query ?? '').toLowerCase();
  const events = all.filter(e =>
    (!services.length || services.includes(e.service)) &&
    (!service || e.service === service) &&
    (!level || level === 'ALL' || e.level === level) &&
    (!q || `${e.message} ${e.className} ${e.methodName} ${e.errorCode ?? ''} ${e.trackingId}`.toLowerCase().includes(q))
  );
  return { services: services.length ? services : ['demo-entry-service', 'demo-downstream-service'], selectedService: service, level, query, timeRange, events };
}
