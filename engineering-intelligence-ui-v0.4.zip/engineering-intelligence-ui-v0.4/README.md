# Engineering Intelligence UI v0.4

React + Vite + TypeScript UI for Monitoring + EIPA Production Investigation.

## Monitoring flow

The default page is now **Monitoring**. It displays five sample panels modeled after an operational SSO/IDP dashboard. Data comes from `/api/monitoring/dashboards/sso-idp-login`.

Rows are classified as:

- `DRILLDOWN` - open matching operational details/logs.
- `INVESTIGATE` - open the Investigation Mode drawer and launch EIPA.
- `METRIC` - display only.

Example:

```text
Authentication Calls in IDP
  Authentication requests       119
  IDP success responses         116
  IDP failure responses           3  <- click

click
  -> Investigation Mode
  -> Investigate with EIPA
  -> Investigation Overview / Logs / Code / Service Flow / Consumers / Changes / Blast Radius / Recommendations
```

## Safety

The UI contains demo data only when the backend is unavailable. The backend v0.4 package contains dummy SPL only; no original/proprietary Splunk queries are included.

## Run

```bash
npm install
npm run dev
```

The Vite dev server proxies `/api` to the backend on `http://localhost:8080`.
