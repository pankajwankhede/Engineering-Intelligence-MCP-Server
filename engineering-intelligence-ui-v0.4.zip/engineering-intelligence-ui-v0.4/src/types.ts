export type Status = 'COMPLETED' | 'IN_PROGRESS' | 'FAILED';

export interface InvestigationRequest {
  service?: string;
  trackingId?: string;
  requestId?: string;
  traceId?: string;
  apiUrl?: string;
  errorOrException?: string;
  description?: string;
  environment?: string;
  timeRange?: string;
}

export interface FailureInfo {
  exception?: string;
  className?: string;
  methodName?: string;
  fileName?: string;
  lineNumber?: number;
}

export interface CodeComponentInfo {
  classPurpose?: string;
  methodPurpose?: string;
  issueFound?: boolean;
  issue?: string;
}

export interface ServiceStep {
  service: string;
  team: string;
  businessDomain: string;
  repository: string;
  status: string;
  issueFound: boolean;
  failure?: FailureInfo;
  componentAnalysis?: CodeComponentInfo;
  callers: string[];
  apiEndpoints: string[];
  consumers: string[];
  downstreamServices: string[];
}

export interface ChangedResource {
  path: string;
  type: string;
  relevance: string;
  incidentRelated: boolean;
  additions: number;
  deletions: number;
}

export interface RecentChange {
  commit: string;
  author: string;
  timestamp: string;
  message: string;
  correlation: string;
  risk: string;
  totalResources: number;
  incidentRelatedResources: number;
  resourceTypeCounts: Record<string, number>;
  resources: ChangedResource[];
}

export interface InvestigationResult {
  investigationId: string;
  status: Status;
  entryService: string;
  trackingId?: string;
  requestId?: string;
  traceId?: string;
  environment: string;
  timeRange: string;
  traversalOrder: string[];
  serviceFlow: ServiceStep[];
  rootCause: {
    service?: string;
    ownerTeam?: string;
    repository?: string;
    className?: string;
    methodName?: string;
    lineNumber?: number;
    reason: string;
    confidence: number;
  };
  impactedTeams: string[];
  recentChanges: RecentChange[];
  recommendations: string[];
}

export interface MonitoringRow {
  label: string;
  count: number;
  action: 'METRIC' | 'DRILLDOWN' | 'INVESTIGATE';
  investigationCategory?: string;
  severity: string;
}

export interface MonitoringPanel {
  dashboardId: string;
  panelId: string;
  title: string;
  description: string;
  visualization: string;
  queryReference: string;
  generatedAt: string;
  rows: MonitoringRow[];
}

export interface MonitoringDashboard {
  dashboardId: string;
  title: string;
  description: string;
  environment: string;
  timeRange: string;
  panels: MonitoringPanel[];
}
