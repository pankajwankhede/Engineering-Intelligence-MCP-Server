import type { InvestigationRequest, InvestigationResult, MonitoringDashboard, MonitoringRow } from '../types';
import { demoInvestigation } from '../data/demo';

export async function startInvestigation(request: InvestigationRequest): Promise<InvestigationResult> {
  try {
    const response = await fetch('/api/investigations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request)
    });
    if (!response.ok) throw new Error(`Backend returned ${response.status}`);
    return await response.json();
  } catch (error) {
    console.warn('Using demo response because backend is unavailable.', error);
    await new Promise(resolve => setTimeout(resolve, 700));
    return {
      ...demoInvestigation,
      entryService: request.service || demoInvestigation.entryService,
      trackingId: request.trackingId || demoInvestigation.trackingId,
      requestId: request.requestId || demoInvestigation.requestId,
      traceId: request.traceId || demoInvestigation.traceId,
      environment: request.environment || 'PRODUCTION',
      timeRange: request.timeRange || '2h'
    };
  }
}


export async function getMonitoringDashboard(environment = 'PRODUCTION', timeRange = '15m'): Promise<MonitoringDashboard> {
  const url = `/api/monitoring/dashboards/sso-idp-login?environment=${encodeURIComponent(environment)}&timeRange=${encodeURIComponent(timeRange)}`;
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Backend returned ${response.status}`);
    return await response.json();
  } catch (error) {
    console.warn('Using monitoring demo data because backend is unavailable.', error);
    return demoMonitoringDashboard(environment, timeRange);
  }
}

export async function investigateMonitoringMetric(input: {
  dashboardId: string;
  panelId: string;
  row: MonitoringRow;
  environment: string;
  timeRange: string;
}): Promise<InvestigationResult> {
  try {
    const response = await fetch('/api/monitoring/investigate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        dashboardId: input.dashboardId,
        panelId: input.panelId,
        metricLabel: input.row.label,
        investigationCategory: input.row.investigationCategory,
        environment: input.environment,
        timeRange: input.timeRange
      })
    });
    if (!response.ok) throw new Error(`Backend returned ${response.status}`);
    return await response.json();
  } catch (error) {
    console.warn('Using demo investigation because backend is unavailable.', error);
    await new Promise(resolve => setTimeout(resolve, 900));
    return demoInvestigation;
  }
}

function demoMonitoringDashboard(environment: string, timeRange: string): MonitoringDashboard {
  const panel = (panelId: string, title: string, description: string, rows: MonitoringRow[]) => ({
    dashboardId: 'sso-idp-login', panelId, title, description, visualization: 'table',
    queryReference: `${panelId}-demo`, generatedAt: new Date().toISOString(), rows
  });
  return {
    dashboardId: 'sso-idp-login',
    title: 'Sample SSO IDP Login Monitoring',
    description: 'Demo data only. Replace backend dummy SPL with your approved Splunk queries.',
    environment, timeRange,
    panels: [
      panel('authentication-service-calls','Authentication Service Calls','Dummy query representing high-level authentication service calls.',[
        {label:'Portal authentication launch',count:298,action:'DRILLDOWN',severity:'INFO'},
        {label:'Partner identity request',count:137,action:'DRILLDOWN',severity:'INFO'},
        {label:'Login service exceptions',count:6,action:'INVESTIGATE',investigationCategory:'LOGIN_SERVICE_EXCEPTION',severity:'HIGH'}]),
      panel('idp-authentication-calls','Authentication Calls in IDP','Dummy query representing request/success/failure/transmit/cache activity.',[
        {label:'Authentication requests',count:119,action:'DRILLDOWN',severity:'INFO'},
        {label:'IDP success responses',count:116,action:'DRILLDOWN',severity:'INFO'},
        {label:'IDP failure responses',count:3,action:'INVESTIGATE',investigationCategory:'IDP_FAILURE_RESPONSE',severity:'CRITICAL'},
        {label:'Transmit requests',count:112,action:'DRILLDOWN',severity:'INFO'},
        {label:'Session-cache exceptions',count:1,action:'INVESTIGATE',investigationCategory:'SESSION_CACHE_EXCEPTION',severity:'HIGH'}]),
      panel('login-user-authentication','Login Service User Authentication','Dummy query representing login outcomes.',[
        {label:'User login requests',count:121,action:'DRILLDOWN',severity:'INFO'},
        {label:'Database success responses',count:113,action:'DRILLDOWN',severity:'INFO'},
        {label:'Invalid user',count:7,action:'DRILLDOWN',investigationCategory:'INVALID_USER',severity:'WARNING'},
        {label:'Unhandled exceptions',count:2,action:'INVESTIGATE',investigationCategory:'LOGIN_EXCEPTION',severity:'HIGH'}]),
      panel('portal-launch','IDP Launch in Portal','Dummy query representing portal launch and OAuth activity.',[
        {label:'IDP launches in portal',count:140,action:'DRILLDOWN',severity:'INFO'},
        {label:'IDP launch successful',count:138,action:'DRILLDOWN',severity:'INFO'},
        {label:'Portal session not found',count:2,action:'INVESTIGATE',investigationCategory:'SESSION_NOT_FOUND',severity:'HIGH'},
        {label:'OAuth exceptions',count:1,action:'INVESTIGATE',investigationCategory:'OAUTH_EXCEPTION',severity:'CRITICAL'}]),
      panel('partner-identity','Partner Identity Calls','Dummy query representing partner identity traffic.',[
        {label:'Partner identity requests',count:420,action:'DRILLDOWN',severity:'INFO'},
        {label:'Partner identity responses',count:416,action:'DRILLDOWN',severity:'INFO'},
        {label:'Partner identity failures',count:4,action:'INVESTIGATE',investigationCategory:'PARTNER_IDENTITY_FAILURE',severity:'HIGH'}])
    ]
  };
}
