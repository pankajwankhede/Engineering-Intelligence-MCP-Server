import type { InvestigationResult } from '../types';

export const demoInvestigation: InvestigationResult = {
  investigationId: 'INV-20260816-10021',
  status: 'COMPLETED',
  entryService: 'service-a',
  trackingId: 'TRK-829372',
  requestId: 'REQ-1001',
  traceId: 'a1b2c3d4e5f6g7h88',
  environment: 'PRODUCTION',
  timeRange: '2h',
  traversalOrder: ['service-a', 'service-b', 'service-c'],
  serviceFlow: [
    {
      service: 'service-a', team: 'Platform-A-Team', businessDomain: 'Payments', repository: 'PROJA/service-a', status: 'IMPACTED', issueFound: false,
      callers: ['PaymentController.pay()', 'PaymentService.submit()'],
      apiEndpoints: ['POST /api/v1/payments/process'], consumers: ['mobile-bff', 'checkout-service'], downstreamServices: ['service-b']
    },
    {
      service: 'service-b', team: 'Platform-B-Team', businessDomain: 'Customer', repository: 'PROJB/service-b', status: 'IMPACTED', issueFound: false,
      callers: ['PaymentClient.callServiceB()', 'ServiceBClient.process()'], apiEndpoints: ['GET /service-b/api/v1/accounts/{id}'], consumers: ['service-a'], downstreamServices: ['service-c']
    },
    {
      service: 'service-c', team: 'Platform-C-Team', businessDomain: 'Accounts', repository: 'PROJC/service-c', status: 'FAILED', issueFound: true,
      failure: { exception: 'SQLTimeoutException', className: 'AccountRepository', methodName: 'findAccount', fileName: 'AccountRepository.java', lineNumber: 211 },
      componentAnalysis: { classPurpose: 'Reads account data and maps database records into domain objects.', methodPurpose: 'Fetches a single account by account ID and returns the mapped account.', issueFound: true, issue: 'Database query exceeds the configured timeout under load.' },
      callers: ['AccountService.getAccount()', 'ServiceCController.getAccount()'], apiEndpoints: ['GET /service-c/api/v1/accounts/{id}'], consumers: ['service-b', 'admin-portal'], downstreamServices: []
    }
  ],
  rootCause: {
    service: 'service-c', ownerTeam: 'Platform-C-Team', repository: 'PROJC/service-c', className: 'AccountRepository', methodName: 'findAccount', lineNumber: 211,
    reason: 'SQLTimeoutException in AccountRepository.findAccount(); query execution exceeds 30 seconds during elevated database load.', confidence: 0.91
  },
  impactedTeams: ['Platform-A-Team', 'Platform-B-Team', 'Platform-C-Team'],
  recentChanges: [{
    commit: 'e539dc2', author: 'developer1', timestamp: '2026-08-16T16:32:00Z', message: 'Handle account query timeout and add retry logic', correlation: 'HIGH', risk: 'HIGH', totalResources: 8, incidentRelatedResources: 3,
    resourceTypeCounts: { JAVA_CLASS: 2, CONFIG: 2, TEST: 1, API_SPEC: 1, BUILD: 1, DOCUMENTATION: 1 },
    resources: [
      { path: 'src/main/java/com/company/account/repository/AccountRepository.java', type: 'JAVA_CLASS', relevance: 'HIGH', incidentRelated: true, additions: 18, deletions: 6 },
      { path: 'src/main/java/com/company/account/service/AccountService.java', type: 'JAVA_CLASS', relevance: 'MEDIUM', incidentRelated: true, additions: 7, deletions: 2 },
      { path: 'src/main/resources/application.yml', type: 'CONFIG', relevance: 'HIGH', incidentRelated: true, additions: 3, deletions: 1 },
      { path: 'src/test/java/com/company/account/AccountRepositoryTest.java', type: 'TEST', relevance: 'LOW', incidentRelated: false, additions: 28, deletions: 0 },
      { path: 'openapi/account-api.yaml', type: 'API_SPEC', relevance: 'LOW', incidentRelated: false, additions: 4, deletions: 1 },
      { path: 'build.gradle', type: 'BUILD', relevance: 'LOW', incidentRelated: false, additions: 1, deletions: 1 },
      { path: 'config/account-prod.yml', type: 'CONFIG', relevance: 'MEDIUM', incidentRelated: false, additions: 2, deletions: 1 },
      { path: 'README.md', type: 'DOCUMENTATION', relevance: 'LOW', incidentRelated: false, additions: 5, deletions: 0 }
    ]
  }],
  recommendations: [
    'Add database query timeout handling and bounded retry behavior.',
    'Create an index or optimize the account lookup query after DBA validation.',
    'Add a regression test for the timeout scenario.',
    'Monitor query latency and connection-pool pressure.',
    'Improve downstream timing fields in structured logs.'
  ]
};

export const demoLogs = [
  ['10:01:13.012', 'service-a', 'INFO', 'Received POST /api/v1/payments/process', 'TRK-829372'],
  ['10:01:13.132', 'service-a', 'INFO', 'Calling service-b account endpoint', 'TRK-829372'],
  ['10:01:13.450', 'service-b', 'INFO', 'Calling service-c GET /accounts/123', 'TRK-829372'],
  ['10:01:15.790', 'service-c', 'ERROR', 'SQLTimeoutException: Query timed out after 30,000 ms', 'TRK-829372'],
  ['10:01:15.801', 'service-b', 'WARN', 'Downstream service-c responded with 500', 'TRK-829372'],
  ['10:01:15.812', 'service-a', 'ERROR', 'Payment request failed because account lookup failed', 'TRK-829372']
];
