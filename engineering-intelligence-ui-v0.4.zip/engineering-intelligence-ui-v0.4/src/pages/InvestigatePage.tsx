import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '../components/Ui';
import { startInvestigation } from '../services/api';
import { useInvestigation } from '../state';
import type { InvestigationRequest } from '../types';

const fields = [
  ['trackingId', 'Tracking ID', 'TRK-829372'], ['requestId', 'Request ID', 'REQ-1001'], ['traceId', 'Trace ID', 'trace/span identifier'],
  ['service', 'Service', 'optional service name'], ['apiUrl', 'API URL', '/api/v1/payments'], ['errorOrException', 'Error / Exception', 'SQLTimeoutException']
] as const;

export function InvestigatePage() {
  const [mode, setMode] = useState('trackingId');
  const [form, setForm] = useState<InvestigationRequest>({ environment: 'PRODUCTION', timeRange: '2h', trackingId: 'TRK-829372' });
  const [loading, setLoading] = useState(false);
  const { setResult } = useInvestigation();
  const navigate = useNavigate();

  const update = (key: keyof InvestigationRequest, value: string) => setForm(prev => ({ ...prev, [key]: value }));
  const submit = async () => {
    setLoading(true);
    navigate('/progress');
    const result = await startInvestigation(form);
    setResult(result);
    setTimeout(() => navigate('/overview'), 850);
  };

  return <div className="page narrow-page">
    <div className="page-heading"><div><h1>Start a New Investigation</h1><p>Provide whatever you know. EIPA discovers services and traces the root cause.</p></div></div>
    <Card>
      <div className="tabs">{fields.map(([key, label]) => <button key={key} className={mode === key ? 'tab active' : 'tab'} onClick={() => setMode(key)}>{label}</button>)}<button className={mode === 'description' ? 'tab active' : 'tab'} onClick={() => setMode('description')}>Natural Language</button></div>
      <div className="form-grid">
        {mode === 'description' ? <label className="field span-2"><span>Describe the problem</span><textarea value={form.description || ''} onChange={e => update('description', e.target.value)} placeholder="Customers are getting payment failures since 10 AM. Find the root cause." /></label> : (() => {
          const field = fields.find(f => f[0] === mode)!;
          return <label className="field span-2"><span>{field[1]}</span><input value={(form as any)[field[0]] || ''} onChange={e => update(field[0], e.target.value)} placeholder={field[2]} /></label>;
        })()}
        <label className="field"><span>Environment</span><select value={form.environment} onChange={e => update('environment', e.target.value)}><option>PRODUCTION</option><option>UAT</option><option>QA</option><option>DEV</option></select></label>
        <label className="field"><span>Time Range</span><select value={form.timeRange} onChange={e => update('timeRange', e.target.value)}><option value="30m">Last 30 Minutes</option><option value="1h">Last 1 Hour</option><option value="2h">Last 2 Hours</option><option value="6h">Last 6 Hours</option><option value="24h">Last 24 Hours</option></select></label>
      </div>
      <div className="what-next"><b>What happens next?</b><ol><li>Search bounded Splunk data.</li><li>Discover entry and downstream services.</li><li>Switch to each mapped Bitbucket repository.</li><li>Analyze code, callers, APIs, consumers and changes.</li><li>Return evidence-backed root cause and blast radius.</li></ol></div>
      <button className="primary-button" onClick={submit} disabled={loading}>{loading ? 'Starting…' : '▶ Start Investigation'}</button>
    </Card>
  </div>;
}
