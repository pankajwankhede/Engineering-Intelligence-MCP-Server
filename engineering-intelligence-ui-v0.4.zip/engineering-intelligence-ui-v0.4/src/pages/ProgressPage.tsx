import { Card, Badge } from '../components/Ui';

export function ProgressPage() {
  const steps = [['Collecting Logs', 'done'], ['Discovering Services', 'active'], ['Analyzing Code', 'pending'], ['Building Impact', 'pending'], ['Generating RCA', 'pending']];
  return <div className="page narrow-page"><div className="page-heading"><div><h1>Investigation in Progress…</h1><p>EIPA is correlating logs, service flow and source code.</p></div></div>
    <Card><div className="stepper">{steps.map(([name, state], i) => <div className={`step ${state}`} key={name}><div className="step-circle">{state === 'done' ? '✓' : i + 1}</div><b>{name}</b><span>{state === 'done' ? 'Completed' : state === 'active' ? 'In progress' : 'Pending'}</span></div>)}</div></Card>
    <Card title="Discovering services from logs"><div className="discovered"><div>service-a <Badge tone="green">ENTRY SERVICE</Badge></div><div>service-b <Badge>DOWNSTREAM</Badge></div><div className="scanner">Searching additional correlated events…</div></div></Card>
  </div>;
}
