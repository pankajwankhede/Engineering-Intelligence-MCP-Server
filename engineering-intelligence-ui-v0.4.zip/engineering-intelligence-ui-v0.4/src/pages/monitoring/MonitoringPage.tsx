import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Badge, Card } from '../../components/Ui';
import { getMonitoringDashboard, investigateMonitoringMetric } from '../../services/api';
import { useInvestigation } from '../../state';
import type { MonitoringDashboard, MonitoringPanel, MonitoringRow } from '../../types';

function tone(severity: string): 'red' | 'orange' | 'green' | 'blue' | 'purple' {
  if (severity === 'CRITICAL') return 'red';
  if (severity === 'HIGH' || severity === 'WARNING') return 'orange';
  if (severity === 'INFO') return 'blue';
  return 'green';
}

export function MonitoringPage() {
  const [environment, setEnvironment] = useState('PRODUCTION');
  const [timeRange, setTimeRange] = useState('15m');
  const [dashboard, setDashboard] = useState<MonitoringDashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<{panel: MonitoringPanel; row: MonitoringRow} | null>(null);
  const [investigating, setInvestigating] = useState(false);
  const { setResult } = useInvestigation();
  const navigate = useNavigate();

  const load = async () => {
    setLoading(true);
    setDashboard(await getMonitoringDashboard(environment, timeRange));
    setLoading(false);
  };
  useEffect(() => { load(); }, [environment, timeRange]);

  const summary = useMemo(() => {
    const rows = dashboard?.panels.flatMap(p => p.rows) || [];
    const failures = rows.filter(r => r.action === 'INVESTIGATE' && r.count > 0);
    return {
      panels: dashboard?.panels.length || 0,
      metrics: rows.length,
      actionable: failures.length,
      totalFailures: failures.reduce((a, r) => a + r.count, 0)
    };
  }, [dashboard]);

  const openRow = (panel: MonitoringPanel, row: MonitoringRow) => {
    if (row.count <= 0) return;
    setSelected({panel, row});
  };

  const investigate = async () => {
    if (!dashboard || !selected) return;
    setInvestigating(true);
    const result = await investigateMonitoringMetric({
      dashboardId: dashboard.dashboardId,
      panelId: selected.panel.panelId,
      row: selected.row,
      environment,
      timeRange
    });
    setResult(result);
    setInvestigating(false);
    setSelected(null);
    navigate('/overview');
  };

  return <div className="page monitoring-page">
    <div className="page-heading">
      <div><h1>Monitoring <span className="breadcrumb">/ SSO IDP Login Dashboard</span></h1><p>Reuse approved Splunk monitoring queries and launch EIPA directly from actionable failure metrics.</p></div>
      <div className="monitor-controls">
        <select value={environment} onChange={e => setEnvironment(e.target.value)}><option>PRODUCTION</option><option>UAT</option><option>QA</option></select>
        <select value={timeRange} onChange={e => setTimeRange(e.target.value)}><option value="15m">Last 15 Minutes</option><option value="30m">Last 30 Minutes</option><option value="1h">Last 1 Hour</option><option value="2h">Last 2 Hours</option></select>
        <button onClick={load}>↻ Refresh</button>
      </div>
    </div>

    <div className="demo-notice"><b>Demo safety:</b> this project contains only dummy SPL. Replace query definitions on the backend with your approved existing Splunk queries or saved-search references.</div>

    <div className="metrics-grid four monitoring-summary">
      <Card><div className="metric-label">Dashboard Panels</div><div className="metric-value">{summary.panels}</div><div className="metric-detail">Configured monitoring panels</div></Card>
      <Card><div className="metric-label">Metrics</div><div className="metric-value">{summary.metrics}</div><div className="metric-detail">Rows returned by approved searches</div></Card>
      <Card className="tone-red"><div className="metric-label">Actionable Failures</div><div className="metric-value">{summary.actionable}</div><div className="metric-detail">Clickable investigation categories</div></Card>
      <Card className="tone-orange"><div className="metric-label">Failure Events</div><div className="metric-value">{summary.totalFailures}</div><div className="metric-detail">Across actionable rows</div></Card>
    </div>

    {loading ? <Card><div className="empty">Loading monitoring panels…</div></Card> : <div className="monitor-panel-grid">
      {dashboard?.panels.map(panel => <Card key={panel.panelId} title={panel.title} className="monitor-panel">
        <div className="panel-description">{panel.description}</div>
        <div className="query-ref">Query ref: <code>{panel.queryReference}</code></div>
        <table className="monitor-table"><thead><tr><th>#</th><th>Metric</th><th>Count</th><th>Action</th></tr></thead><tbody>
          {panel.rows.map((row, idx) => <tr key={row.label} className={row.action === 'INVESTIGATE' && row.count > 0 ? 'clickable-failure' : ''} onClick={() => openRow(panel,row)}>
            <td>{idx + 1}</td><td>{row.label}</td><td><b>{row.count}</b></td><td><Badge tone={tone(row.severity)}>{row.action === 'INVESTIGATE' ? 'Investigate' : row.action === 'DRILLDOWN' ? 'Drilldown' : 'Metric'}</Badge></td>
          </tr>)}
        </tbody></table>
      </Card>)}
    </div>}

    <div className="monitor-bottom-grid">
      <Card title="Failure Trend"><div className="fake-chart"><span style={{height:'22%'}}/><span style={{height:'30%'}}/><span style={{height:'27%'}}/><span style={{height:'45%'}}/><span style={{height:'38%'}}/><span style={{height:'61%'}}/><span style={{height:'43%'}}/><span style={{height:'78%'}}/><span style={{height:'51%'}}/><span style={{height:'88%'}}/><span style={{height:'60%'}}/></div><div className="metric-detail">Sample visualization only. Drive this from your timechart SPL.</div></Card>
      <Card title="Recent Alerts"><div className="alert-row critical"><b>Critical</b><span>IDP failure response spike detected</span><small>Clickable failure metric can launch EIPA</small></div><div className="alert-row warning"><b>Warning</b><span>Login exceptions above threshold</span><small>Review trend and affected transactions</small></div><div className="alert-row info"><b>Info</b><span>Monitoring query refresh completed</span><small>Source: Splunk</small></div></Card>
    </div>

    {selected && <div className="investigation-overlay" onClick={() => !investigating && setSelected(null)}>
      <aside className="investigation-drawer" onClick={e => e.stopPropagation()}>
        <button className="drawer-close" onClick={() => setSelected(null)}>×</button>
        <div className="drawer-kicker">Investigation Mode</div>
        <h2>{selected.row.label}</h2>
        <Badge tone={tone(selected.row.severity)}>{selected.row.severity}</Badge>
        <dl className="drawer-details"><dt>Count</dt><dd>{selected.row.count}</dd><dt>Panel</dt><dd>{selected.panel.title}</dd><dt>Environment</dt><dd>{environment}</dd><dt>Time Range</dt><dd>{timeRange}</dd><dt>Category</dt><dd>{selected.row.investigationCategory || 'General drilldown'}</dd></dl>
        <Card title="What happens next?"><ol className="recommend-list"><li>Run a bounded detail search for matching failed events.</li><li>Extract tracking/request/trace IDs.</li><li>Discover the affected service flow.</li><li>Correlate Splunk evidence with mapped Bitbucket code.</li><li>Analyze class, method, callers, API consumers and recent changes.</li><li>Open the full EIPA RCA report.</li></ol></Card>
        {selected.row.action === 'INVESTIGATE' ? <button className="primary-button drawer-action" onClick={investigate} disabled={investigating}>{investigating ? 'Investigating…' : 'Investigate with EIPA →'}</button> : <button className="primary-button drawer-action" onClick={() => navigate('/logs')}>Open Drilldown →</button>}
      </aside>
    </div>}
  </div>;
}
