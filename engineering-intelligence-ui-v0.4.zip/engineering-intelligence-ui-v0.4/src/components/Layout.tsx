import { NavLink, Outlet, useNavigate } from 'react-router-dom';

const nav = [
  ['/', 'Monitoring'], ['/overview', 'Investigation Overview'], ['/investigate', 'Start Investigation'], ['/service-flow', 'Service Flow'], ['/logs', 'Logs & Trace'],
  ['/code', 'Code Analysis'], ['/call-flow', 'Call Flow'], ['/consumers', 'API & Consumers'], ['/changes', 'Recent Changes'],
  ['/blast-radius', 'Blast Radius'], ['/timeline', 'Evidence Timeline'], ['/recommendations', 'Recommendations'],
  ['/similar', 'Similar Incidents'], ['/reports', 'Reports'], ['/settings', 'Settings']
];

export function Layout() {
  const navigate = useNavigate();
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-logo">AI</div><div><strong>Engineering Intelligence</strong><small>Monitoring + Investigation</small></div></div>
      <nav>{nav.map(([path, label]) => <NavLink key={path} to={path} end={path === '/'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>{label}</NavLink>)}</nav>
      <div className="side-tip"><b>Investigation Tips</b><span>Provide any ID, service, API, exception, or plain-English symptom.</span></div>
    </aside>
    <main className="main-area">
      <header className="topbar">
        <button className="mobile-brand" onClick={() => navigate('/')}>AI</button>
        <div className="global-search">⌕ <input placeholder="Search Request ID, Tracking ID, Service, Error..." /></div>
        <div className="top-actions"><span className="status-dot" /> Platform Online <div className="avatar">AD</div></div>
      </header>
      <div className="content"><Outlet /></div>
    </main>
  </div>;
}
