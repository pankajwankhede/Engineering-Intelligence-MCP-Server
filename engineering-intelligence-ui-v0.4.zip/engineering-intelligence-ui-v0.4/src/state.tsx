import { createContext, useContext, useState, type ReactNode } from 'react';
import { demoInvestigation } from './data/demo';
import type { InvestigationResult } from './types';

interface InvestigationContextValue {
  result: InvestigationResult;
  setResult: (result: InvestigationResult) => void;
}

const InvestigationContext = createContext<InvestigationContextValue | undefined>(undefined);

export function InvestigationProvider({ children }: { children: ReactNode }) {
  const [result, setResult] = useState<InvestigationResult>(demoInvestigation);
  return <InvestigationContext.Provider value={{ result, setResult }}>{children}</InvestigationContext.Provider>;
}

export function useInvestigation() {
  const context = useContext(InvestigationContext);
  if (!context) throw new Error('useInvestigation must be used inside InvestigationProvider');
  return context;
}
