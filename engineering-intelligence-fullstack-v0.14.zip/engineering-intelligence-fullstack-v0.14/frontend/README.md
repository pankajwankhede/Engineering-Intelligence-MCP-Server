# Engineering Intelligence UI v0.14

This corrected package contains separate page files under `src/pages` for every sidebar item.

## Run
```bash
npm install
npm run dev
```

## Demo mode
`.env`:
```env
VITE_DEMO_MODE=true
VITE_API_BASE_URL=http://localhost:8080
```

Switch `VITE_DEMO_MODE=false` to call the real Spring Boot backend.
