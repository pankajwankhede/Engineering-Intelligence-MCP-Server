import { Search } from 'lucide-react'
import type { ReactNode } from 'react'

export function Card({title, children}:{title:string; children:ReactNode}) { return <section className="card"><div className="card-title">{title}</div>{children}</section> }
export function Metric({label,value}:{label:string;value:string}) { return <div className="metric"><span>{label}</span><strong>{value}</strong></div> }
export function Info({title,text}:{title:string;text:string}) { return <div className="info"><strong>{title}</strong><p>{text}</p></div> }
export function Table({headers,rows}:{headers:string[];rows:string[][]}) { return <div className="table"><div className="tr head">{headers.map(h=><span key={h}>{h}</span>)}</div>{rows.map((r,i)=><div className="tr" key={i}>{r.map((c,j)=><span key={j}>{c}</span>)}</div>)}</div> }
export function Bars({values}:{values:number[]}) { const max=Math.max(...values,1); return <div className="bars">{values.map((v,i)=><div key={i} style={{height:`${Math.max(8,(v/max)*100)}%`}}><span>{v}</span></div>)}</div> }
export function Empty() { return <div className="empty"><Search size={30}/><h2>No investigation loaded</h2><p>Start an investigation first. In demo mode no backend is required.</p></div> }
