export type Page =
  | 'overview' | 'start' | 'serviceFlow' | 'logs' | 'code' | 'callFlow'
  | 'api' | 'database' | 'runtime' | 'monitoring' | 'changes' | 'blastRadius'
  | 'timeline' | 'recommendations' | 'similarIncidents' | 'reports'
  | 'integrations' | 'settings'

export const pageTitle = (page: Page) => ({
  overview: 'Investigation Overview',
  start: 'Start Investigation',
  serviceFlow: 'Service Flow',
  logs: 'Logs & Trace',
  code: 'Code Analysis',
  callFlow: 'Call Flow',
  api: 'API & Consumers',
  database: 'Database Analysis',
  runtime: 'PCF / Runtime',
  monitoring: 'New Relic / Monitoring',
  changes: 'Recent Changes',
  blastRadius: 'Blast Radius',
  timeline: 'Evidence Timeline',
  recommendations: 'Recommendations',
  similarIncidents: 'Similar Incidents',
  reports: 'Reports',
  integrations: 'Integrations',
  settings: 'Settings',
})[page]
