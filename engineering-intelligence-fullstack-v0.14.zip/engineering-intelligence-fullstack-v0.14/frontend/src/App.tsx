import { useEffect, useState } from 'react'
import { Activity, AlertTriangle, Boxes, Code2, Database, FileClock, FileText, Gauge, GitBranch, Network, PlayCircle, Radar, Search, ServerCog, Settings, Sparkles, Waypoints } from 'lucide-react'
import { DEMO_CONFIG } from './config/demo'
import { getDatabaseAnalysis, getIntegrations, getMonitoringAnalysis, getPlatformStatus, getRuntimeAnalysis, startInvestigation } from './api/platformApi'
import type { DatabaseAnalysis, IntegrationItem, InvestigationResult, MonitoringAnalysis, PlatformStatus, RuntimeAnalysis } from './types'
import type { Page } from './navigation'
import { pageTitle } from './navigation'
import StartInvestigationPage from './pages/StartInvestigationPage'
import InvestigationOverviewPage from './pages/InvestigationOverviewPage'
import ServiceFlowPage from './pages/ServiceFlowPage'
import LogsTracePage from './pages/LogsTracePage'
import CodeAnalysisPage from './pages/CodeAnalysisPage'
import CallFlowPage from './pages/CallFlowPage'
import ApiConsumersPage from './pages/ApiConsumersPage'
import DatabaseAnalysisPage from './pages/DatabaseAnalysisPage'
import RuntimePage from './pages/RuntimePage'
import MonitoringPage from './pages/MonitoringPage'
import RecentChangesPage from './pages/RecentChangesPage'
import BlastRadiusPage from './pages/BlastRadiusPage'
import EvidenceTimelinePage from './pages/EvidenceTimelinePage'
import RecommendationsPage from './pages/RecommendationsPage'
import SimilarIncidentsPage from './pages/SimilarIncidentsPage'
import ReportsPage from './pages/ReportsPage'
import IntegrationsPage from './pages/IntegrationsPage'
import SettingsPage from './pages/SettingsPage'

type NavItem={page:Page;label:string;icon:any;isNew?:boolean}
const nav:NavItem[]=[
 {page:'overview',label:'Investigation Overview',icon:Gauge},{page:'start',label:'Start Investigation',icon:Search},
 {page:'serviceFlow',label:'Service Flow',icon:Waypoints},{page:'logs',label:'Logs & Trace',icon:FileText},{page:'code',label:'Code Analysis',icon:Code2},{page:'callFlow',label:'Call Flow',icon:PlayCircle},{page:'api',label:'API & Consumers',icon:Network},
 {page:'database',label:'Database Analysis',icon:Database,isNew:true},{page:'runtime',label:'PCF / Runtime',icon:ServerCog,isNew:true},{page:'monitoring',label:'New Relic / Monitoring',icon:Activity,isNew:true},
 {page:'changes',label:'Recent Changes',icon:FileClock},{page:'blastRadius',label:'Blast Radius',icon:Radar},{page:'timeline',label:'Evidence Timeline',icon:GitBranch},{page:'recommendations',label:'Recommendations',icon:Sparkles},{page:'similarIncidents',label:'Similar Incidents',icon:FileText},{page:'reports',label:'Reports',icon:FileText},{page:'integrations',label:'Integrations',icon:Boxes,isNew:true},{page:'settings',label:'Settings',icon:Settings},
]
const emptyStatus:PlatformStatus={backend:'HEALTHY',mode:DEMO_CONFIG.enabled?'DEMO':'LIVE',splunk:'DISABLED',bitbucket:'DISABLED',newRelic:'DISABLED',pcf:'DISABLED',oracle:'DISABLED',sqlServer:'DISABLED',llmGateway:'DISABLED'}

export default function App(){
 const[page,setPage]=useState<Page>('start');const[query,setQuery]=useState('Find NullPointerException in bc-login-service');const[environment,setEnvironment]=useState('PRODUCTION');const[timeRange,setTimeRange]=useState('Last 2 Hours');const[loading,setLoading]=useState(false);const[error,setError]=useState('');const[status,setStatus]=useState<PlatformStatus>(emptyStatus);const[investigation,setInvestigation]=useState<InvestigationResult|null>(null);const[database,setDatabase]=useState<DatabaseAnalysis|null>(null);const[monitoring,setMonitoring]=useState<MonitoringAnalysis|null>(null);const[runtime,setRuntime]=useState<RuntimeAnalysis|null>(null);const[integrations,setIntegrations]=useState<IntegrationItem[]>([])
 useEffect(()=>{getPlatformStatus().then(setStatus).catch(()=>setStatus({...emptyStatus,backend:'DEGRADED'}))},[])
 async function runInvestigation(){setLoading(true);setError('');try{const inv=await startInvestigation({query,environment,timeRange});setInvestigation(inv);const[db,mon,run,ints]=await Promise.all([getDatabaseAnalysis(inv.investigationId),getMonitoringAnalysis(inv.investigationId),getRuntimeAnalysis(inv.investigationId),getIntegrations()]);setDatabase(db);setMonitoring(mon);setRuntime(run);setIntegrations(ints);setPage('overview')}catch(e){setError(e instanceof Error?e.message:'Investigation failed')}finally{setLoading(false)}}
 useEffect(()=>{if(page==='integrations'&&!integrations.length)getIntegrations().then(setIntegrations).catch(()=>{})},[page,integrations.length])
 const shared={investigation}
 return <div className="app-shell"><aside className="sidebar"><div className="brand"><div className="brand-mark">EI</div><div><strong>Engineering Intelligence</strong><span>Monitoring + Investigation</span></div></div><div className="side-section">INVESTIGATION</div><nav>{nav.map(item=>{const Icon=item.icon;return <button key={item.page} className={page===item.page?'nav-item active':'nav-item'} onClick={()=>setPage(item.page)}><Icon size={17}/><span>{item.label}</span>{item.isNew&&<em>NEW</em>}</button>})}</nav><div className="sidebar-bottom"><Settings size={16}/> Engineering Intelligence<div className="version">EIPA v0.14.0</div></div></aside><main><header className="topbar"><div className="top-title"><strong>{pageTitle(page)}</strong><span>{investigation?investigation.investigationId:'Ready for investigation'}</span></div><div className="statuses"><Status label="Backend" value={status.backend}/><Status label="Splunk" value={status.splunk}/><Status label="New Relic" value={status.newRelic}/><Status label="PCF" value={status.pcf}/><span className={DEMO_CONFIG.enabled?'mode demo':'mode live'}>{DEMO_CONFIG.enabled?'DEMO MODE':'LIVE BACKEND'}</span></div></header><section className="content">{error&&<div className="error-banner"><AlertTriangle size={18}/>{error}</div>}
 {page==='start'&&<StartInvestigationPage query={query} setQuery={setQuery} environment={environment} setEnvironment={setEnvironment} timeRange={timeRange} setTimeRange={setTimeRange} loading={loading} run={runInvestigation}/>} {page==='overview'&&<InvestigationOverviewPage investigation={investigation} monitoring={monitoring} runtime={runtime}/>} {page==='serviceFlow'&&<ServiceFlowPage {...shared}/>} {page==='logs'&&<LogsTracePage {...shared}/>} {page==='code'&&<CodeAnalysisPage {...shared}/>} {page==='callFlow'&&<CallFlowPage {...shared}/>} {page==='api'&&<ApiConsumersPage {...shared}/>} {page==='database'&&<DatabaseAnalysisPage data={database}/>} {page==='runtime'&&<RuntimePage data={runtime}/>} {page==='monitoring'&&<MonitoringPage data={monitoring}/>} {page==='changes'&&<RecentChangesPage {...shared}/>} {page==='blastRadius'&&<BlastRadiusPage {...shared}/>} {page==='timeline'&&<EvidenceTimelinePage {...shared}/>} {page==='recommendations'&&<RecommendationsPage {...shared}/>} {page==='similarIncidents'&&<SimilarIncidentsPage {...shared}/>} {page==='reports'&&<ReportsPage {...shared}/>} {page==='integrations'&&<IntegrationsPage data={integrations}/>} {page==='settings'&&<SettingsPage {...shared}/>}</section></main></div>
}
function Status({label,value}:{label:string;value:string}){return <div className="status"><i className={value==='ERROR'||value==='DEGRADED'?'bad':''}/><span>{label}</span><b>{value}</b></div>}
