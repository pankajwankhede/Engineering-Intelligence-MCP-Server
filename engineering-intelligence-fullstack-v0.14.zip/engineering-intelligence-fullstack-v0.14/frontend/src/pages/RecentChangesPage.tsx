import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function RecentChangesPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Recent Changes"><ul className="generic-list"><li>10:19 Deployment completed for bc-login-service</li><li>Commit abc123 modified UserService null-handling path</li><li>No database schema deployment detected in selected time range</li></ul></Card></div>}
