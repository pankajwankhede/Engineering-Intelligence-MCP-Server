import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function ServiceFlowPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Service Flow"><ul className="generic-list"><li>bc-web → bc-login-service → customer-profile-service</li><li>Trace correlation across service boundaries</li><li>Runtime and database nodes included in investigation graph</li></ul></Card></div>}
