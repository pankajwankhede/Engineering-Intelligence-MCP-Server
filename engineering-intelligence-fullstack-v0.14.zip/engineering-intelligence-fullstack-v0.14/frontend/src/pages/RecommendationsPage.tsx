import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function RecommendationsPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Recommendations"><ul className="generic-list"><li>Add null guard before customer.getProfile().getAddress()</li><li>Add unit test for missing customer profile</li><li>Review data integrity for CUSTOMER_PROFILE</li><li>Monitor login error rate after fix</li></ul></Card></div>}
