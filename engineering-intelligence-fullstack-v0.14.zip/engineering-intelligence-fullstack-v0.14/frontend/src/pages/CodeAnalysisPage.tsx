import { Card, Empty } from '../components/ui'
import type { InvestigationResult } from '../types'
export default function CodeAnalysisPage({investigation}:{investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;return <div className="page"><Card title="Code Analysis"><ul className="generic-list"><li>UserService.java:187 candidate null dereference</li><li>Repository analysis via Bitbucket MCP / REST connector</li><li>Recent change correlation attached to the evidence model</li></ul></Card></div>}
