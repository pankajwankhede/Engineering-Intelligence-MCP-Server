# Engineering Intelligence Full Stack v0.14

- `frontend/` corrected React/Vite UI with separate files for every page.
- `backend/` Spring Boot backend from v0.13.
- Frontend demo/live switching is controlled by `VITE_DEMO_MODE`.
