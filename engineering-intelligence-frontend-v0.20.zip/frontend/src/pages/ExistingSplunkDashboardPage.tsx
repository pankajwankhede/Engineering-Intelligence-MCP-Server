import type {MonitoringDashboardDefinition,MonitoringDashboardSummary,ConfiguredPanelResult,AppSelection} from '../types';
import {Action,Card,Metric,MiniLine} from '../components/ui';
import type {Page} from '../navigation';

export default function ExistingSplunkDashboardPage({dashboard,dashboards,selectedDashboardId,onDashboardChange,panels,selection,onSelect,environment,setEnvironment,timeRange,setTimeRange,onLoad,loading,onNavigate}:{dashboard:MonitoringDashboardDefinition|null;dashboards:MonitoringDashboardSummary[];selectedDashboardId:string;onDashboardChange:(id:string)=>void;panels:Record<string,ConfiguredPanelResult>;selection:AppSelection;onSelect:(s:Partial<AppSelection>)=>void;environment:string;setEnvironment:(v:string)=>void;timeRange:string;setTimeRange:(v:string)=>void;onLoad:()=>void;loading:boolean;onNavigate:(p:Page)=>void}){
  return <div className="page">
    <div className="page-heading"><div><h1>Existing Splunk Dashboard</h1><p>Select a configured dashboard and filters. Backend/Splunk is called only when <b>Load Dashboard</b> is clicked.</p></div></div>
    <div className="splunk-load-toolbar">
      <label>Dashboard<select value={selectedDashboardId} onChange={e=>onDashboardChange(e.target.value)}>{dashboards.map(d=><option key={d.id} value={d.id}>{d.title}</option>)}</select></label>
      <label>Service<select value={selection.service} onChange={e=>onSelect({service:e.target.value})}><option value="ALL">All Services</option><option>bc-login-service</option><option>customer-profile-service</option><option>notification-service</option><option>payment-service</option><option>audit-service</option></select></label>
      <label>Environment<select value={environment} onChange={e=>setEnvironment(e.target.value)}><option>PRODUCTION</option><option>QA</option><option>DEV</option></select></label>
      <label>Time Range<select value={timeRange} onChange={e=>setTimeRange(e.target.value)}><option>Last 15 Minutes</option><option>Last 1 Hour</option><option>Last 2 Hours</option><option>Last 24 Hours</option></select></label>
      <Action onClick={onLoad}>{loading?'Loading...':'Load Dashboard'}</Action>
    </div>
    {dashboard?<><div className="info-note loaded-context"><b>Loaded:</b> {dashboard.title} · Service: {Object.values(panels)[0]?.service??'Not loaded'} · Environment: {Object.values(panels)[0]?.environment??'Not loaded'} · Time: {Object.values(panels)[0]?.timeRange??'Not loaded'}</div>
    <div className="configured-grid">{dashboard.panels.map(def=>{const r=panels[def.id];return <Card key={def.id} title={def.title}><div className="panel-metrics">{(r?.metrics??[]).map(m=><Metric key={m.label} label={m.label} value={m.value} tone={m.tone}/>)}</div><MiniLine values={r?.trend??[2,4,3,5,6,5]}/><div className="card-footer"><Action secondary onClick={()=>{onSelect({panelId:def.id});onNavigate('splunkPanelDetail')}}>View Details</Action><Action onClick={()=>{onSelect({panelId:def.id});onNavigate('splunkFailures')}}>Investigate Failures</Action></div></Card>})}</div></>:<div className="empty"><h2>Select dashboard and click Load Dashboard</h2></div>}
    <div className="info-note">No automatic query on dropdown change. Load Dashboard commits the selected dashboard/service/environment/time range and then calls the backend.</div>
  </div>
}
