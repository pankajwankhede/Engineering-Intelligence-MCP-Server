# v0.11 Monitoring All-Panels Update

Adds an explicit all-panels endpoint:

`GET /api/monitoring/dashboards/{dashboardId}/panels?environment=&timeRange=15m`

It returns the same normalized `MonitoringDashboardResponse` as the dashboard endpoint, containing all configured panel results. Existing specific-panel and investigation endpoints remain unchanged.
