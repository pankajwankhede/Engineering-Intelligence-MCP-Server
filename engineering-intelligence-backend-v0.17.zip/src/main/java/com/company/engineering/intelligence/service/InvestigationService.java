package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.model.Models.*;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class InvestigationService {
    private final LlmGateway llmGateway; private final AtomicInteger counter=new AtomicInteger(17);
    public InvestigationService(LlmGateway llmGateway){this.llmGateway=llmGateway;}
    public InvestigationResult start(InvestigationRequest request){Interpretation p=llmGateway.interpret(request.query());String id="INV-"+LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)+"-"+String.format("%04d",counter.getAndIncrement());String exception=p.exception()==null?"NullPointerException":p.exception();String service=defaulted(p.service(),"bc-login-service");return new InvestigationResult(id,"INVESTIGATING",new Understanding(p.intent(),service,exception,defaulted(request.environment(),"PRODUCTION"),defaulted(request.timeRange(),"Last 15 Minutes"),p.confidence()),new RootCause(exception+" in UserService.java:187","Customer profile can be missing and the current code dereferences profile.getAddress() without a null guard. The first failures correlate with a recent code/config change and a degraded PCF instance.",92,"src/main/java/com/company/login/service/UserService.java",187),new Impact(5,25.4,3248),List.of(new Evidence("Splunk","45 matching errors; first failure at 10:23:10 AM.","MATCH"),new Evidence("New Relic","/AuthenticateUser error rate 25.4% and p95 2.48s.","MATCH"),new Evidence("PCF / Tanzu","Instance 1 degraded and restarted twice.","MATCH"),new Evidence("Bitbucket","Recent profile-mapping change touches UserService.java.","MATCH"),new Evidence("Oracle","Some affected users have no CUSTOMER_PROFILE record.","MATCH")));}
    public List<AffectedService> services(){return List.of(new AffectedService("bc-login-service","Customer Login","ROOT_CAUSE",25.4,2480,12542,3248),new AffectedService("customer-profile-service","Customer Profile","IMPACTED",8.21,1350,4023,1024),new AffectedService("notification-service","Notifications","AT_RISK",2.11,820,841,256),new AffectedService("payment-service","Payments","HEALTHY",.3,210,45,12),new AffectedService("audit-service","Audit","HEALTHY",.11,160,12,0));}
    public MonitoringAnalysis monitoring(){return new MonitoringAnalysis(256,25.4,12542,2480,List.of(52,61,74,83,91,105,116,132,148,136),List.of(4,7,8,12,18,16,23,29,21,25));}
    public RuntimeAnalysis runtime(){return new RuntimeAnalysis("PCF / Tanzu","engineering","production","bc-login-service",3,2,2048,2,List.of("10:20:00 Config change deployed","10:23:28 Instance 1 health check failed","10:23:45 Instance 1 restarted","10:24:10 High CPU alert on instance 1"));}
    private List<SplunkEvent> events(){return List.of(new SplunkEvent("10:23:10 AM","ERROR","NullPointerException in UserService.getCustomerDetails","TRK-88901","1","REQ-12345","TRK-88901","bc-login-service",500,"NULL_POINTER_EXCEPTION"),new SplunkEvent("10:23:14 AM","ERROR","Account locked","TRK-88902","0","REQ-12346","TRK-88902","bc-login-service",423,"ACCOUNT_LOCKED"),new SplunkEvent("10:23:21 AM","ERROR","IDP timeout","TRK-88903","1","REQ-12347","TRK-88903","idp-service",504,"IDP_TIMEOUT"));}
    public SplunkAnalysis splunk(){return new SplunkAnalysis("bc-login-service","prod_app","spring:json",12542,45,List.of(new SplunkPanel("errors","Application Errors","index=prod_app service=$service$ level=ERROR | stats count by exception","45","+62.4%","CRITICAL",events()),new SplunkPanel("latency","API Latency","index=prod_app service=$service$ | timechart p95(duration_ms)","2.48s","+62.7%","CRITICAL",events()),new SplunkPanel("auth","Authentication Failures","index=prod_app action=AuthenticateUser | stats count by result","330","+18.2%","CRITICAL",events())));}
    public NewRelicAnalysis newRelic(){return new NewRelicAnalysis("bc-login-service","BC Login Service - PROD",.62,136,25.4,2480,List.of(new TransactionMetric("/AuthenticateUser",42,25.4,2480,"CRITICAL"),new TransactionMetric("/customer/profile",20,8.2,1350,"WARN"),new TransactionMetric("/notification/send",15,2.1,845,"WARN"),new TransactionMetric("/audit/log",10,0,320,"OK")),List.of(new DependencyMetric("Oracle/BCLOGIN","Database",245,.2,"OK"),new DependencyMetric("customer-profile-service","HTTP",1350,8.2,"WARN"),new DependencyMetric("GemFire","Cache",42,.1,"OK")));}
    public JvmAnalysis jvm(){return new JvmAnalysis("bc-login-service","1",1260,1800,245,156,38,156,7,82,List.of(48,52,57,61,66,70,68,72),List.of(4,8,5,12,10,18,15,22),List.of(new MemoryPool("G1 Eden",245,800,30),new MemoryPool("G1 Survivor",64,128,50),new MemoryPool("G1 Old Gen",940,1400,67),new MemoryPool("Metaspace",120,400,30)),List.of(new ThreadSample("http-nio-8080-exec-1","RUNNABLE","13.4%","TokenValidationFilter.doFilter"),new ThreadSample("http-nio-8080-exec-2","WAITING","2.3%","CompletableFuture.get"),new ThreadSample("scheduler-1","BLOCKED","1.2%","CustomerRepository.findById")));}
    public PcfAnalysis pcf(){return new PcfAnalysis("engineering","production","bc-login-service","bc-login-service.apps.pcf.company.com","java_buildpack_offline",List.of(new PcfInstance(0,"RUNNING",45,"1.2G / 2G","20%","5d 8h",0,"healthy"),new PcfInstance(1,"DEGRADED",92,"1.7G / 2G","25%","2h 15m",2,"health check failed"),new PcfInstance(2,"RUNNING",38,"1.1G / 2G","18%","5d 8h",0,"healthy")),List.of(new PcfEvent("10:23 AM","Crash/HealthCheck","system","Instance 1 health check failed"),new PcfEvent("10:21 AM","Restart","system","Instance 1 restarted"),new PcfEvent("10:20 AM","Deploy","pipeline","Config change deployed")),List.of(new EnvItem("SPRING_PROFILES_ACTIVE","prod"),new EnvItem("JAVA_OPTS","-Xms1g -Xmx1800m"),new EnvItem("JBP_CONFIG_OPEN_JDK_JRE","{ jre: { version: 21.+ } }")));}
    public DatabaseAnalysis database(){return new DatabaseAnalysis("ORACLE","ORACLE-PROD","BCLOGIN","logical-prod-readonly","SPRING DATA JPA",18,12,2,50,List.of(new LongQuery("Q-8221","2.48s","SLOW",1245,8,"SELECT * FROM CUSTOMER_PROFILE WHERE CUSTOMER_ID = ?"),new LongQuery("Q-9004","856ms","WARN",856,1,"SELECT * FROM USER_SESSIONS WHERE USER_ID = ?")),List.of(new BlockingSession("12345",2,"00:00:42")),List.of("Profile lookup returns no row for some customers.","Review index on CUSTOMER_PROFILE.CUSTOMER_ID.","Keep production diagnostics read-only."));}
    public CodeAnalysis code(){return code("bc-login-service");}
    public CodeAnalysis code(String service){
        String selected = service == null || service.isBlank() ? "bc-login-service" : service;
        boolean root = "bc-login-service".equals(selected);
        return new CodeAnalysis(
            selected,
            "BC/engineering/" + selected,
            "main",
            root ? "src/main/java/com/company/login/service/UserService.java" : "src/main/java/com/company/service/ServiceHandler.java",
            root ? "NullPointerException" : "UpstreamDependencyException",
            root ? "UserService" : "ServiceHandler",
            root ? "getCustomerDetails" : "handleRequest",
            root ? 187 : 96,
            root ? 92 : 74,
            root ? "profile can be null but getAddress() is called without a guard. This matches Splunk stack traces and the recent profile mapping change." : "This service is impacted by an upstream failure. No primary source-code defect is confirmed for this service.",
            root ? List.of("183  CustomerProfile profile = customerProfileRepository","184      .findByCustomerId(customerId)","185      .orElse(null);","186","187  return profile.getAddress().getCity();  // NPE","188","189  // add null guard before dereference") : List.of("92   Response response = upstreamClient.call(request);","93   if (!response.isSuccessful()) {","94       metrics.incrementUpstreamFailure();","95   }","96   return response;","97"),
            List.of(new CommitInfo("a1b2c3d","john.doe","10:20 AM","Fix token validation logic / profile mapping"),new CommitInfo("b8137e1","jane.smith","09:14 AM","Update login timeout value")),
            "Java",
            root ? "com.company.login.service" : "com.company.service",
            "2 minutes before incident",
            "Identity Platform Team",
            root ? "CRITICAL" : "MEDIUM",
            root ? "Null safety / data validation" : "Dependency propagation",
            root ? List.of(new CodeEvidence("Splunk","45 stack traces reference UserService.java:187","MATCH"),new CodeEvidence("Recent Change","Commit a1b2c3d modified profile mapping near incident start","MATCH"),new CodeEvidence("New Relic","/AuthenticateUser errors correlate with the same code path","MATCH")) : List.of(new CodeEvidence("Service Flow","Failure originates upstream from bc-login-service","MATCH"),new CodeEvidence("New Relic","Dependency latency/error increase is correlated","MATCH")),
            root ? List.of("src/main/java/com/company/login/controller/AuthController.java","src/main/java/com/company/login/service/UserService.java","src/main/java/com/company/login/repository/CustomerProfileRepository.java","src/main/java/com/company/login/config/AuthConfig.java") : List.of("src/main/java/com/company/service/ServiceHandler.java","src/main/java/com/company/client/UpstreamClient.java","src/main/java/com/company/config/ClientConfig.java")
        );
    }
    private String defaulted(String v,String f){return v==null||v.isBlank()?f:v;}
}
