package com.company.engineering.intelligence.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.List;
import java.util.Map;

@ConfigurationProperties(prefix = "eipa")
public record PlatformProperties(
        Demo demo,
        Llm llm,
        Map<String, Connector> connectors,
        Monitoring monitoring,
        Splunk splunk
) {
    public record Demo(boolean enabled) {}
    public record Llm(boolean enabled, String baseUrl, String model, String apiKey) {}
    public record Connector(boolean enabled, String baseUrl, String token, String mode) {}
    public record Monitoring(Map<String, Dashboard> dashboards) {}
    public record Dashboard(String title, String description, List<Panel> panels) {}
    public record Panel(String id, String title, String queryRef, String visualization) {}
    public record Splunk(Map<String, Query> queries) {}
    public record Query(String spl) {}
}
