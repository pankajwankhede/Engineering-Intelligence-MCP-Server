package com.company.engineering.intelligence.model;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public final class Models {
    private Models() {}
    public record InvestigationRequest(@NotBlank String query, String environment, String timeRange) {}
    public record Understanding(String intent, String service, String exception, String environment, String timeRange, int confidence) {}
    public record RootCause(String title, String description, int confidence, String file, Integer line) {}
    public record Impact(int services, double failedRequestPercent, int usersImpacted) {}
    public record Evidence(String source, String summary, String status) {}
    public record InvestigationResult(String investigationId, String status, Understanding understanding, RootCause rootCause, Impact impact, List<Evidence> evidence) {}
    public record PlatformStatus(String backend, String mode, String splunk, String bitbucket, String newRelic, String pcf, String oracle, String sqlServer, String llmGateway) {}
    public record IntegrationItem(String key, String name, String category, String status, String endpoint, String details) {}
    public record Interpretation(String intent, String service, String exception, int confidence) {}
    public record AffectedService(String name, String displayName, String role, double errorRate, int p95, int failedRequests, int customersImpacted) {}

    public record LongQuery(String sqlId, String duration, String status, Integer avgMs, Integer rows, String sql) {}
    public record BlockingSession(String sid, int blocked, String duration) {}
    public record DatabaseAnalysis(String type, String database, String schema, String connectionRef, String persistenceTechnology, int active, int idle, int waiting, int maxConnections, List<LongQuery> longRunningQueries, List<BlockingSession> blockingSessions, List<String> recommendations) {}
    public record MonitoringAnalysis(int requestRate, double errorRate, int failedRequests, int p95LatencyMs, List<Integer> throughputTrend, List<Integer> errorTrend) {}
    public record RuntimeAnalysis(String platform, String org, String space, String app, int instances, int healthyInstances, int memoryMb, int restartsLastHour, List<String> recentEvents) {}

    public record SplunkEvent(String time, String level, String message, String traceId, String instance, String requestId, String trackingId, String service, Integer responseCode, String result) {}
    public record SplunkPanel(String id, String title, String query, String value, String trend, String severity, List<SplunkEvent> events) {}
    public record SplunkAnalysis(String service, String index, String sourcetype, int totalEvents, int matchingErrors, List<SplunkPanel> panels) {}

    public record MonitoringDashboardSummary(String id, String title, String description, int panelCount) {}
    public record DashboardPanelDefinition(String id, String title, String queryRef, String visualization) {}
    public record MonitoringDashboardDefinition(String id, String title, String description, List<DashboardPanelDefinition> panels) {}
    public record PanelMetric(String label, String value, String tone) {}
    public record ConfiguredPanelResult(String dashboardId, String panelId, String title, String queryRef, String visualization, String service, String timeRange, List<PanelMetric> metrics, List<Integer> trend, List<SplunkEvent> rows, String spl) {}

    public record TransactionMetric(String name, int rpm, double errorRate, int p95, String status) {}
    public record DependencyMetric(String name, String type, int latency, double errorRate, String status) {}
    public record NewRelicAnalysis(String service, String appName, double apdex, int throughput, double errorRate, int p95, List<TransactionMetric> transactions, List<DependencyMetric> dependencies) {}
    public record MemoryPool(String name, int usedMb, int maxMb, int percent) {}
    public record ThreadSample(String thread, String state, String cpu, String topFrame) {}
    public record JvmAnalysis(String service, String instance, int heapUsedMb, int heapMaxMb, int nonHeapMb, int gcPauseMs, int gcCount, int threads, int blockedThreads, int cpu, List<Integer> heapTrend, List<Integer> gcTrend, List<MemoryPool> pools, List<ThreadSample> threadSamples) {}
    public record PcfInstance(int index, String state, int cpu, String memory, String disk, String uptime, int restarts, String lastEvent) {}
    public record PcfEvent(String time, String type, String actor, String description) {}
    public record EnvItem(String key, String value) {}
    public record PcfAnalysis(String org, String space, String app, String route, String buildpack, List<PcfInstance> instances, List<PcfEvent> events, List<EnvItem> env) {}
    public record CommitInfo(String id, String author, String time, String message) {}
    public record CodeEvidence(String source, String summary, String status) {}
    public record CodeAnalysis(String service, String repository, String branch, String selectedFile, String issueType, String className, String methodName, int line, int confidence, String finding, List<String> snippet, List<CommitInfo> commits, String language, String packageName, String lastModified, String owner, String severity, String issueCategory, List<CodeEvidence> relatedEvidence, List<String> fileTree) {}
}
