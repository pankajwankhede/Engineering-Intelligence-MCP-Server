package com.company.eipa;

import com.company.eipa.catalog.DependencyTraversalService;
import com.company.eipa.catalog.ServiceCatalog;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class ServiceCatalogBindingTest {

    @Autowired
    ServiceCatalog catalog;

    @Autowired
    DependencyTraversalService traversal;

    @Test
    void loadsServicesFromYamlAndTraversesCrossProjectDependencies() {
        assertThat(catalog.required("service-a").bitbucket().project()).isEqualTo("PROJA");
        assertThat(catalog.required("service-b").bitbucket().project()).isEqualTo("PROJB");
        assertThat(catalog.required("service-c").bitbucket().project()).isEqualTo("PROJC");
        assertThat(traversal.traversalOrder("service-a"))
                .containsExactly("service-a", "service-b", "service-c");
    }
}
