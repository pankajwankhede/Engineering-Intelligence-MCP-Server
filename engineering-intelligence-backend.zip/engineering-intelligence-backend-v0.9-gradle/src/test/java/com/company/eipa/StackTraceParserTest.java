package com.company.eipa;

import com.company.eipa.model.LogEvent;
import com.company.eipa.splunk.StackTraceParser;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class StackTraceParserTest {
    @Test
    void extractsClassMethodAndLine() {
        var parser = new StackTraceParser();
        var result = parser.findPrimaryFailure(List.of(new LogEvent(
            "now", "payment-service", "ERROR",
            "java.lang.NullPointerException at com.company.payment.service.PaymentProcessor.processPayment(PaymentProcessor.java:184)", "")));
        assertThat(result.className()).isEqualTo("com.company.payment.service.PaymentProcessor");
        assertThat(result.methodName()).isEqualTo("processPayment");
        assertThat(result.lineNumber()).isEqualTo(184);
    }
}
