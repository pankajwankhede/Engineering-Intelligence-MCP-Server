package com.company.eipa.model;

public record FailureInfo(String exception, String className, String methodName, String fileName, Integer lineNumber) {}
