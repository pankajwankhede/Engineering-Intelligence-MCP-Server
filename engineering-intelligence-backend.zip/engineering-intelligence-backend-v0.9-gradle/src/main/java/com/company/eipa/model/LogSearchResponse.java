package com.company.eipa.model;

import java.util.List;

public record LogSearchResponse(
        List<String> services,
        String selectedService,
        String level,
        String query,
        String timeRange,
        List<LogEvent> events) {}
