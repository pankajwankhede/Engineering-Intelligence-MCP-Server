package com.company.eipa.monitoring.model;

public record MonitoringRow(
        String label,
        long count,
        String action,
        String investigationCategory,
        String severity
) {}
