package com.company.eipa.logging;

import java.time.Instant;
import java.util.Map;

/** Organization-wide JSON logging contract recommended for newly onboarded services. */
public record StandardLogEvent(
        Instant timestamp, String service, String environment, String level,
        String trackingId, String requestId, String transactionId, String traceId, String spanId,
        String className, String methodName, String errorCode, String exceptionType,
        Integer httpStatus, String message, Map<String,Object> attributes) {
}
