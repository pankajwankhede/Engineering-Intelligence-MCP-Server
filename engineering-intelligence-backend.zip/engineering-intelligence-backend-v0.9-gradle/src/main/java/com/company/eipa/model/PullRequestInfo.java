package com.company.eipa.model;

public record PullRequestInfo(
        String id,
        String title,
        String author,
        String sourceBranch,
        String destinationBranch,
        String state,
        String updatedAt,
        String service,
        String repository) {}
