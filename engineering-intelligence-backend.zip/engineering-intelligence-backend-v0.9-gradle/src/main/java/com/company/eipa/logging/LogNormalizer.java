package com.company.eipa.logging;

import com.company.eipa.model.LogEvent;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Converts structured JSON, PCF/router events, Java text logs and generic raw messages
 * into one canonical EIPA event. Parsing is best-effort and always keeps the raw event.
 */
@Component
public class LogNormalizer {
    private static final Pattern JAVA_LOCATION = Pattern.compile("(?:at\\s+)?([\\w.$]+)\\.([\\w$]+)(?:\\([^:()]*:(\\d+)\\)|[-:]Line[:=]?(\\d+))", Pattern.CASE_INSENSITIVE);
    private static final Pattern JAVA_HELPER_LOCATION = Pattern.compile("([\\w.$]+)\\.([\\w$]+)[-:]Line[:=]?(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXCEPTION = Pattern.compile("(?:^|\\s)([A-Za-z_$][\\w.$]*(?:Exception|Error))(?::|\\s|$)");
    private static final Pattern HTTP_STATUS = Pattern.compile("HTTP/\\d(?:\\.\\d)?\\s+(\\d{3})");
    private static final Pattern KEY_VALUE = Pattern.compile("(?i)(tracking[_-]?id|request[_-]?id|transaction[_-]?id|correlation[_-]?id|trace[_-]?id|span[_-]?id|error[_-]?code|client[_-]?id)\\s*[=:]\\s*[\\\"']?([^\\s,;\\\"']+)");
    private static final Pattern LOG_LEVEL = Pattern.compile("(?:^|\\s)(TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL)(?:\\s|$)", Pattern.CASE_INSENSITIVE);

    private final ObjectMapper mapper;
    private final LogNormalizationProperties props;

    public LogNormalizer(ObjectMapper mapper, LogNormalizationProperties props) {
        this.mapper = mapper;
        this.props = props;
    }

    public LogEvent normalize(JsonNode splunkResult, String fallbackService) {
        Map<String,Object> original = mapper.convertValue(splunkResult, new TypeReference<>() {});
        String raw = first(splunkResult, List.of("_raw", "raw", "event"));
        JsonNode embedded = parseEmbeddedJson(raw);

        String service = firstAny(splunkResult, embedded, list(props.serviceFields(), "service","serviceName","application","app","appName","cf_app_name"));
        if (!StringUtils.hasText(service)) service = fallbackService;
        String environment = firstAny(splunkResult, embedded, list(props.environmentFields(), "environment","env","cf_space_name","PCF_Prod_PCF_Foundation"));
        String level = normalizeLevel(firstAny(splunkResult, embedded, list(props.levelFields(), "level","severity","logLevel")));
        String trackingId = firstAny(splunkResult, embedded, list(props.trackingIdFields(), "trackingId","tracking_id","TrackingID","correlationId","correlation_id"));
        String requestId = firstAny(splunkResult, embedded, list(props.requestIdFields(), "requestId","request_id","vcap_request_id","x_vcap_request_id"));
        String transactionId = firstAny(splunkResult, embedded, list(props.transactionIdFields(), "transactionId","transaction_id","TransactionID"));
        String traceId = firstAny(splunkResult, embedded, list(props.traceIdFields(), "traceId","trace_id","x_b3_traceid","x_b3_traceId"));
        String spanId = firstAny(splunkResult, embedded, list(props.spanIdFields(), "spanId","span_id","x_b3_spanid"));
        String errorCode = firstAny(splunkResult, embedded, list(props.errorCodeFields(), "errorCode","error_code","code"));
        String message = firstAny(splunkResult, embedded, list(props.messageFields(), "message","msg","error","exception"));
        if (!StringUtils.hasText(message)) message = raw;

        String time = firstAny(splunkResult, embedded, List.of("_time","timestamp","time","@timestamp"));
        String host = firstAny(splunkResult, embedded, List.of("host","hostname"));
        String source = firstAny(splunkResult, embedded, List.of("source"));
        String sourceType = firstAny(splunkResult, embedded, List.of("sourcetype","source_type","sourceType"));
        Integer httpStatus = integer(firstAny(splunkResult, embedded, List.of("httpStatus","http_status","status","statusCode","status_code")));
        String className = firstAny(splunkResult, embedded, List.of("class","className","logger_name","logger"));
        String methodName = firstAny(splunkResult, embedded, List.of("method","methodName"));
        Integer lineNumber = integer(firstAny(splunkResult, embedded, List.of("line","lineNumber","line_number")));
        String exceptionType = firstAny(splunkResult, embedded, List.of("exceptionType","exception_type","exceptionClass"));

        Map<String,String> rawKv = extractRawKeyValues(raw + " " + message);
        trackingId = coalesce(trackingId, rawKv.get("trackingid"), rawKv.get("correlationid"));
        requestId = coalesce(requestId, rawKv.get("requestid"));
        transactionId = coalesce(transactionId, rawKv.get("transactionid"));
        traceId = coalesce(traceId, rawKv.get("traceid"));
        spanId = coalesce(spanId, rawKv.get("spanid"));
        errorCode = coalesce(errorCode, rawKv.get("errorcode"));

        String searchable = (message == null ? "" : message) + "\n" + (raw == null ? "" : raw);
        Matcher loc = JAVA_LOCATION.matcher(searchable);
        if (!loc.find()) loc = JAVA_HELPER_LOCATION.matcher(searchable);
        if ((!StringUtils.hasText(className) || !StringUtils.hasText(methodName) || lineNumber == null) && loc.find(0)) {
            className = coalesce(className, loc.group(1));
            methodName = coalesce(methodName, loc.group(2));
            String line = loc.groupCount() >= 4 ? coalesce(loc.group(3), loc.group(4)) : loc.group(3);
            if (lineNumber == null) lineNumber = integer(line);
        }
        if (!StringUtils.hasText(exceptionType)) {
            Matcher ex = EXCEPTION.matcher(searchable);
            if (ex.find()) exceptionType = ex.group(1);
        }
        if (httpStatus == null) {
            Matcher hs = HTTP_STATUS.matcher(searchable);
            if (hs.find()) httpStatus = integer(hs.group(1));
        }
        if (!StringUtils.hasText(level)) {
            Matcher lm = LOG_LEVEL.matcher(searchable);
            if (lm.find()) level = normalizeLevel(lm.group(1));
        }
        if (!StringUtils.hasText(level)) level = StringUtils.hasText(exceptionType) ? "ERROR" : "INFO";

        String format = detectFormat(splunkResult, embedded, raw, sourceType);
        double confidence = confidence(service, level, trackingId, requestId, transactionId, traceId, className, message, format);
        return new LogEvent(time, service, environment, level, trackingId, requestId, transactionId, traceId, spanId,
                httpStatus, className, methodName, lineNumber, errorCode, exceptionType, message, host, source, sourceType,
                format, confidence, original, raw);
    }

    private JsonNode parseEmbeddedJson(String raw) {
        if (!StringUtils.hasText(raw)) return null;
        String s = raw.trim();
        if (!(s.startsWith("{") && s.endsWith("}"))) return null;
        try { return mapper.readTree(s); } catch (Exception ignored) { return null; }
    }

    private String detectFormat(JsonNode result, JsonNode embedded, String raw, String sourceType) {
        if (embedded != null && embedded.isObject()) return "JSON";
        if (StringUtils.hasText(sourceType) && (sourceType.equalsIgnoreCase("RTR") || sourceType.toLowerCase().contains("router"))) return "PCF_ROUTER";
        String s = raw == null ? "" : raw;
        if (JAVA_LOCATION.matcher(s).find() || JAVA_HELPER_LOCATION.matcher(s).find() || LOG_LEVEL.matcher(s).find()) return "JAVA_TEXT";
        return result != null && result.size() > 3 ? "STRUCTURED_SPLUNK" : "RAW_TEXT";
    }

    private double confidence(String... values) { return 0.0; }
    private double confidence(String service, String level, String trackingId, String requestId, String transactionId,
                              String traceId, String className, String message, String format) {
        double score = 0.15;
        if (StringUtils.hasText(service)) score += .20;
        if (StringUtils.hasText(level)) score += .10;
        if (StringUtils.hasText(trackingId) || StringUtils.hasText(requestId) || StringUtils.hasText(transactionId) || StringUtils.hasText(traceId)) score += .20;
        if (StringUtils.hasText(className)) score += .10;
        if (StringUtils.hasText(message)) score += .10;
        if ("JSON".equals(format) || "STRUCTURED_SPLUNK".equals(format)) score += .15;
        return Math.min(1.0, Math.round(score * 100.0) / 100.0);
    }

    private Map<String,String> extractRawKeyValues(String text) {
        Map<String,String> out = new HashMap<>();
        if (!StringUtils.hasText(text)) return out;
        Matcher m = KEY_VALUE.matcher(text);
        while (m.find()) out.put(m.group(1).replace("_", "").replace("-", "").toLowerCase(), m.group(2));
        return out;
    }

    private List<String> list(List<String> configured, String... defaults) {
        LinkedHashSet<String> names = new LinkedHashSet<>();
        if (configured != null) names.addAll(configured);
        names.addAll(Arrays.asList(defaults));
        return new ArrayList<>(names);
    }
    private String firstAny(JsonNode primary, JsonNode embedded, List<String> names) {
        String v = first(primary, names);
        return StringUtils.hasText(v) ? v : first(embedded, names);
    }
    private String first(JsonNode node, List<String> names) {
        if (node == null) return "";
        for (String name : names) {
            JsonNode v = findIgnoreCase(node, name);
            if (v != null && !v.isNull()) {
                String s = v.isValueNode() ? v.asText("") : v.toString();
                if (StringUtils.hasText(s)) return s;
            }
        }
        return "";
    }
    private JsonNode findIgnoreCase(JsonNode node, String name) {
        if (node.has(name)) return node.get(name);
        var it = node.fields();
        while (it.hasNext()) { var e = it.next(); if (e.getKey().equalsIgnoreCase(name)) return e.getValue(); }
        return null;
    }
    private String coalesce(String... values) { for (String v : values) if (StringUtils.hasText(v)) return v; return ""; }
    private Integer integer(String v) { if (!StringUtils.hasText(v)) return null; try { return Integer.valueOf(v.replaceAll("[^0-9]", "")); } catch (Exception e) { return null; } }
    private String normalizeLevel(String v) { if (!StringUtils.hasText(v)) return ""; v=v.toUpperCase(Locale.ROOT); return "WARNING".equals(v) ? "WARN" : v; }
}
