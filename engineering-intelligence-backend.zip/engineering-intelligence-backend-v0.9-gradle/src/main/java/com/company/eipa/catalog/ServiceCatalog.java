package com.company.eipa.catalog;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;

@Component
public class ServiceCatalog {
    private final ServiceCatalogProperties properties;

    public ServiceCatalog(ServiceCatalogProperties properties) {
        this.properties = properties;
    }

    public ServiceDefinition required(String serviceName) {
        var service = services().get(serviceName);
        if (service == null) {
            throw new IllegalArgumentException("Unknown service: " + serviceName);
        }
        return service;
    }

    public Map<String, ServiceDefinition> services() {
        return properties.services() == null ? Map.of() : properties.services();
    }

    public Set<String> serviceNames() {
        return services().keySet();
    }

    public int maxTraversalDepth() {
        return properties.maxTraversalDepth() <= 0 ? 5 : properties.maxTraversalDepth();
    }
}
