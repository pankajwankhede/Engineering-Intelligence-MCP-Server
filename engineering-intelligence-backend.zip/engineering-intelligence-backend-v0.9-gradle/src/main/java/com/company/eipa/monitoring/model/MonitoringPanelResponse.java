package com.company.eipa.monitoring.model;

import java.time.Instant;
import java.util.List;

public record MonitoringPanelResponse(
        String dashboardId,
        String panelId,
        String title,
        String description,
        String visualization,
        String queryReference,
        Instant generatedAt,
        List<MonitoringRow> rows
) {}
