package com.company.eipa.code;

import com.company.eipa.bitbucket.SourceCodeService;
import com.company.eipa.model.FailureInfo;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class ApiFlowAnalyzer {
    private static final Pattern CLASS_MAPPING = Pattern.compile("@RequestMapping\\s*\\(\\s*(?:value\\s*=\\s*)?[\\\"']([^\\\"']*)[\\\"']");
    private static final Pattern METHOD_MAPPING = Pattern.compile("@(Get|Post|Put|Delete|Patch|Request)Mapping\\s*(?:\\(\\s*(?:value\\s*=\\s*)?[\\\"']?([^\\\"')}]*)[\\\"']?[^)]*\\))?");
    private final SourceCodeService sourceCode;

    public ApiFlowAnalyzer(SourceCodeService sourceCode) {
        this.sourceCode = sourceCode;
    }

    public List<String> findEndpoints(String service, FailureInfo failure) {
        List<String> endpoints = new ArrayList<>();
        for (var file : sourceCode.listFiles(service)) {
            if (!"JAVA".equals(file.type())) continue;
            String content;
            try { content = sourceCode.getFile(service, file.path(), null).content(); }
            catch (Exception ignored) { continue; }
            if (!(content.contains("@RestController") || content.contains("@Controller"))) continue;
            String classPath = "";
            Matcher classMatcher = CLASS_MAPPING.matcher(content);
            if (classMatcher.find()) classPath = normalizePath(classMatcher.group(1));
            Matcher methodMatcher = METHOD_MAPPING.matcher(content);
            while (methodMatcher.find()) {
                String verb = methodMatcher.group(1).toUpperCase();
                if ("REQUEST".equals(verb)) verb = "REQUEST";
                String methodPath = normalizePath(methodMatcher.group(2));
                String fullPath = normalizePath(classPath + "/" + methodPath);
                String endpoint = verb + " " + (fullPath.isBlank() ? "/" : fullPath);
                if (!endpoints.contains(endpoint)) endpoints.add(endpoint);
            }
        }
        return endpoints;
    }

    private String normalizePath(String value) {
        if (value == null || value.isBlank()) return "";
        String v = value.trim().replaceAll("/+", "/");
        if (!v.startsWith("/")) v = "/" + v;
        if (v.length() > 1 && v.endsWith("/")) v = v.substring(0, v.length() - 1);
        return v;
    }
}
