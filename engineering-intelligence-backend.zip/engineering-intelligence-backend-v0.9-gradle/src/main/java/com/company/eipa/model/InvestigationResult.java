package com.company.eipa.model;

import java.util.List;

public record InvestigationResult(
        String investigationId,
        String status,
        String entryService,
        String trackingId,
        String requestId,
        String traceId,
        String environment,
        String timeRange,
        List<String> traversalOrder,
        List<ServiceInvestigationStep> serviceFlow,
        RootCauseInfo rootCause,
        List<String> impactedTeams,
        List<RecentChangeInfo> recentChanges,
        List<String> recommendations) {
}
