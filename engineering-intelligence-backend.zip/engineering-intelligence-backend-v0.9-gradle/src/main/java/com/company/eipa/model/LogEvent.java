package com.company.eipa.model;

import java.util.Map;

/**
 * Canonical event used by EIPA regardless of the original Splunk log format.
 * originalFields/raw preserve the source evidence so normalization never discards data.
 */
public record LogEvent(
        String time,
        String service,
        String environment,
        String level,
        String trackingId,
        String requestId,
        String transactionId,
        String traceId,
        String spanId,
        Integer httpStatus,
        String className,
        String methodName,
        Integer lineNumber,
        String errorCode,
        String exceptionType,
        String message,
        String host,
        String source,
        String sourceType,
        String format,
        double parseConfidence,
        Map<String, Object> originalFields,
        String raw) {
}
