package com.company.eipa.model;

public record CodeFileContent(
        String service,
        String repository,
        String branch,
        String path,
        String content,
        Integer highlightedLine) {}
