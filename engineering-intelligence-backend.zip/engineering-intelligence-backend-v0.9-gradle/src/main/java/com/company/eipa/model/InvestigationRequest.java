package com.company.eipa.model;

/**
 * Flexible user input for production investigation. Only one strong identifier is required.
 * Service is optional: EIPA can discover it from tracking/request/trace ID or description.
 */
public record InvestigationRequest(
        String service,
        String trackingId,
        String requestId,
        String traceId,
        String apiUrl,
        String errorOrException,
        String description,
        String environment,
        String timeRange) {

    public String effectiveTimeRange() {
        return timeRange == null || timeRange.isBlank() ? "2h" : timeRange;
    }

    public String primaryIdentifier() {
        if (trackingId != null && !trackingId.isBlank()) return trackingId;
        if (requestId != null && !requestId.isBlank()) return requestId;
        if (traceId != null && !traceId.isBlank()) return traceId;
        if (apiUrl != null && !apiUrl.isBlank()) return apiUrl;
        if (errorOrException != null && !errorOrException.isBlank()) return errorOrException;
        if (description != null && !description.isBlank()) return description;
        return "manual-investigation";
    }
}
