package com.company.eipa.model;

public record CodeComponentInfo(String classPurpose, String methodPurpose, boolean issueFound, String issue) {}
