package com.company.eipa.changes;

import com.company.eipa.bitbucket.BitbucketRestClient;
import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.model.ChangedResource;
import com.company.eipa.model.FailureInfo;
import com.company.eipa.model.PullRequestInfo;
import com.company.eipa.model.RecentChangeInfo;
import com.company.eipa.model.ServiceChangeHistory;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class RecentChangeService {
    private final ServiceCatalog catalog;
    private final BitbucketRestClient bitbucket;

    public RecentChangeService(ServiceCatalog catalog, BitbucketRestClient bitbucket) {
        this.catalog = catalog;
        this.bitbucket = bitbucket;
    }

    public List<RecentChangeInfo> findRecentChanges(String serviceName, FailureInfo failure) {
        ServiceChangeHistory history = getHistory(serviceName, 10);
        if (failure == null || failure.fileName() == null || failure.fileName().isBlank()) return history.commits();
        return history.commits().stream().map(change -> markIncidentFile(change, failure.fileName())).toList();
    }

    public ServiceChangeHistory getHistory(String serviceName, int limit) {
        var definition = catalog.required(serviceName);
        int safeLimit = Math.max(1, Math.min(limit, 10));
        String project = enc(definition.bitbucket().project());
        String repo = enc(definition.bitbucket().repository());
        String branch = enc(definition.bitbucket().defaultBranch());
        String repository = definition.bitbucket().project() + "/" + definition.bitbucket().repository();

        JsonNode commitBody = bitbucket.getJson("/rest/api/1.0/projects/%s/repos/%s/commits?until=%s&limit=%d".formatted(project, repo, branch, safeLimit));
        List<RecentChangeInfo> commits = new ArrayList<>();
        JsonNode commitValues = commitBody == null ? null : commitBody.path("values");
        if (commitValues != null && commitValues.isArray()) {
            commitValues.forEach(node -> commits.add(toCommit(project, repo, node)));
        }

        JsonNode prBody = bitbucket.getJson("/rest/api/1.0/projects/%s/repos/%s/pull-requests?state=ALL&limit=25&order=NEWEST".formatted(project, repo));
        List<PullRequestInfo> prs = new ArrayList<>();
        JsonNode prValues = prBody == null ? null : prBody.path("values");
        if (prValues != null && prValues.isArray()) {
            prValues.forEach(node -> prs.add(toPullRequest(node, serviceName, repository)));
        }

        return new ServiceChangeHistory(serviceName, definition.ownership().team(), repository, commits, prs);
    }

    private RecentChangeInfo toCommit(String project, String repo, JsonNode node) {
        String id = text(node, "displayId", text(node, "id", ""));
        String author = node.path("author").path("displayName").asText(node.path("author").path("name").asText(""));
        String message = text(node, "message", "");
        String timestamp = timestamp(node.path("authorTimestamp"));
        List<ChangedResource> resources = loadChanges(project, repo, id);
        Map<String,Integer> counts = new LinkedHashMap<>();
        resources.forEach(r -> counts.merge(r.type(), 1, Integer::sum));
        return new RecentChangeInfo(id, author, timestamp, message, "UNKNOWN", "UNKNOWN", resources.size(), 0, counts, resources);
    }

    private List<ChangedResource> loadChanges(String project, String repo, String commit) {
        if (commit == null || commit.isBlank()) return List.of();
        JsonNode body = bitbucket.getJson("/rest/api/1.0/projects/%s/repos/%s/commits/%s/changes?limit=500".formatted(project, repo, enc(commit)));
        JsonNode values = body == null ? null : body.path("values");
        if (values == null || !values.isArray()) return List.of();
        List<ChangedResource> resources = new ArrayList<>();
        values.forEach(change -> {
            String path = change.path("path").path("toString").asText(change.path("path").asText(""));
            if (path.isBlank()) return;
            resources.add(new ChangedResource(path, classify(path), "UNKNOWN", false, 0, 0));
        });
        return resources;
    }

    private PullRequestInfo toPullRequest(JsonNode node, String serviceName, String repository) {
        String id = node.path("id").asText("");
        String title = text(node, "title", "");
        String author = node.path("author").path("user").path("displayName").asText(node.path("author").path("user").path("name").asText(""));
        String source = node.path("fromRef").path("displayId").asText("");
        String destination = node.path("toRef").path("displayId").asText("");
        String state = text(node, "state", "");
        String updatedAt = timestamp(node.path("updatedDate"));
        return new PullRequestInfo(id, title, author, source, destination, state, updatedAt, serviceName, repository);
    }

    private RecentChangeInfo markIncidentFile(RecentChangeInfo change, String fileName) {
        List<ChangedResource> resources = change.resources().stream().map(r -> {
            boolean related = r.path().endsWith(fileName);
            return new ChangedResource(r.path(), r.type(), related ? "HIGH" : r.relevance(), related, r.additions(), r.deletions());
        }).toList();
        int related = (int) resources.stream().filter(ChangedResource::incidentRelated).count();
        String correlation = related > 0 ? "HIGH" : change.correlation();
        Map<String,Integer> counts = new LinkedHashMap<>();
        resources.forEach(r -> counts.merge(r.type(), 1, Integer::sum));
        return new RecentChangeInfo(change.commit(), change.author(), change.timestamp(), change.message(), correlation, change.risk(), resources.size(), related, counts, resources);
    }

    private String classify(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".java")) return p.contains("/test/") || p.contains("/tests/") ? "TEST" : "JAVA_CLASS";
        if (p.contains("openapi") || p.contains("swagger")) return "API_SPEC";
        if (p.endsWith(".yml") || p.endsWith(".yaml") || p.endsWith(".properties") || p.endsWith(".json")) return "CONFIG";
        if (p.endsWith(".gradle") || p.endsWith("pom.xml")) return "BUILD";
        if (p.endsWith(".md")) return "DOCUMENTATION";
        return "FILE";
    }

    private String timestamp(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) return "";
        if (node.isNumber()) return Instant.ofEpochMilli(node.asLong()).toString();
        return node.asText("");
    }
    private String text(JsonNode node, String field, String fallback) { String value = node.path(field).asText(""); return value.isBlank() ? fallback : value; }
    private String enc(String value) { return UriUtils.encodePathSegment(value == null ? "" : value, StandardCharsets.UTF_8); }
}
