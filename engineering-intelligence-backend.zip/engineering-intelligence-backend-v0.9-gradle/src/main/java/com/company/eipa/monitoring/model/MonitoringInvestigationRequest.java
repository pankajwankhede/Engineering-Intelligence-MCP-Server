package com.company.eipa.monitoring.model;

public record MonitoringInvestigationRequest(
        String dashboardId,
        String panelId,
        String metricLabel,
        String investigationCategory,
        String environment,
        String timeRange,
        String trackingId,
        String requestId,
        String traceId
) {}
