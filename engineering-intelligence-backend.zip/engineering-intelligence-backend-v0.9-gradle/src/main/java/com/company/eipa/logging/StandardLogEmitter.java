package com.company.eipa.logging;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;

/**
 * Lightweight example emitter that requires no special log encoder. New services can move this into a shared starter.
 * It emits one JSON object per log line, which Splunk can index while EIPA continues supporting legacy text logs.
 */
public final class StandardLogEmitter {
    private final Logger logger;
    private final ObjectMapper mapper;

    public StandardLogEmitter(Logger logger, ObjectMapper mapper) { this.logger = logger; this.mapper = mapper; }

    public void info(StandardLogEvent event) { write(event, null); }
    public void error(StandardLogEvent event, Throwable error) { write(event, error); }

    private void write(StandardLogEvent event, Throwable error) {
        try {
            String json = mapper.writeValueAsString(event);
            if (error == null) logger.info(json); else logger.error(json, error);
        } catch (Exception serializationFailure) {
            logger.error("Unable to serialize standard log event", serializationFailure);
        }
    }
}
