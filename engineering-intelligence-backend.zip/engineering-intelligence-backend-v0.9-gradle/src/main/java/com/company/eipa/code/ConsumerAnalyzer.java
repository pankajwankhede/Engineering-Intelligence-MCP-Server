package com.company.eipa.code;

import com.company.eipa.catalog.ServiceCatalog;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ConsumerAnalyzer {
    private final ServiceCatalog catalog;

    public ConsumerAnalyzer(ServiceCatalog catalog) {
        this.catalog = catalog;
    }

    public List<String> findConsumers(String service, List<String> endpoints) {
        // Catalog-driven reverse dependency lookup. Runtime/API-gateway consumers can be merged later.
        List<String> consumers = new ArrayList<>();
        catalog.services().forEach((candidateName, definition) -> {
            boolean callsTarget = definition.safeDependencies().stream().anyMatch(dep -> service.equals(dep.service()));
            if (callsTarget) consumers.add(candidateName);
        });
        return consumers.stream().distinct().sorted().toList();
    }
}
