package com.company.eipa.discovery;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.model.InvestigationRequest;
import com.company.eipa.splunk.SplunkSearchService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class ServiceDiscoveryService {
    private final ServiceCatalog catalog;
    private final SplunkSearchService splunk;

    public ServiceDiscoveryService(ServiceCatalog catalog, SplunkSearchService splunk) {
        this.catalog = catalog;
        this.splunk = splunk;
    }

    public String discoverEntryService(InvestigationRequest request) {
        if (StringUtils.hasText(request.service())) {
            catalog.required(request.service());
            return request.service();
        }
        if (catalog.serviceNames().isEmpty()) throw new IllegalStateException("No services are registered in the service catalog");

        String freeText = firstNonBlank(request.traceId(), request.apiUrl(), request.errorOrException(), request.description());
        List<Candidate> candidates = new ArrayList<>();
        for (String service : catalog.serviceNames()) {
            try {
                var result = splunk.searchRelatedLogs(
                        List.of(service), service, "ALL", freeText,
                        request.timeRange(), request.trackingId(), request.requestId());
                if (!result.events().isEmpty()) {
                    String firstTime = result.events().stream().map(e -> e.time() == null ? "" : e.time()).filter(StringUtils::hasText).min(String::compareTo).orElse("");
                    candidates.add(new Candidate(service, firstTime, result.events().size()));
                }
            } catch (RuntimeException ignored) {
                // Continue other catalog entries. If nothing matches, fail with a clear discovery error below.
            }
        }
        return candidates.stream()
                .sorted(Comparator.comparing(Candidate::firstTime, Comparator.nullsLast(String::compareTo)).thenComparing(Comparator.comparingInt(Candidate::eventCount).reversed()))
                .map(Candidate::service)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("Unable to discover an entry service from the supplied identifiers/symptom within the configured service catalog and time range"));
    }

    private String firstNonBlank(String... values) {
        for (String value : values) if (StringUtils.hasText(value)) return value;
        return "";
    }

    private record Candidate(String service, String firstTime, int eventCount) {}
}
