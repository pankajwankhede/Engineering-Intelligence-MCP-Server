package com.company.eipa.model;

public record CodeFileInfo(String path, String type, String displayName) {}
