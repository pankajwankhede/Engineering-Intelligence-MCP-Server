package com.company.eipa.monitoring.model;

public record MonitoringDashboardSummary(
        String dashboardId,
        String title,
        String description,
        int panelCount
) {}
