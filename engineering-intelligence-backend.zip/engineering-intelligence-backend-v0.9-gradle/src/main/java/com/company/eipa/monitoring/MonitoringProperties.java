package com.company.eipa.monitoring;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Map;

@ConfigurationProperties(prefix = "eipa.monitoring")
public record MonitoringProperties(
        String defaultEnvironment,
        String defaultTimeRange,
        Map<String, DashboardDefinition> dashboards,
        Map<String, QueryDefinition> queries
) {
    public MonitoringProperties {
        dashboards = dashboards == null ? new LinkedHashMap<>() : dashboards;
        queries = queries == null ? new LinkedHashMap<>() : queries;
    }

    public record DashboardDefinition(String title, String description, java.util.List<PanelDefinition> panels) {}

    public record PanelDefinition(String id, String title, String queryRef, String visualization) {}

    public record QueryDefinition(
            String description,
            String spl,
            String action,
            String investigationCategory
    ) {}
}
