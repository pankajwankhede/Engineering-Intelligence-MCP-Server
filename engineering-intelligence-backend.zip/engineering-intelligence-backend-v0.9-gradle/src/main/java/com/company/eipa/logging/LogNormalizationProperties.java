package com.company.eipa.logging;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "eipa.log-normalization")
public record LogNormalizationProperties(
        List<String> serviceFields,
        List<String> environmentFields,
        List<String> levelFields,
        List<String> trackingIdFields,
        List<String> requestIdFields,
        List<String> transactionIdFields,
        List<String> traceIdFields,
        List<String> spanIdFields,
        List<String> errorCodeFields,
        List<String> messageFields) {
}
