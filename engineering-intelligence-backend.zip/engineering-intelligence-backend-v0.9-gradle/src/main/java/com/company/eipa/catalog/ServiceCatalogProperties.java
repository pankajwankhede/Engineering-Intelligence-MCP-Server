package com.company.eipa.catalog;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

@ConfigurationProperties(prefix = "eipa.catalog")
public record ServiceCatalogProperties(
        int maxTraversalDepth,
        Map<String, ServiceDefinition> services) {
}
