package com.company.eipa.model;

import java.util.List;

public record ServiceChangeHistory(
        String service,
        String team,
        String repository,
        List<RecentChangeInfo> commits,
        List<PullRequestInfo> pullRequests) {}
