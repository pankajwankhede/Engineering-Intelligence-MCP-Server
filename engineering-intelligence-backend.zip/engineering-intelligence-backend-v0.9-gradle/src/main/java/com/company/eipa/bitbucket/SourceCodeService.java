package com.company.eipa.bitbucket;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.model.CodeFileContent;
import com.company.eipa.model.CodeFileInfo;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class SourceCodeService {
    private final ServiceCatalog catalog;
    private final BitbucketRestClient bitbucket;

    public SourceCodeService(ServiceCatalog catalog, BitbucketRestClient bitbucket) {
        this.catalog = catalog;
        this.bitbucket = bitbucket;
    }

    public List<CodeFileInfo> listFiles(String serviceName) {
        var service = catalog.required(serviceName);
        String project = enc(service.bitbucket().project());
        String repo = enc(service.bitbucket().repository());
        String branch = enc(service.bitbucket().defaultBranch());
        String uri = "/rest/api/1.0/projects/%s/repos/%s/files?at=%s&limit=1000".formatted(project, repo, branch);
        JsonNode body = bitbucket.getJson(uri);
        List<CodeFileInfo> files = new ArrayList<>();
        JsonNode values = body == null ? null : body.path("values");
        if (values != null && values.isArray()) {
            values.forEach(node -> {
                String path = node.asText();
                if (!path.isBlank()) files.add(new CodeFileInfo(path, classify(path), fileName(path)));
            });
        }
        files.sort(Comparator.comparing(CodeFileInfo::path));
        return files;
    }

    public CodeFileContent getFile(String serviceName, String path, Integer highlightedLine) {
        var service = catalog.required(serviceName);
        String project = enc(service.bitbucket().project());
        String repoSlug = enc(service.bitbucket().repository());
        String branch = enc(service.bitbucket().defaultBranch());
        String encodedPath = encodePath(path);
        String uri = "/rest/api/1.0/projects/%s/repos/%s/raw/%s?at=%s".formatted(project, repoSlug, encodedPath, branch);
        String content = bitbucket.getText(uri);
        String repository = service.bitbucket().project() + "/" + service.bitbucket().repository();
        return new CodeFileContent(serviceName, repository, service.bitbucket().defaultBranch(), path, content == null ? "" : content, highlightedLine);
    }

    public String getSourceContext(String serviceName, String className, Integer lineNumber) {
        List<CodeFileInfo> files = listFiles(serviceName);
        if (files.isEmpty()) return "";
        String expected = className == null ? null : className.substring(className.lastIndexOf('.') + 1) + ".java";
        CodeFileInfo target = expected == null ? files.getFirst() : files.stream()
                .filter(f -> f.displayName().equals(expected))
                .findFirst().orElse(files.getFirst());
        return getFile(serviceName, target.path(), lineNumber).content();
    }

    private String classify(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".java")) return p.contains("/test/") || p.contains("/tests/") ? "TEST" : "JAVA";
        if (p.endsWith(".yml") || p.endsWith(".yaml") || p.endsWith(".properties") || p.endsWith(".json")) return "CONFIG";
        if (p.endsWith(".gradle") || p.endsWith("pom.xml")) return "BUILD";
        if (p.contains("openapi") || p.contains("swagger")) return "API_SPEC";
        if (p.endsWith(".md")) return "DOCUMENTATION";
        return "FILE";
    }

    private String fileName(String path) {
        int i = path.lastIndexOf('/');
        return i >= 0 ? path.substring(i + 1) : path;
    }

    private String enc(String value) { return UriUtils.encodePathSegment(value, StandardCharsets.UTF_8); }
    private String encodePath(String path) {
        return String.join("/", java.util.Arrays.stream(path.split("/"))
                .map(this::enc).toList());
    }
}
