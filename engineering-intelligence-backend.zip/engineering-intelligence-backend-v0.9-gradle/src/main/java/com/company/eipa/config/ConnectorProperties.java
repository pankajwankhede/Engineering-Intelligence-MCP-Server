package com.company.eipa.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "eipa.connectors")
public record ConnectorProperties(Splunk splunk, Bitbucket bitbucket) {
    public record Splunk(String baseUrl, String token, int maxResults, int timeoutSeconds) {}
    public record Bitbucket(String baseUrl, String username, String token) {}
}
