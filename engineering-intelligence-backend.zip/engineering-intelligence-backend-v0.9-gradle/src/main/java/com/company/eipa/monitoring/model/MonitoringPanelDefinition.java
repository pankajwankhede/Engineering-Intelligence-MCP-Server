package com.company.eipa.monitoring.model;

public record MonitoringPanelDefinition(
        String panelId,
        String title,
        String visualization,
        String queryReference,
        String description
) {}
