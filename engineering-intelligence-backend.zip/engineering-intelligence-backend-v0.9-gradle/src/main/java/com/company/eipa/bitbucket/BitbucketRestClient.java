package com.company.eipa.bitbucket;

import com.company.eipa.config.ConnectorProperties;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class BitbucketRestClient {
    private final ConnectorProperties properties;
    private final RestClient restClient;

    public BitbucketRestClient(ConnectorProperties properties, RestClient.Builder builder) {
        this.properties = properties;
        var cfg = properties.bitbucket();
        this.restClient = cfg != null && StringUtils.hasText(cfg.baseUrl())
                ? builder.baseUrl(cfg.baseUrl()).defaultHeader(HttpHeaders.ACCEPT, "application/json").build()
                : null;
    }

    public boolean configured() {
        return restClient != null;
    }

    public JsonNode getJson(String uri) {
        requireConfigured();
        return restClient.get().uri(uri).headers(this::auth).retrieve().body(JsonNode.class);
    }

    public String getText(String uri) {
        requireConfigured();
        return restClient.get().uri(uri).headers(this::auth).retrieve().body(String.class);
    }

    private void auth(HttpHeaders headers) {
        var cfg = properties.bitbucket();
        if (cfg == null) return;
        if (StringUtils.hasText(cfg.username()) && StringUtils.hasText(cfg.token())) {
            String pair = cfg.username() + ":" + cfg.token();
            headers.set(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString(pair.getBytes(StandardCharsets.UTF_8)));
        } else if (StringUtils.hasText(cfg.token())) {
            headers.setBearerAuth(cfg.token());
        }
    }

    private void requireConfigured() {
        if (!configured()) throw new IllegalStateException("Bitbucket connector is not configured. Set BITBUCKET_URL and the approved read-only credentials.");
    }
}
