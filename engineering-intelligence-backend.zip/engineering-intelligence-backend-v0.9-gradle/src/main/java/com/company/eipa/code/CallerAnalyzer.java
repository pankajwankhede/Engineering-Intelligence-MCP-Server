package com.company.eipa.code;

import com.company.eipa.bitbucket.SourceCodeService;
import com.company.eipa.model.FailureInfo;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class CallerAnalyzer {
    private static final Pattern METHOD_DECLARATION = Pattern.compile("(?:public|protected|private|static|final|synchronized|native|abstract|\\s)+[\\w<>\\[\\], ?]+\\s+(\\w+)\\s*\\([^;]*\\)\\s*(?:throws [^{]+)?\\{");
    private final SourceCodeService sourceCode;

    public CallerAnalyzer(SourceCodeService sourceCode) {
        this.sourceCode = sourceCode;
    }

    public List<String> findCallers(String service, FailureInfo failure) {
        if (failure == null || failure.methodName() == null || failure.methodName().isBlank()) return List.of();
        String targetMethod = failure.methodName();
        List<String> callers = new ArrayList<>();
        for (var file : sourceCode.listFiles(service)) {
            if (!"JAVA".equals(file.type())) continue;
            String content;
            try { content = sourceCode.getFile(service, file.path(), null).content(); }
            catch (Exception ignored) { continue; }
            String[] lines = content.split("\\R", -1);
            String currentMethod = null;
            for (int i = 0; i < lines.length; i++) {
                Matcher declaration = METHOD_DECLARATION.matcher(lines[i]);
                if (declaration.find()) currentMethod = declaration.group(1);
                String line = lines[i];
                boolean targetCall = line.contains("." + targetMethod + "(") || line.matches(".*\\b" + Pattern.quote(targetMethod) + "\\s*\\(.*");
                boolean ownDeclaration = declaration.find(0) && targetMethod.equals(declaration.group(1));
                if (targetCall && !ownDeclaration) {
                    String className = file.displayName().endsWith(".java") ? file.displayName().substring(0, file.displayName().length() - 5) : file.displayName();
                    String caller = className + "." + (currentMethod == null ? "<unknown>" : currentMethod) + "()";
                    if (!callers.contains(caller)) callers.add(caller);
                }
            }
        }
        return callers;
    }
}
