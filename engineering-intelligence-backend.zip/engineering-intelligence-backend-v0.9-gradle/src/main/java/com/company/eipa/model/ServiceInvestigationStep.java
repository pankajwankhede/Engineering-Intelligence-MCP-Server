package com.company.eipa.model;

import java.util.List;

public record ServiceInvestigationStep(
        String service,
        String team,
        String businessDomain,
        String repository,
        String status,
        boolean issueFound,
        FailureInfo failure,
        CodeComponentInfo componentAnalysis,
        List<String> callers,
        List<String> apiEndpoints,
        List<String> consumers,
        List<String> downstreamServices) {
}
