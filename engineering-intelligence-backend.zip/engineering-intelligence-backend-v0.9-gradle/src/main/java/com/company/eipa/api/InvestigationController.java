package com.company.eipa.api;

import com.company.eipa.bitbucket.SourceCodeService;
import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.changes.RecentChangeService;
import com.company.eipa.investigation.InvestigationOrchestrator;
import com.company.eipa.model.*;
import com.company.eipa.splunk.SplunkSearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:5173"})
public class InvestigationController {
    private final InvestigationOrchestrator orchestrator;
    private final ServiceCatalog catalog;
    private final SourceCodeService sourceCodeService;
    private final RecentChangeService recentChangeService;
    private final SplunkSearchService splunkSearchService;

    public InvestigationController(InvestigationOrchestrator orchestrator,
                                   ServiceCatalog catalog,
                                   SourceCodeService sourceCodeService,
                                   RecentChangeService recentChangeService,
                                   SplunkSearchService splunkSearchService) {
        this.orchestrator = orchestrator;
        this.catalog = catalog;
        this.sourceCodeService = sourceCodeService;
        this.recentChangeService = recentChangeService;
        this.splunkSearchService = splunkSearchService;
    }

    @PostMapping("/investigations")
    public ResponseEntity<InvestigationResult> investigate(@RequestBody InvestigationRequest request) {
        return ResponseEntity.ok(orchestrator.investigate(request));
    }

    @GetMapping("/catalog/services")
    public Set<String> services() {
        return catalog.serviceNames();
    }

    @GetMapping("/code/services/{service}/files")
    public List<CodeFileInfo> codeFiles(@PathVariable String service) {
        return sourceCodeService.listFiles(service);
    }

    @GetMapping("/code/services/{service}/file")
    public CodeFileContent codeFile(@PathVariable String service,
                                    @RequestParam String path,
                                    @RequestParam(required = false) Integer highlightedLine) {
        return sourceCodeService.getFile(service, path, highlightedLine);
    }

    @GetMapping("/changes/services/{service}")
    public ServiceChangeHistory changeHistory(@PathVariable String service,
                                              @RequestParam(defaultValue = "10") int limit) {
        return recentChangeService.getHistory(service, limit);
    }

    @GetMapping("/logs/search")
    public LogSearchResponse logs(@RequestParam List<String> services,
                                  @RequestParam(defaultValue = "ALL") String service,
                                  @RequestParam(defaultValue = "ALL") String level,
                                  @RequestParam(defaultValue = "") String query,
                                  @RequestParam(defaultValue = "2h") String timeRange,
                                  @RequestParam(required = false) String trackingId,
                                  @RequestParam(required = false) String requestId) {
        return splunkSearchService.searchRelatedLogs(services, service, level, query, timeRange, trackingId, requestId);
    }
}
