package com.company.eipa.splunk;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.config.ConnectorProperties;
import com.company.eipa.model.InvestigationRequest;
import com.company.eipa.model.LogEvent;
import com.company.eipa.model.LogSearchResponse;
import com.company.eipa.logging.LogNormalizer;
import com.company.eipa.monitoring.model.MonitoringRow;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
public class SplunkSearchService {
    private final ServiceCatalog catalog;
    private final ConnectorProperties properties;
    private final ObjectMapper objectMapper;
    private final RestClient restClient;
    private final LogNormalizer logNormalizer;

    public SplunkSearchService(ServiceCatalog catalog,
                               ConnectorProperties properties,
                               ObjectMapper objectMapper,
                               RestClient.Builder builder,
                               LogNormalizer logNormalizer) {
        this.catalog = catalog;
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.logNormalizer = logNormalizer;
        var cfg = properties.splunk();
        this.restClient = cfg != null && StringUtils.hasText(cfg.baseUrl())
                ? builder.baseUrl(cfg.baseUrl()).build()
                : null;
    }

    public List<LogEvent> traceRequest(InvestigationRequest request) {
        if (!StringUtils.hasText(request.service())) {
            throw new IllegalArgumentException("A service must be discovered before service-scoped tracing can run.");
        }
        return traceService(request.service(), request.requestId(), request.timeRange());
    }

    public List<LogEvent> traceService(String serviceName, String requestId, String timeRange) {
        var service = catalog.required(serviceName);
        String indexClause = indexClause(service.splunk().indexes());
        String idFilter = StringUtils.hasText(requestId) ? identifierFilter("request", requestId) : "";
        String search = "search " + indexClause + idFilter + " | sort 0 _time | fields " + normalizationFields();
        return execute(search, normalizeTimeRange(timeRange), serviceName);
    }

    public LogSearchResponse searchRelatedLogs(List<String> relatedServices,
                                               String selectedService,
                                               String level,
                                               String query,
                                               String timeRange,
                                               String trackingId,
                                               String requestId) {
        List<String> services = relatedServices == null ? List.of() : relatedServices.stream().filter(StringUtils::hasText).distinct().toList();
        if (services.isEmpty()) return new LogSearchResponse(List.of(), selectedService, level, query, normalizeTimeRange(timeRange), List.of());

        List<LogEvent> events = new ArrayList<>();
        for (String serviceName : services) {
            if (StringUtils.hasText(selectedService) && !"ALL".equalsIgnoreCase(selectedService) && !serviceName.equalsIgnoreCase(selectedService)) continue;
            var service = catalog.required(serviceName);
            StringBuilder search = new StringBuilder("search ").append(indexClause(service.splunk().indexes()));
            if (StringUtils.hasText(trackingId)) search.append(identifierFilter("tracking", trackingId));
            if (StringUtils.hasText(requestId)) search.append(identifierFilter("request", requestId));
            if (StringUtils.hasText(level) && !"ALL".equalsIgnoreCase(level)) search.append(" level=\"").append(splEscape(level)).append("\"");
            if (StringUtils.hasText(query)) search.append(" \"").append(splEscape(query)).append("\"");
            search.append(" | sort 0 _time | fields ").append(normalizationFields());
            events.addAll(execute(search.toString(), normalizeTimeRange(timeRange), serviceName));
        }
        events.sort(java.util.Comparator.comparing(LogEvent::time));
        return new LogSearchResponse(services, selectedService, level, query, normalizeTimeRange(timeRange), events);
    }


    public List<MonitoringRow> executeMonitoringQuery(String configuredSpl,
                                                      String environment,
                                                      String timeRange,
                                                      String configuredAction,
                                                      String investigationCategory) {
        requireConfigured();
        String range = normalizeTimeRange(timeRange);
        String search = configuredSpl == null ? "" : configuredSpl
                .replace("$earliest$", "-" + range)
                .replace("$latest$", "now")
                .replace("$environment$", splEscape(environment == null ? "" : environment));
        if (!StringUtils.hasText(search)) return List.of();

        MultiValueMap<String,String> form = new LinkedMultiValueMap<>();
        form.add("search", search.stripLeading().startsWith("search ") ? search : "search " + search);
        form.add("output_mode", "json");
        form.add("earliest_time", "-" + range);
        form.add("latest_time", "now");
        String body = restClient.post().uri("/services/search/jobs/export")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED).headers(this::auth).body(form)
                .retrieve().body(String.class);
        if (!StringUtils.hasText(body)) return List.of();

        List<MonitoringRow> rows = new ArrayList<>();
        for (String line : body.split("\\R")) {
            if (!StringUtils.hasText(line)) continue;
            try {
                JsonNode envelope = objectMapper.readTree(line);
                JsonNode result = envelope.has("result") ? envelope.path("result") : envelope;
                if (!result.isObject()) continue;
                String label = firstText(result, List.of("column", "metric", "label", "name", "event_type"), "");
                long count = numericValue(result);
                if (!StringUtils.hasText(label)) continue;
                String action = monitoringAction(configuredAction, label, count);
                String severity = monitoringSeverity(label, action, count);
                String category = "INVESTIGATE".equals(action)
                        ? (StringUtils.hasText(investigationCategory) ? investigationCategory + ":" + label : label)
                        : null;
                rows.add(new MonitoringRow(label, count, action, category, severity));
            } catch (Exception ignored) { }
        }
        return rows;
    }

    private long numericValue(JsonNode result) {
        var fields = result.fields();
        while (fields.hasNext()) {
            var e = fields.next();
            if (List.of("column", "metric", "label", "name", "event_type", "_time").contains(e.getKey())) continue;
            JsonNode value = e.getValue();
            if (value.isNumber()) return value.asLong();
            if (value.isTextual()) {
                try { return Long.parseLong(value.asText().replace(",", "").trim()); } catch (Exception ignored) { }
            }
        }
        return 0L;
    }

    private String monitoringAction(String configuredAction, String label, long count) {
        if (count <= 0) return "METRIC";
        if ("INVESTIGATE".equalsIgnoreCase(configuredAction)) return "INVESTIGATE";
        if ("DRILLDOWN".equalsIgnoreCase(configuredAction)) return "DRILLDOWN";
        String l = label.toLowerCase();
        return (l.contains("fail") || l.contains("error") || l.contains("exception") || l.contains("timeout") || l.contains("not found"))
                ? "INVESTIGATE" : "DRILLDOWN";
    }

    private String monitoringSeverity(String label, String action, long count) {
        if (count <= 0) return "INFO";
        String l = label.toLowerCase();
        if (l.contains("fail") || l.contains("exception") || l.contains("error") || l.contains("timeout")) return "CRITICAL";
        if (l.contains("invalid") || l.contains("locked") || l.contains("disabled") || l.contains("not found")) return "WARNING";
        return "INVESTIGATE".equals(action) ? "HIGH" : "INFO";
    }

    private List<LogEvent> execute(String search, String range, String fallbackService) {
        requireConfigured();
        MultiValueMap<String,String> form = new LinkedMultiValueMap<>();
        form.add("search", search);
        form.add("output_mode", "json");
        form.add("earliest_time", "-" + range);
        form.add("latest_time", "now");

        String body = restClient.post()
                .uri("/services/search/jobs/export")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .headers(this::auth)
                .body(form)
                .retrieve()
                .body(String.class);
        if (!StringUtils.hasText(body)) return List.of();

        List<LogEvent> events = new ArrayList<>();
        for (String line : body.split("\\R")) {
            if (!StringUtils.hasText(line)) continue;
            try {
                JsonNode envelope = objectMapper.readTree(line);
                JsonNode result = envelope.has("result") ? envelope.path("result") : envelope;
                events.add(logNormalizer.normalize(result, fallbackService));
            } catch (Exception ignored) {
                // Ignore non-result control lines returned by the export endpoint.
            }
        }
        int max = properties.splunk().maxResults() > 0 ? properties.splunk().maxResults() : 500;
        return events.size() > max ? events.subList(0, max) : events;
    }

    private void auth(HttpHeaders headers) {
        String token = properties.splunk().token();
        if (!StringUtils.hasText(token)) return;
        if (token.regionMatches(true, 0, "Splunk ", 0, 7) || token.regionMatches(true, 0, "Bearer ", 0, 7) || token.regionMatches(true, 0, "Basic ", 0, 6)) {
            headers.set(HttpHeaders.AUTHORIZATION, token);
        } else {
            headers.set(HttpHeaders.AUTHORIZATION, "Splunk " + token);
        }
    }

    private String indexClause(List<String> indexes) {
        if (indexes == null || indexes.isEmpty()) throw new IllegalStateException("No Splunk indexes are configured for the service.");
        return "(" + indexes.stream().map(i -> "index=\"" + splEscape(i) + "\"").collect(java.util.stream.Collectors.joining(" OR ")) + ")";
    }

    private String identifierFilter(String kind, String value) {
        String v = splEscape(value);
        List<String> fields = "tracking".equals(kind)
                ? List.of("trackingId","tracking_id","TrackingID","correlationId","correlation_id","transactionId","TransactionID","traceId","trace_id","x_b3_traceid")
                : List.of("requestId","request_id","vcap_request_id","x_vcap_request_id","transactionId","TransactionID","trackingId","tracking_id");
        return " (" + fields.stream().map(f -> f + "=\"" + v + "\"").collect(java.util.stream.Collectors.joining(" OR ")) + ")";
    }

    private String normalizationFields() {
        return String.join(" ", List.of(
                "_time","timestamp","time","service","serviceName","application","app","appName","cf_app_name","environment","env","cf_space_name",
                "level","severity","logLevel","message","msg","error","exception","trackingId","tracking_id","TrackingID","correlationId","correlation_id",
                "requestId","request_id","vcap_request_id","transactionId","transaction_id","TransactionID","traceId","trace_id","x_b3_traceid","spanId","span_id","x_b3_spanid",
                "errorCode","error_code","class","className","method","methodName","line","lineNumber","httpStatus","http_status","status","host","source","sourcetype","source_type","_raw"));
    }

    private String normalizeTimeRange(String value) {
        if (!StringUtils.hasText(value)) return "2h";
        String trimmed = value.trim();
        if (!trimmed.matches("[0-9]+[mhd]")) throw new IllegalArgumentException("timeRange must be a bounded value such as 15m, 2h, or 1d");
        return trimmed;
    }

    private String splEscape(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("|", " ").replace("\n", " ").replace("\r", " ");
    }

    private String firstText(JsonNode node, List<String> names, String fallback) {
        for (String name : names) {
            String value = text(node, name, "");
            if (StringUtils.hasText(value)) return value;
        }
        return fallback == null ? "" : fallback;
    }
    private String text(JsonNode node, String field, String fallback) {
        if (node == null || !node.has(field) || node.path(field).isNull()) return fallback;
        String value = node.path(field).asText("");
        return StringUtils.hasText(value) ? value : fallback;
    }
    private void requireConfigured() {
        if (restClient == null) throw new IllegalStateException("Splunk connector is not configured. Set SPLUNK_URL and an approved read-only SPLUNK_TOKEN.");
    }
}
