package com.company.eipa.splunk;

import com.company.eipa.model.FailureInfo;
import com.company.eipa.model.LogEvent;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.regex.Pattern;

@Component
public class StackTraceParser {
    private static final Pattern FRAME = Pattern.compile("(?:at\\s+)?([\\w.$]+)\\.([\\w$]+)\\(([^:()]+):(\\d+)\\)");

    public FailureInfo findPrimaryFailure(List<LogEvent> events) {
        for (var event : events) {
            if (!"ERROR".equalsIgnoreCase(event.level()) && event.exceptionType() == null) continue;
            if (event.className() != null && event.methodName() != null) {
                return new FailureInfo(
                        event.exceptionType() == null ? "Unknown" : event.exceptionType(),
                        event.className(), event.methodName(),
                        fileName(event.className()), event.lineNumber());
            }
            var matcher = FRAME.matcher(event.message() == null ? "" : event.message());
            if (matcher.find()) {
                String fqcn = matcher.group(1);
                return new FailureInfo(
                    extractException(event.message()), fqcn, matcher.group(2), matcher.group(3), Integer.valueOf(matcher.group(4)));
            }
        }
        return new FailureInfo("Unknown", null, null, null, null);
    }

    private String fileName(String fqcn) { if (fqcn == null) return null; int i=fqcn.lastIndexOf('.'); return (i>=0?fqcn.substring(i+1):fqcn) + ".java"; }

    private String extractException(String message) {
        if (message == null) return "Unknown";
        int idx = message.indexOf(" at ");
        String prefix = idx > 0 ? message.substring(0, idx) : message;
        int dot = prefix.lastIndexOf('.');
        return dot >= 0 ? prefix.substring(dot + 1).trim() : prefix.trim();
    }
}
