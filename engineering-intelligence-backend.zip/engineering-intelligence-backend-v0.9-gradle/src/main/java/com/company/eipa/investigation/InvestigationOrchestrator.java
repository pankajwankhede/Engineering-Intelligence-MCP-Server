package com.company.eipa.investigation;

import com.company.eipa.bitbucket.SourceCodeService;
import com.company.eipa.catalog.DependencyTraversalService;
import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.changes.RecentChangeService;
import com.company.eipa.code.ApiFlowAnalyzer;
import com.company.eipa.code.CallerAnalyzer;
import com.company.eipa.code.ConsumerAnalyzer;
import com.company.eipa.code.JavaSourceAnalyzer;
import com.company.eipa.discovery.ServiceDiscoveryService;
import com.company.eipa.model.*;
import com.company.eipa.splunk.SplunkSearchService;
import com.company.eipa.splunk.StackTraceParser;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Service
public class InvestigationOrchestrator {
    private final ServiceCatalog catalog;
    private final DependencyTraversalService traversal;
    private final ServiceDiscoveryService discovery;
    private final SplunkSearchService splunk;
    private final StackTraceParser parser;
    private final SourceCodeService sourceCode;
    private final JavaSourceAnalyzer analyzer;
    private final CallerAnalyzer callers;
    private final ApiFlowAnalyzer apiFlow;
    private final ConsumerAnalyzer consumers;
    private final RecentChangeService recentChangeService;

    public InvestigationOrchestrator(ServiceCatalog catalog,
                                     DependencyTraversalService traversal,
                                     ServiceDiscoveryService discovery,
                                     SplunkSearchService splunk,
                                     StackTraceParser parser,
                                     SourceCodeService sourceCode,
                                     JavaSourceAnalyzer analyzer,
                                     CallerAnalyzer callers,
                                     ApiFlowAnalyzer apiFlow,
                                     ConsumerAnalyzer consumers,
                                     RecentChangeService recentChangeService) {
        this.catalog = catalog;
        this.traversal = traversal;
        this.discovery = discovery;
        this.splunk = splunk;
        this.parser = parser;
        this.sourceCode = sourceCode;
        this.analyzer = analyzer;
        this.callers = callers;
        this.apiFlow = apiFlow;
        this.consumers = consumers;
        this.recentChangeService = recentChangeService;
    }

    public InvestigationResult investigate(InvestigationRequest request) {
        String entryService = discovery.discoverEntryService(request);
        String effectiveRange = request.effectiveTimeRange();
        List<String> order = traversal.traversalOrder(entryService);
        List<ServiceInvestigationStep> flow = new ArrayList<>();
        RootCauseInfo rootCause = null;
        LinkedHashSet<String> impactedTeams = new LinkedHashSet<>();
        List<RecentChangeInfo> recentChanges = new ArrayList<>();

        for (String serviceName : order) {
            var definition = catalog.required(serviceName);
            var logs = splunk.traceService(serviceName, request.primaryIdentifier(), effectiveRange);
            FailureInfo failure = tryFindFailure(logs);
            CodeComponentInfo component = null;
            List<String> callerList = List.of();
            List<String> endpoints = List.of();
            List<String> consumerList = List.of();
            boolean issueFound = false;

            if (failure != null) {
                var source = sourceCode.getSourceContext(serviceName, failure.className(), failure.lineNumber());
                component = analyzer.analyze(source, failure);
                callerList = callers.findCallers(serviceName, failure);
                endpoints = apiFlow.findEndpoints(serviceName, failure);
                consumerList = consumers.findConsumers(serviceName, endpoints);
                issueFound = component.issueFound();
                if (issueFound) recentChanges.addAll(recentChangeService.findRecentChanges(serviceName, failure));
            }

            List<String> downstream = definition.safeDependencies().stream()
                    .map(com.company.eipa.catalog.ServiceDefinition.Dependency::service)
                    .toList();

            String status = issueFound ? "FAILED" : (downstream.isEmpty() ? "HEALTHY" : "IMPACTED");
            impactedTeams.add(definition.ownership().team());

            flow.add(new ServiceInvestigationStep(
                    serviceName,
                    definition.ownership().team(),
                    definition.ownership().businessDomain(),
                    definition.bitbucket().project() + "/" + definition.bitbucket().repository(),
                    status,
                    issueFound,
                    failure,
                    component,
                    callerList,
                    endpoints,
                    consumerList,
                    downstream));

            if (rootCause == null && issueFound) {
                rootCause = new RootCauseInfo(
                        serviceName,
                        definition.ownership().team(),
                        definition.bitbucket().project() + "/" + definition.bitbucket().repository(),
                        failure.className(),
                        failure.methodName(),
                        failure.lineNumber(),
                        "Probable code defect correlated with Splunk failure evidence in " + serviceName,
                        0.91);
            }
        }

        if (rootCause == null) {
            rootCause = new RootCauseInfo(null, null, null, null, null, null,
                    "No code defect confirmed; continue database, configuration, infrastructure, or external dependency investigation.",
                    0.40);
        }

        String investigationId = "INV-" + Instant.now().toEpochMilli();
        return new InvestigationResult(
                investigationId,
                "COMPLETED",
                entryService,
                request.trackingId(),
                request.requestId(),
                request.traceId(),
                request.environment() == null || request.environment().isBlank() ? "PRODUCTION" : request.environment(),
                effectiveRange,
                order,
                flow,
                rootCause,
                List.copyOf(impactedTeams),
                List.copyOf(recentChanges),
                List.of(
                        "Validate the suspected root cause with live Splunk evidence.",
                        "Review incident-related resources in the correlated Bitbucket commit.",
                        "Confirm affected API consumers before remediation.",
                        "Add a regression test before applying a production fix.",
                        "Improve structured logging and dependency timing metrics where evidence is incomplete."));
    }

    private FailureInfo tryFindFailure(List<LogEvent> logs) {
        FailureInfo failure = parser.findPrimaryFailure(logs);
        return failure.className() == null ? null : failure;
    }
}
