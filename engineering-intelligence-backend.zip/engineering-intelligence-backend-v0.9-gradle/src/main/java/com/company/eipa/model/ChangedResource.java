package com.company.eipa.model;

public record ChangedResource(
        String path,
        String type,
        String relevance,
        boolean incidentRelated,
        int additions,
        int deletions) {
}
