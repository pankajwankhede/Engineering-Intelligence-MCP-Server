package com.company.eipa.catalog;

import java.util.List;

public record ServiceDefinition(
        Ownership ownership,
        Splunk splunk,
        Bitbucket bitbucket,
        Code code,
        Api api,
        Runtime runtime,
        List<Dependency> dependencies) {

    public record Ownership(String team, String businessDomain) {}
    public record Splunk(List<String> indexes, String sourcetype, String serviceField) {}
    public record Bitbucket(String project, String repository, String defaultBranch) {}
    public record Code(String language, String sourceRoot) {}
    public record Api(String contextPath) {}
    public record Runtime(String platform) {}
    public record Dependency(String service, String type, String client, String baseUrlKey) {}

    public List<Dependency> safeDependencies() {
        return dependencies == null ? List.of() : dependencies;
    }
}
