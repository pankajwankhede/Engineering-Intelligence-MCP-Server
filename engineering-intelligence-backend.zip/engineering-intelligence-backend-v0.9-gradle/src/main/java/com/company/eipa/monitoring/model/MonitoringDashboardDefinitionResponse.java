package com.company.eipa.monitoring.model;

import java.util.List;

public record MonitoringDashboardDefinitionResponse(
        String dashboardId,
        String title,
        String description,
        List<MonitoringPanelDefinition> panels
) {}
