package com.company.eipa.model;

public record RootCauseInfo(
        String service,
        String ownerTeam,
        String repository,
        String className,
        String methodName,
        Integer lineNumber,
        String reason,
        double confidence) {
}
