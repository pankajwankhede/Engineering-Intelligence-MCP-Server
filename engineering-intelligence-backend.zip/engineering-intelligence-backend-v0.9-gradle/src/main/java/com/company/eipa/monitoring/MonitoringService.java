package com.company.eipa.monitoring;

import com.company.eipa.monitoring.model.MonitoringDashboardResponse;
import com.company.eipa.monitoring.model.MonitoringDashboardSummary;
import com.company.eipa.monitoring.model.MonitoringDashboardDefinitionResponse;
import com.company.eipa.monitoring.model.MonitoringPanelDefinition;
import com.company.eipa.monitoring.model.MonitoringPanelResponse;
import com.company.eipa.splunk.SplunkSearchService;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class MonitoringService {
    private final MonitoringProperties properties;
    private final SplunkSearchService splunk;

    public MonitoringService(MonitoringProperties properties, SplunkSearchService splunk) {
        this.properties = properties;
        this.splunk = splunk;
    }

    public List<MonitoringDashboardSummary> dashboards() {
        return properties.dashboards().entrySet().stream()
                .map(entry -> new MonitoringDashboardSummary(entry.getKey(), entry.getValue().title(), entry.getValue().description(), entry.getValue().panels() == null ? 0 : entry.getValue().panels().size()))
                .toList();
    }

    public MonitoringDashboardDefinitionResponse definition(String dashboardId) {
        var dashboard = requiredDashboard(dashboardId);
        var panels = dashboard.panels() == null ? List.<MonitoringPanelDefinition>of() : dashboard.panels().stream().map(panel -> {
            var query = properties.queries().get(panel.queryRef());
            return new MonitoringPanelDefinition(panel.id(), panel.title(), panel.visualization(), panel.queryRef(), query == null ? "No query description configured" : query.description());
        }).toList();
        return new MonitoringDashboardDefinitionResponse(dashboardId, dashboard.title(), dashboard.description(), panels);
    }

    public MonitoringDashboardResponse dashboard(String dashboardId, String environment, String timeRange) {
        var dashboard = requiredDashboard(dashboardId);
        String env = valueOrDefault(environment, properties.defaultEnvironment(), "");
        String range = valueOrDefault(timeRange, properties.defaultTimeRange(), "15m");
        var panels = dashboard.panels() == null ? List.<MonitoringPanelResponse>of() : dashboard.panels().stream().map(panel -> panel(dashboardId, panel.id(), env, range)).toList();
        return new MonitoringDashboardResponse(dashboardId, dashboard.title(), dashboard.description(), env, range, panels);
    }

    public MonitoringPanelResponse panel(String dashboardId, String panelId, String environment, String timeRange) {
        var dashboard = requiredDashboard(dashboardId);
        if (dashboard.panels() == null) throw new IllegalArgumentException("Dashboard has no panels: " + dashboardId);
        var panel = dashboard.panels().stream().filter(p -> p.id().equals(panelId)).findFirst().orElseThrow(() -> new IllegalArgumentException("Unknown monitoring panel: " + panelId));
        var query = properties.queries().get(panel.queryRef());
        if (query == null) throw new IllegalArgumentException("Unknown monitoring query reference: " + panel.queryRef());
        String env = valueOrDefault(environment, properties.defaultEnvironment(), "");
        String range = valueOrDefault(timeRange, properties.defaultTimeRange(), "15m");
        var rows = splunk.executeMonitoringQuery(query.spl(), env, range, query.action(), query.investigationCategory());
        return new MonitoringPanelResponse(dashboardId, panel.id(), panel.title(), query.description(), panel.visualization(), panel.queryRef(), Instant.now(), rows);
    }

    public String queryDescription(String queryRef) {
        var query = properties.queries().get(queryRef);
        if (query == null) throw new IllegalArgumentException("Unknown monitoring query: " + queryRef);
        return query.description();
    }

    private MonitoringProperties.DashboardDefinition requiredDashboard(String dashboardId) {
        var dashboard = properties.dashboards().get(dashboardId);
        if (dashboard == null) throw new IllegalArgumentException("Unknown monitoring dashboard: " + dashboardId);
        return dashboard;
    }
    private String valueOrDefault(String value, String configured, String fallback) {
        if (value != null && !value.isBlank()) return value;
        if (configured != null && !configured.isBlank()) return configured;
        return fallback;
    }
}
