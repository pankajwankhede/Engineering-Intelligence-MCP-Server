package com.company.eipa.monitoring.model;

import java.util.List;

public record MonitoringDashboardResponse(
        String dashboardId,
        String title,
        String description,
        String environment,
        String timeRange,
        List<MonitoringPanelResponse> panels
) {}
