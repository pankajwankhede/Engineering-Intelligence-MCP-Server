package com.company.eipa.mcp;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.investigation.InvestigationOrchestrator;
import com.company.eipa.model.InvestigationRequest;
import com.company.eipa.model.InvestigationResult;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class EngineeringIntelligenceTools {
    private final InvestigationOrchestrator orchestrator;
    private final ServiceCatalog catalog;

    public EngineeringIntelligenceTools(InvestigationOrchestrator orchestrator, ServiceCatalog catalog) {
        this.orchestrator = orchestrator;
        this.catalog = catalog;
    }

    @Tool(description = "Investigate a production issue using any known identifier. Service is optional. EIPA discovers the entry service, traces configured downstream services, correlates Splunk evidence with the mapped Bitbucket repositories, analyzes code, consumers, recent changes/resources and returns probable root cause and blast radius evidence.")
    public InvestigationResult investigateProductionIssue(
            String service,
            String trackingId,
            String requestId,
            String traceId,
            String apiUrl,
            String errorOrException,
            String description,
            String environment,
            String timeRange) {
        return orchestrator.investigate(new InvestigationRequest(service, trackingId, requestId, traceId,
                apiUrl, errorOrException, description, environment, timeRange));
    }

    @Tool(description = "List all services currently registered in the Engineering Intelligence service catalog.")
    public Set<String> listRegisteredServices() {
        return catalog.serviceNames();
    }
}
