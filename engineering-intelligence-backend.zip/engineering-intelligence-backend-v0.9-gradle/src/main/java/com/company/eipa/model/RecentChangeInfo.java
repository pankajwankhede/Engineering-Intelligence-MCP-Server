package com.company.eipa.model;

import java.util.List;
import java.util.Map;

public record RecentChangeInfo(
        String commit,
        String author,
        String timestamp,
        String message,
        String correlation,
        String risk,
        int totalResources,
        int incidentRelatedResources,
        Map<String, Integer> resourceTypeCounts,
        List<ChangedResource> resources) {
}
