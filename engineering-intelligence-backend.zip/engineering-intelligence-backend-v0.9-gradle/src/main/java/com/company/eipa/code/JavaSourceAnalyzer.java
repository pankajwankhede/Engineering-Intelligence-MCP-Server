package com.company.eipa.code;

import com.company.eipa.model.CodeComponentInfo;
import com.company.eipa.model.FailureInfo;
import org.springframework.stereotype.Component;

@Component
public class JavaSourceAnalyzer {
    public CodeComponentInfo analyze(String source, FailureInfo failure) {
        if (source == null) {
            return new CodeComponentInfo("Unknown", "Unknown", false, "No source context was retrieved.");
        }

        boolean paymentNull = source.contains("paymentGateway.process") && source.contains("response.getTransactionId()") && !source.contains("response == null");
        boolean accountNull = source.contains("accountRepository.find") && source.contains("account.getId()") && !source.contains("account == null");
        boolean issueFound = paymentNull || accountNull;

        String classPurpose;
        String methodPurpose;
        if (failure.className() != null && failure.className().contains("AccountProcessor")) {
            classPurpose = "Coordinates account lookup and maps repository data into the service domain response.";
            methodPurpose = "Loads an account from the repository and converts it into the returned account model.";
        } else {
            classPurpose = "Coordinates payment processing with an external payment gateway.";
            methodPurpose = "Calls the payment gateway and converts its response into the service response.";
        }

        String issue = issueFound
                ? "A returned object is dereferenced without an explicit null check in the retrieved failure context."
                : "No deterministic code issue identified from the retrieved source context.";

        return new CodeComponentInfo(classPurpose, methodPurpose, issueFound, issue);
    }
}
