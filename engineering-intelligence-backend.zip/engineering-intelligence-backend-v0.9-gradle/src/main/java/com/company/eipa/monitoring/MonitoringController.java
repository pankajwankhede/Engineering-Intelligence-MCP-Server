package com.company.eipa.monitoring;

import com.company.eipa.investigation.InvestigationOrchestrator;
import com.company.eipa.model.InvestigationRequest;
import com.company.eipa.model.InvestigationResult;
import com.company.eipa.monitoring.model.MonitoringDashboardResponse;
import com.company.eipa.monitoring.model.MonitoringInvestigationRequest;
import com.company.eipa.monitoring.model.MonitoringDashboardSummary;
import com.company.eipa.monitoring.model.MonitoringDashboardDefinitionResponse;
import com.company.eipa.monitoring.model.MonitoringPanelResponse;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/monitoring")
@CrossOrigin(origins = "*")
public class MonitoringController {

    private final MonitoringService monitoringService;
    private final InvestigationOrchestrator investigationOrchestrator;

    public MonitoringController(MonitoringService monitoringService,
                                InvestigationOrchestrator investigationOrchestrator) {
        this.monitoringService = monitoringService;
        this.investigationOrchestrator = investigationOrchestrator;
    }

    @GetMapping("/dashboards")
    public List<MonitoringDashboardSummary> dashboards() {
        return monitoringService.dashboards();
    }

    @GetMapping("/dashboards/{dashboardId}/definition")
    public MonitoringDashboardDefinitionResponse definition(@PathVariable String dashboardId) {
        return monitoringService.definition(dashboardId);
    }

    @GetMapping("/dashboards/{dashboardId}")
    public MonitoringDashboardResponse dashboard(@PathVariable String dashboardId,
                                                  @RequestParam(required = false) String environment,
                                                  @RequestParam(required = false) String timeRange) {
        return monitoringService.dashboard(dashboardId, environment, timeRange);
    }

    @GetMapping("/dashboards/{dashboardId}/panels/{panelId}")
    public MonitoringPanelResponse panel(@PathVariable String dashboardId,
                                         @PathVariable String panelId,
                                         @RequestParam(required = false) String environment,
                                         @RequestParam(required = false) String timeRange) {
        return monitoringService.panel(dashboardId, panelId, environment, timeRange);
    }

    @PostMapping("/investigate")
    public InvestigationResult investigate(@RequestBody MonitoringInvestigationRequest request) {
        String description = "Monitoring investigation triggered from dashboard=" + request.dashboardId()
                + ", panel=" + request.panelId()
                + ", metric=" + request.metricLabel()
                + ", category=" + request.investigationCategory();

        var investigationRequest = new InvestigationRequest(
                null,
                request.trackingId(),
                request.requestId(),
                request.traceId(),
                null,
                request.metricLabel(),
                description,
                request.environment(),
                request.timeRange()
        );
        return investigationOrchestrator.investigate(investigationRequest);
    }
}
