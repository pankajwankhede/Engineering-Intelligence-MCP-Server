package com.company.eipa.catalog;

import org.springframework.stereotype.Service;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class DependencyTraversalService {
    private final ServiceCatalog catalog;

    public DependencyTraversalService(ServiceCatalog catalog) {
        this.catalog = catalog;
    }

    public List<String> traversalOrder(String entryService) {
        record Node(String service, int depth) {}

        List<String> ordered = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        ArrayDeque<Node> queue = new ArrayDeque<>();
        queue.add(new Node(entryService, 0));

        while (!queue.isEmpty()) {
            Node node = queue.removeFirst();
            if (!visited.add(node.service())) {
                continue;
            }

            ordered.add(node.service());
            if (node.depth() >= catalog.maxTraversalDepth()) {
                continue;
            }

            for (var dependency : catalog.required(node.service()).safeDependencies()) {
                if (catalog.services().containsKey(dependency.service()) && !visited.contains(dependency.service())) {
                    queue.addLast(new Node(dependency.service(), node.depth() + 1));
                }
            }
        }

        return ordered;
    }
}
