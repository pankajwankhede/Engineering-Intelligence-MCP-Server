# EIPA Standard JSON Logging Contract

EIPA supports **both** the new JSON contract and existing legacy/raw logs. Services can migrate gradually.

## Recommended fields for new services

```json
{
  "timestamp": "2026-08-16T15:41:46.949Z",
  "service": "<application-name>",
  "environment": "PRODUCTION",
  "level": "ERROR",
  "trackingId": "<tracking-id>",
  "requestId": "<request-id>",
  "transactionId": "<transaction-id>",
  "traceId": "<distributed-trace-id>",
  "spanId": "<span-id>",
  "className": "com.company.feature.SomeService",
  "methodName": "process",
  "errorCode": "DOMAIN_ERROR_CODE",
  "exceptionType": "java.lang.IllegalStateException",
  "httpStatus": 500,
  "message": "Operation failed",
  "attributes": {"endpoint":"/api/example"}
}
```

Do not log passwords, access tokens, authorization headers, session cookies, full account numbers, or other restricted data.

## Backward compatibility

`LogNormalizer` attempts, in order:
1. Splunk structured fields
2. embedded JSON in `_raw`
3. configured field aliases (`cf_app_name`, `TransactionID`, `vcap_request_id`, `x_b3_traceid`, etc.)
4. Java class/method/line extraction from raw text
5. key/value extraction from semi-structured messages
6. generic raw-text fallback

Every normalized event retains `originalFields` and `raw`, and includes `format` + `parseConfidence`.

## Migration strategy

- Phase 1: no producer changes; EIPA normalizes current Splunk events.
- Phase 2: add IDs and service fields to high-value services.
- Phase 3: emit the full JSON contract for new/modernized services.
- Phase 4: use the JSON contract as the organization logging standard while retaining the legacy parsers.

`StandardLogEvent` and `StandardLogEmitter` are reference implementations that can later move to a shared organization logging starter.
