# v0.8 Dynamic Source/Change Integration

The UI is fully backend-response driven. This backend revision also removes service-specific source-code and commit-history branching from the Java implementation.

## Dynamic Bitbucket behavior

`SourceCodeService` resolves the selected service through the service catalog and then calls the mapped Bitbucket project/repository/branch:

- repository file list: Bitbucket REST `/files`
- selected raw file: Bitbucket REST `/raw/{path}`

`RecentChangeService` similarly resolves the mapped repository and loads:

- latest commits
- changed resources for each commit
- pull requests

No Java code contains payment/account-specific class or method selection logic for those endpoints.

Configure read-only connection values with:

- `BITBUCKET_URL`
- `BITBUCKET_USERNAME`
- `BITBUCKET_TOKEN`

The service catalog in `application.yml` is sample configuration and is intended to be replaced with organization service mappings or an external catalog/CMDB.
