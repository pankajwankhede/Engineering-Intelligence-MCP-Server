# v0.9 - Fully Dynamic UI / Generic Backend

## Important

The React UI contains **no business/service-specific sample data**. It does not know about payment, account,
merchant, or any named application. All service names, repositories, classes, methods, APIs, consumers,
commits, PRs, logs, root-cause details, teams, and recommendations are rendered from backend responses.

The backend code analyzers were also changed to remove domain-specific hardcoded class/method/consumer/API values.

### Dynamic sources

- Service names/ownership/repository/index mapping: EIPA service catalog
- Logs/trace/service discovery: Splunk connector
- File tree/file contents: Bitbucket connector
- Last 10 commits/PRs/changed resources: Bitbucket connector
- Callers: repository source scan (POC implementation; replace with JavaParser/Spoon/CodeQL for scale)
- API endpoint discovery: repository Spring annotation scan
- Consumers: reverse service dependencies from catalog (runtime gateway/Splunk consumer merge can be added)
- Monitoring panels: backend monitoring dashboard/query definitions and live Splunk results

No proprietary Splunk query is included. Existing dummy monitoring SPL remains clearly marked as sample only.
