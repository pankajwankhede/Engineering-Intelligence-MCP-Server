# Engineering Intelligence Backend v0.9 (Gradle)

Spring Boot + MCP backend for Monitoring and EIPA Production Investigation.

## v0.9 dynamic behavior

- Splunk log/trace searches execute through the configured Splunk REST export endpoint.
- Monitoring panels execute their configured SPL dynamically; `MonitoringService` no longer contains static metric rows.
- Code Analysis resolves the service through the service catalog, then loads the file list and selected raw file from the mapped Bitbucket project/repository/branch.
- Recent Changes resolves the selected service repository dynamically and loads latest commits, commit resources, and pull requests from Bitbucket REST APIs.
- No Java branch selects payment/account/service-A/B/C source files or method names.
- The service catalog and monitoring definitions in `application.yml` are **sample configuration** intended to be replaced with organization mappings and approved dummy/real query definitions.

## Required connector settings

```text
SPLUNK_URL
SPLUNK_TOKEN
BITBUCKET_URL
BITBUCKET_USERNAME
BITBUCKET_TOKEN
```

Use read-only service credentials/tokens and keep secrets outside Git (Vault/CredHub/secret manager/environment injection).

## Important: bundled monitoring SPL

The monitoring SPL in this package remains intentionally dummy/sample SPL only. No original/proprietary query supplied by the user is included. Replace query definitions with approved searches or saved-search integration.

## Main APIs

```text
POST /api/investigations
GET  /api/logs/search
GET  /api/code/services/{service}/files
GET  /api/code/services/{service}/file
GET  /api/changes/services/{service}?limit=10
GET  /api/monitoring/dashboards
GET  /api/monitoring/dashboards/{dashboardId}/definition
GET  /api/monitoring/dashboards/{dashboardId}/panels/{panelId}
POST /api/monitoring/investigate
```

## Run in IntelliJ

1. Extract the backend ZIP.
2. Open the extracted folder in IntelliJ IDEA.
3. Import `build.gradle` as a Gradle project.
4. Use Java 21.
5. Configure connector environment variables.
6. Run `EngineeringIntelligenceApplication`.

A Gradle Wrapper is not included because Gradle is not installed in the packaging environment.
