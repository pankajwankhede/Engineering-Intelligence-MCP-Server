# Dummy Splunk Query Guide

This repository intentionally does **not** include any original/proprietary Splunk queries.

The dummy queries in `src/main/resources/application.yml` exist only to show how an existing Splunk dashboard can be mapped into the Engineering Intelligence Monitoring UI.

## Mapping

### `authentication-service-calls-demo`
Represents a high-level authentication-service dashboard panel. Typical real metrics may include portal launch, partner identity request/response, login-service exceptions, network exceptions, etc.

### `idp-authentication-calls-demo`
Represents the IDP authentication panel. Typical real metrics may include authentication request, success response, failure response, transmit request/response and session/cache exceptions.

The UI marks `IDP failure responses` as an `INVESTIGATE` row. Clicking it can launch EIPA.

### `login-user-authentication-demo`
Represents user-login authentication outcomes such as login requests, database success, disabled/locked/invalid users and exceptions.

### `portal-launch-demo`
Represents portal/IDP launch and OAuth/session metrics such as launch success, session-not-found, OAuth requests and OAuth exceptions.

### `partner-identity-demo`
Represents partner-identity request, response and failure metrics.

## Production replacement options

Option A: replace only the dummy `spl:` body with the approved SPL.

Option B (recommended): store a `saved-search-name`/report reference instead of SPL and let the backend execute the Splunk saved search. This keeps proprietary SPL in Splunk rather than application source code.

## Action types

- `METRIC`: display only.
- `DRILLDOWN`: show matching Splunk events/details.
- `INVESTIGATE`: start EIPA and correlate Splunk evidence with source code, service flow, API consumers, callers, recent changes and blast radius.
