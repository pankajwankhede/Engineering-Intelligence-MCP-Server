package com.company.eipa.bitbucket;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.config.ConnectorProperties;
import org.springframework.stereotype.Service;

@Service
public class SourceCodeService {
    private final ServiceCatalog catalog;
    private final ConnectorProperties properties;

    public SourceCodeService(ServiceCatalog catalog, ConnectorProperties properties) {
        this.catalog = catalog;
        this.properties = properties;
    }

    public String getSourceContext(String serviceName, String className, Integer lineNumber) {
        var service = catalog.required(serviceName);
        String repo = service.bitbucket().project() + "/" + service.bitbucket().repository();
        String branch = service.bitbucket().defaultBranch();

        // POC hook: resolve FQCN -> source path and call the mapped repository's Bitbucket source/raw API.
        // This method intentionally resolves the repository PER SERVICE, allowing A/B/C to live in different projects.
        if ("service-c".equals(serviceName)) {
            return """
                // DEMO SOURCE CONTEXT
                // repo: %s branch=%s
                public class AccountProcessor {
                    public Account findAccount(String accountId) {
                        Account account = accountRepository.find(accountId);
                        return new Account(account.getId()); // suspected null dereference
                    }
                }
                """.formatted(repo, branch);
        }

        return """
            // DEMO SOURCE CONTEXT
            // repo: %s branch=%s
            public class PaymentProcessor {
                public PaymentResponse processPayment(PaymentRequest request) {
                    PaymentResponse response = paymentGateway.process(request);
                    return new PaymentResponse(response.getTransactionId()); // suspected null dereference
                }
            }
            """.formatted(repo, branch);
    }
}
