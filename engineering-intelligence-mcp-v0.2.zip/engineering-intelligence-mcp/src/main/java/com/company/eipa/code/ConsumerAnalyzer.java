package com.company.eipa.code;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ConsumerAnalyzer {
    public List<String> findConsumers(String service, List<String> endpoints) {
        // POC placeholder. Production: combine gateway/service-catalog data with Splunk runtime callers.
        if ("service-c".equals(service)) {
            return List.of("service-b");
        }
        if ("service-b".equals(service)) {
            return List.of("service-a");
        }
        return List.of("checkout-service", "mobile-bff", "merchant-portal");
    }
}
