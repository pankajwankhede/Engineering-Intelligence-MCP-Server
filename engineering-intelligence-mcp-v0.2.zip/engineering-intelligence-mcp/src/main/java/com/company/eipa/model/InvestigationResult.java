package com.company.eipa.model;

import java.util.List;

public record InvestigationResult(
        String status,
        String entryService,
        String requestId,
        List<String> traversalOrder,
        List<ServiceInvestigationStep> serviceFlow,
        RootCauseInfo rootCause,
        List<String> impactedTeams,
        List<String> recommendations) {
}
