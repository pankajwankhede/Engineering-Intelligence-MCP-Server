package com.company.eipa.code;

import com.company.eipa.model.FailureInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CallerAnalyzer {
    public List<String> findCallers(String service, FailureInfo failure) {
        // POC placeholder. Production: JavaParser/Spoon/CodeQL or a prebuilt code index.
        if ("service-c".equals(service)) {
            return List.of("AccountService.getAccount", "AccountController.getAccount");
        }
        return List.of("PaymentService.submit", "RefundService.retryPayment", "BatchPaymentJob.process");
    }
}
