package com.company.eipa.code;

import com.company.eipa.model.FailureInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ApiFlowAnalyzer {
    public List<String> findEndpoints(String service, FailureInfo failure) {
        // POC placeholder. Production: parse Spring @RequestMapping mappings and build a call graph.
        if ("service-c".equals(service)) {
            return List.of("GET /service-c/api/v1/accounts/{accountId}");
        }
        return List.of("POST /api/v1/payments");
    }
}
