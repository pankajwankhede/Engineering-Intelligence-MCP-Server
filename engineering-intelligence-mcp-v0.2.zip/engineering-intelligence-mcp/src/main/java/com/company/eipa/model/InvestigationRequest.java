package com.company.eipa.model;

public record InvestigationRequest(String service, String requestId, String timeRange) {}
