package com.company.eipa.model;

public record LogEvent(String time, String service, String level, String message, String raw) {}
