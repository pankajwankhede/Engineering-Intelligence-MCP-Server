package com.company.eipa.investigation;

import com.company.eipa.bitbucket.SourceCodeService;
import com.company.eipa.catalog.DependencyTraversalService;
import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.code.ApiFlowAnalyzer;
import com.company.eipa.code.CallerAnalyzer;
import com.company.eipa.code.ConsumerAnalyzer;
import com.company.eipa.code.JavaSourceAnalyzer;
import com.company.eipa.model.CodeComponentInfo;
import com.company.eipa.model.FailureInfo;
import com.company.eipa.model.InvestigationRequest;
import com.company.eipa.model.InvestigationResult;
import com.company.eipa.model.RootCauseInfo;
import com.company.eipa.model.ServiceInvestigationStep;
import com.company.eipa.splunk.SplunkSearchService;
import com.company.eipa.splunk.StackTraceParser;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

@Service
public class InvestigationOrchestrator {
    private final ServiceCatalog catalog;
    private final DependencyTraversalService traversal;
    private final SplunkSearchService splunk;
    private final StackTraceParser parser;
    private final SourceCodeService sourceCode;
    private final JavaSourceAnalyzer analyzer;
    private final CallerAnalyzer callers;
    private final ApiFlowAnalyzer apiFlow;
    private final ConsumerAnalyzer consumers;

    public InvestigationOrchestrator(ServiceCatalog catalog,
                                     DependencyTraversalService traversal,
                                     SplunkSearchService splunk,
                                     StackTraceParser parser,
                                     SourceCodeService sourceCode,
                                     JavaSourceAnalyzer analyzer,
                                     CallerAnalyzer callers,
                                     ApiFlowAnalyzer apiFlow,
                                     ConsumerAnalyzer consumers) {
        this.catalog = catalog;
        this.traversal = traversal;
        this.splunk = splunk;
        this.parser = parser;
        this.sourceCode = sourceCode;
        this.analyzer = analyzer;
        this.callers = callers;
        this.apiFlow = apiFlow;
        this.consumers = consumers;
    }

    public InvestigationResult investigate(InvestigationRequest request) {
        List<String> order = traversal.traversalOrder(request.service());
        List<ServiceInvestigationStep> flow = new ArrayList<>();
        RootCauseInfo rootCause = null;
        LinkedHashSet<String> impactedTeams = new LinkedHashSet<>();

        for (String serviceName : order) {
            var definition = catalog.required(serviceName);
            var logs = splunk.traceService(serviceName, request.requestId(), request.timeRange());
            FailureInfo failure = tryFindFailure(logs);
            CodeComponentInfo component = null;
            List<String> callerList = List.of();
            List<String> endpoints = List.of();
            List<String> consumerList = List.of();
            boolean issueFound = false;

            if (failure != null) {
                var source = sourceCode.getSourceContext(serviceName, failure.className(), failure.lineNumber());
                component = analyzer.analyze(source, failure);
                callerList = callers.findCallers(serviceName, failure);
                endpoints = apiFlow.findEndpoints(serviceName, failure);
                consumerList = consumers.findConsumers(serviceName, endpoints);
                issueFound = component.issueFound();
            }

            List<String> downstream = definition.safeDependencies().stream()
                    .map(com.company.eipa.catalog.ServiceDefinition.Dependency::service)
                    .toList();

            String status = issueFound ? "FAILED" : (downstream.isEmpty() ? "HEALTHY" : "IMPACTED");
            impactedTeams.add(definition.ownership().team());

            flow.add(new ServiceInvestigationStep(
                    serviceName,
                    definition.ownership().team(),
                    definition.ownership().businessDomain(),
                    definition.bitbucket().project() + "/" + definition.bitbucket().repository(),
                    status,
                    issueFound,
                    failure,
                    component,
                    callerList,
                    endpoints,
                    consumerList,
                    downstream));

            if (rootCause == null && issueFound) {
                rootCause = new RootCauseInfo(
                        serviceName,
                        definition.ownership().team(),
                        definition.bitbucket().project() + "/" + definition.bitbucket().repository(),
                        failure.className(),
                        failure.methodName(),
                        failure.lineNumber(),
                        "Probable code defect correlated with Splunk failure evidence in " + serviceName,
                        0.90);
            }
        }

        if (rootCause == null) {
            var entry = catalog.required(request.service());
            rootCause = new RootCauseInfo(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    "No code defect confirmed in traversed services; continue runtime, database, configuration, or external dependency investigation.",
                    0.40);
        }

        return new InvestigationResult(
                "COMPLETED",
                request.service(),
                request.requestId(),
                order,
                flow,
                rootCause,
                List.copyOf(impactedTeams),
                List.of(
                        "Validate the suspected root cause with live Splunk evidence.",
                        "Review recent commits in the root-cause service repository.",
                        "Confirm impacted API consumers before remediation.",
                        "Add a regression test before applying a production fix."));
    }

    private FailureInfo tryFindFailure(List<com.company.eipa.model.LogEvent> logs) {
        FailureInfo failure = parser.findPrimaryFailure(logs);
        return failure.className() == null ? null : failure;
    }

}
