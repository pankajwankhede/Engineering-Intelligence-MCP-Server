package com.company.eipa.splunk;

import com.company.eipa.catalog.ServiceCatalog;
import com.company.eipa.config.ConnectorProperties;
import com.company.eipa.model.InvestigationRequest;
import com.company.eipa.model.LogEvent;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SplunkSearchService {
    private final ServiceCatalog catalog;
    private final ConnectorProperties properties;

    public SplunkSearchService(ServiceCatalog catalog, ConnectorProperties properties) {
        this.catalog = catalog;
        this.properties = properties;
    }

    public List<LogEvent> traceRequest(InvestigationRequest request) {
        return traceService(request.service(), request.requestId(), request.timeRange());
    }

    public List<LogEvent> traceService(String serviceName, String requestId, String timeRange) {
        var service = catalog.required(serviceName);
        String indexExpression = String.join(" OR index=", service.splunk().indexes());
        String earliest = normalizeTimeRange(timeRange);

        String safeSearch = "search (index=" + indexExpression + ")"
                + " requestId=\"" + sanitize(requestId) + "\" earliest=-" + earliest
                + " | sort _time | fields _time service level message traceId requestId _raw";

        if (properties.splunk() == null || properties.splunk().baseUrl() == null || properties.splunk().baseUrl().isBlank()) {
            return demoEvents(serviceName, safeSearch);
        }

        // POC hook: call Splunk /services/search/jobs/export or async search job APIs here.
        // Credentials remain in ConnectorProperties/Vault and are never supplied by MCP clients.
        return demoEvents(serviceName, safeSearch);
    }

    private String normalizeTimeRange(String value) {
        if (value == null || value.isBlank()) return "2h";
        return value.matches("[0-9]+[mhd]") ? value : "2h";
    }

    private String sanitize(String value) {
        if (value == null) return "";
        return value.replace("\\", "").replace("\"", "").replace("|", "");
    }

    private List<LogEvent> demoEvents(String service, String search) {
        if ("service-c".equals(service)) {
            return List.of(
                    new LogEvent("2026-08-16T10:21:03Z", service, "INFO", "Account lookup started", search),
                    new LogEvent("2026-08-16T10:21:04Z", service, "ERROR",
                            "java.lang.NullPointerException at com.company.account.service.AccountProcessor.findAccount(AccountProcessor.java:211)",
                            "DEMO cross-service failure - configure SPLUNK_URL and SPLUNK_TOKEN for live search")
            );
        }
        if ("payment-service".equals(service)) {
            return List.of(
                    new LogEvent("2026-08-16T10:21:03Z", service, "INFO", "Payment processing started", search),
                    new LogEvent("2026-08-16T10:21:04Z", service, "ERROR",
                            "java.lang.NullPointerException at com.company.payment.service.PaymentProcessor.processPayment(PaymentProcessor.java:184)",
                            "DEMO event - configure SPLUNK_URL and SPLUNK_TOKEN for live search")
            );
        }
        return List.of(new LogEvent(
                "2026-08-16T10:21:03Z", service, "INFO",
                "Request processed; downstream call continued for requestId=" + sanitize(search),
                "DEMO healthy/impacted service event"));
    }
}
