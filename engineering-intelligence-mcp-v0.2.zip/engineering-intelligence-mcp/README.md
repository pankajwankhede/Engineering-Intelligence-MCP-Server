# Engineering Intelligence / Production Investigation MCP Server

Import this folder into IntelliJ IDEA as a Maven project.

## What works in the POC
- Spring Boot MCP server
- `investigateProductionIssue` MCP tool
- Service catalog mapping
- Splunk search boundary/query hook (demo events until credentials/API mapping are configured)
- Stack-trace extraction: exception/class/method/file/line
- Bitbucket source retrieval hook (demo source until enterprise API shape is configured)
- Class/method purpose + issue analysis
- Caller, API endpoint, consumer placeholders
- Structured RCA response

## Requirements
- Java 21+
- Maven 3.9+

## Run
```bash
mvn spring-boot:run
```

Health:
```bash
curl http://localhost:8080/actuator/health
```

## Enterprise connector environment variables
```text
SPLUNK_URL=https://splunk.company.com:8089
SPLUNK_TOKEN=<read-only token from Vault/CredHub>
BITBUCKET_URL=https://bitbucket.company.com
BITBUCKET_USERNAME=<service account>
BITBUCKET_TOKEN=<read-only token from Vault/CredHub>
```
Do not commit credentials.

## Next implementation steps
1. Replace `SplunkSearchService.demoEvents()` with Splunk REST `/services/search/jobs/export` or search-job flow.
2. Replace `SourceCodeService` demo source with Bitbucket read-only source API.
3. Replace caller/API placeholders with JavaParser/Spoon/CodeQL-backed analysis.
4. Add recent commit/PR and deployment correlation.
5. Add authorization, PII masking, query allowlists, time-window limits, and audit logging before enterprise use.

## MCP
The project uses Spring AI's MCP WebMVC server starter. `application.yml` configures Streamable HTTP transport. Connect your approved MCP client to the server's MCP endpoint according to the Spring AI version/client configuration used in your environment.


## v0.2 Cross-service investigation

The service catalog is now YAML-driven. A service can depend on another service owned by a different platform team and stored in a different Bitbucket project/repository.

Example configured demo flow:

```text
service-a (PROJA/service-a)
   -> REST -> service-b (PROJB/service-b)
                 -> REST -> service-c (PROJC/service-c)
```

Call the MCP `investigateProductionIssue` tool with `service-a` and a request ID. The orchestrator traverses dependencies with a visited-service set and `max-traversal-depth`, queries each service's mapped Splunk index, switches to that service's Bitbucket repository when code analysis is required, and returns `serviceFlow`, `rootCause`, and impacted ownership teams.

To add another service, add one entry under `eipa.catalog.services` in `application.yml`; no Java catalog code change is required. For enterprise scale, replace the YAML catalog with Backstage/ServiceNow CMDB/database while keeping the same `ServiceCatalog` abstraction.
