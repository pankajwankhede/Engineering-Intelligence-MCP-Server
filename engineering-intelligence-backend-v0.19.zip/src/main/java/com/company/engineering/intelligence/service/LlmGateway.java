package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.Interpretation;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class LlmGateway {
    private static final Pattern SERVICE = Pattern.compile("(?:in|service)\s+([a-zA-Z0-9_-]+(?:-service)?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXCEPTION = Pattern.compile("([A-Za-z0-9_]+Exception)", Pattern.CASE_INSENSITIVE);
    private final PlatformProperties properties;

    public LlmGateway(PlatformProperties properties) { this.properties = properties; }

    public Interpretation interpret(String query) {
        // This deterministic fallback keeps the app usable without an LLM.
        // Replace/extend this method with your org's GitHub Copilot/LLM Gateway HTTP contract.
        String service = find(SERVICE, query, "unknown-service");
        String exception = find(EXCEPTION, query, null);
        String intent = exception == null ? "Investigate Service" : "Investigate Exception";
        int confidence = properties.llm().enabled() ? 97 : 90;
        return new Interpretation(intent, service, exception, confidence);
    }

    private String find(Pattern pattern, String value, String fallback) {
        Matcher m = pattern.matcher(value == null ? "" : value);
        return m.find() ? m.group(1) : fallback;
    }
}
