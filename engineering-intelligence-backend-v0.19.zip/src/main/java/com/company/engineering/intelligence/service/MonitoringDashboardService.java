package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class MonitoringDashboardService {
    private final PlatformProperties properties;

    public MonitoringDashboardService(PlatformProperties properties) { this.properties = properties; }

    public List<MonitoringDashboardSummary> dashboards() {
        if (properties.monitoring() == null || properties.monitoring().dashboards() == null) return List.of();
        return properties.monitoring().dashboards().entrySet().stream()
                .map(e -> new MonitoringDashboardSummary(e.getKey(), e.getValue().title(), e.getValue().description(), safePanels(e.getValue()).size()))
                .toList();
    }

    public MonitoringDashboardDefinition dashboard(String id) {
        PlatformProperties.Dashboard d = dashboardConfig(id);
        return new MonitoringDashboardDefinition(id, d.title(), d.description(), safePanels(d).stream()
                .map(p -> new DashboardPanelDefinition(p.id(), p.title(), p.queryRef(), defaulted(p.visualization(), "table"))).toList());
    }

    public ConfiguredPanelResult panel(String dashboardId, String panelId, String service, String environment, String timeRange, boolean failuresOnly) {
        PlatformProperties.Dashboard d = dashboardConfig(dashboardId);
        PlatformProperties.Panel p = safePanels(d).stream().filter(x -> x.id().equals(panelId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown panel: " + panelId));
        String spl = resolveSpl(p.queryRef());
        String svc = defaulted(service, "ALL");
        String env = defaulted(environment, "PRODUCTION");
        spl = spl.replace("$service$", "ALL".equalsIgnoreCase(svc) ? "*" : svc).replace("$environment$", env);
        List<SplunkEvent> rows = demoEvents();
        if (failuresOnly) rows = rows.stream().filter(x -> "ERROR".equals(x.level())).toList();
        return new ConfiguredPanelResult(dashboardId, panelId, p.title(), p.queryRef(), defaulted(p.visualization(), "table"),
                svc, env, defaulted(timeRange, "Last 15 Minutes"), metrics(panelId),
                List.of(8,12,10,15,13,20,16,19,24,18,21), rows, spl);
    }

    private PlatformProperties.Dashboard dashboardConfig(String id) {
        if (properties.monitoring() == null || properties.monitoring().dashboards() == null || !properties.monitoring().dashboards().containsKey(id))
            throw new IllegalArgumentException("Unknown dashboard: " + id);
        return properties.monitoring().dashboards().get(id);
    }
    private List<PlatformProperties.Panel> safePanels(PlatformProperties.Dashboard d){ return d.panels()==null?List.of():d.panels(); }
    private String resolveSpl(String ref) {
        if (properties.splunk()!=null && properties.splunk().queries()!=null && properties.splunk().queries().get(ref)!=null)
            return properties.splunk().queries().get(ref).spl();
        return "query-ref=" + ref;
    }
    private List<PanelMetric> metrics(String id) {
        return switch (id) {
            case "authentication-service-calls" -> List.of(new PanelMetric("Requests","12,540",null),new PanelMetric("Success","12,210","ok"),new PanelMetric("Failure","330","bad"));
            case "idp-authentication-calls" -> List.of(new PanelMetric("Requests","8,925",null),new PanelMetric("Success","8,712","ok"),new PanelMetric("Failure","213","bad"));
            case "login-user-authentication" -> List.of(new PanelMetric("Success","7,984","ok"),new PanelMetric("Invalid User","142","warn"),new PanelMetric("Locked","38","bad"),new PanelMetric("Disabled","12",null));
            case "portal-launch" -> List.of(new PanelMetric("Launches","5,421",null),new PanelMetric("Success","5,310","ok"),new PanelMetric("Failure","111","bad"));
            case "partner-identity" -> List.of(new PanelMetric("Calls","4,287",null),new PanelMetric("Success","4,201","ok"),new PanelMetric("Failure","86","bad"));
            case "transmit" -> List.of(new PanelMetric("Requests","3,250",null),new PanelMetric("Success","3,141","ok"),new PanelMetric("Failure","109","bad"));
            case "gemfire" -> List.of(new PanelMetric("Reads","18,420",null),new PanelMetric("Writes","5,311",null),new PanelMetric("Errors","24","bad"));
            default -> List.of(new PanelMetric("DB Success","9,441","ok"),new PanelMetric("DB Failure","34","bad"),new PanelMetric("Timeout","12","warn"));
        };
    }
    private List<SplunkEvent> demoEvents() {
        return List.of(
            new SplunkEvent("10:23:10 AM","ERROR","NullPointerException in UserService.getCustomerDetails","TRK-88901","2","REQ-12345","TRK-88901","bc-login-service",500,"NULL_POINTER_EXCEPTION"),
            new SplunkEvent("10:23:14 AM","ERROR","Account locked","TRK-88902","1","REQ-12346","TRK-88902","bc-login-service",423,"ACCOUNT_LOCKED"),
            new SplunkEvent("10:23:21 AM","ERROR","IDP authentication timeout","TRK-88903","2","REQ-12347","TRK-88903","idp-service",504,"IDP_TIMEOUT"),
            new SplunkEvent("10:23:29 AM","ERROR","Null profile returned","TRK-88904","2","REQ-12348","TRK-88904","bc-login-service",500,"NULL_POINTER_EXCEPTION"),
            new SplunkEvent("10:23:42 AM","INFO","Authentication completed","TRK-88907","0","REQ-12351","TRK-88907","bc-login-service",200,"SUCCESS")
        );
    }
    private String defaulted(String v,String f){return v==null||v.isBlank()?f:v;}
}
