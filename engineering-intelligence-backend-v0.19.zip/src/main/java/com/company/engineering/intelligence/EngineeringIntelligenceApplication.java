package com.company.engineering.intelligence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class EngineeringIntelligenceApplication {
    public static void main(String[] args) {
        SpringApplication.run(EngineeringIntelligenceApplication.class, args);
    }
}
