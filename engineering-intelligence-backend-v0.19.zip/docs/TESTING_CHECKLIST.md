# Testing Checklist

## Frontend

- [ ] `npm install`
- [ ] `npm run build`
- [ ] Demo mode starts without backend
- [ ] Live mode calls configured backend
- [ ] Every sidebar page renders
- [ ] Every visible action navigates/executes or is disabled
- [ ] Service selection is preserved across drill-down pages
- [ ] Existing Splunk Dashboard loads configuration-driven panels
- [ ] Panel Details and Failure Investigation work
- [ ] Request/Tracking ID carries into full investigation
- [ ] Code Analysis shows file tree, highlighted issue, evidence and recent changes
- [ ] Error/loading/empty states are visible

## Backend

- [ ] Application starts with demo mode enabled
- [ ] `/actuator/health` is healthy
- [ ] `/api/v1/status` works
- [ ] investigation endpoints return stable JSON
- [ ] configured dashboard endpoints return panel definitions/results
- [ ] `code?service=...` returns service-scoped analysis
- [ ] connector timeouts/errors are normalized
- [ ] secrets are not returned in APIs/logs
- [ ] production DB diagnostic operations are read-only
