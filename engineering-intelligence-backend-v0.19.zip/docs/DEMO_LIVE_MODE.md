# Demo and Live Mode

## Frontend

Local demo:

```env
VITE_DEMO_MODE=true
VITE_API_BASE_URL=http://localhost:8080
```

Live backend:

```env
VITE_DEMO_MODE=false
VITE_API_BASE_URL=https://engineering-intelligence-api.apps.company.com
```

`src/config/demo.ts` is the single source for the frontend demo switch.

## Backend

```bash
EIPA_DEMO_ENABLED=true
```

Set to false when real connectors are configured.

## Rule

Demo mode must exercise the same UI routes and component hierarchy as live mode. Do not create demo-only navigation that disappears in production.
