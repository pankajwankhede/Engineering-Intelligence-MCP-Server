# Connector Guidelines

## Architecture

Keep connector access behind the Spring Boot backend. React never calls Splunk, New Relic, PCF, Bitbucket, Oracle or SQL Server directly.

## Splunk

Prefer controlled query references and bounded time windows. Support either MCP or REST behind the connector abstraction.

## New Relic

Normalize APM applications, transactions, errors and dependencies into EIPA models. Keep external account/entity identifiers server-side.

## PCF / Tanzu

Expose apps, instances, events, deployments and safe environment metadata. Never return secrets from environment variables.

## Bitbucket/source control

Use read-only repository/file/commit APIs for investigation. Any future write action (PR/comment/revert) must require explicit authorization and audit logging.

## Oracle / SQL Server / JDBC

Production diagnostics should be read-only. Allow-listed queries, execution plans and metadata are preferred. Reject DDL/DML by default in diagnostic mode.

## LLM Gateway

The LLM interprets natural language and synthesizes evidence; it must not be the source of truth for metrics. Connector evidence remains authoritative. Record model name, prompt template version and correlation/tracking ID for auditability.
