# Development Guidelines

## Frontend

- One major screen/sub-screen per page component under `src/pages`.
- Keep API calls in `src/api`, not directly inside presentation components.
- Keep demo data in `src/demo`.
- Shared selection/investigation state must be propagated consistently.
- Reuse `Card`, `Metric`, `Table`, `Action`, `StatusPill` before creating duplicates.
- Buttons must have a real action or be disabled.
- Keep the dark theme tokens in `styles.css`; do not add random page-specific light backgrounds.
- Prefer normalized backend models over connector-specific response shapes.

## Backend

- Controllers are thin.
- Connector logic belongs in services/adapters.
- Configuration is bound through typed properties.
- Never expose raw secrets/config values.
- Keep integration models stable even if Splunk/New Relic/PCF APIs change.
- Add service-aware methods for multi-service investigations.
- Use read-only policies for database/source investigation by default.

## Adding a new page

1. Add the page type in `navigation.ts`.
2. Create a page component in `src/pages`.
3. Add navigation entry/sub-navigation where appropriate.
4. Add API function in `platformApi.ts`.
5. Add normalized TypeScript type.
6. Add matching backend model/service/controller endpoint.
7. Add demo data with the same contract.
8. Wire all drill-down actions.
9. Add/update documentation and tests.
