# PCF / Tanzu Deployment

## Frontend

Build with the live backend route:

```bash
VITE_DEMO_MODE=false VITE_API_BASE_URL=https://engineering-intelligence-api.apps.company.com npm run build
```

Because Vite variables are compiled into the bundle, set them at build time unless you add a runtime config endpoint/file.

## Backend

Representative environment variables:

```bash
EIPA_DEMO_ENABLED=false
EIPA_SPLUNK_ENABLED=true
EIPA_SPLUNK_BASE_URL=...
EIPA_SPLUNK_TOKEN=...
EIPA_NEW_RELIC_ENABLED=true
EIPA_NEW_RELIC_BASE_URL=...
EIPA_NEW_RELIC_TOKEN=...
EIPA_PCF_ENABLED=true
EIPA_PCF_BASE_URL=...
EIPA_PCF_TOKEN=...
EIPA_BITBUCKET_ENABLED=true
EIPA_BITBUCKET_BASE_URL=...
EIPA_BITBUCKET_TOKEN=...
EIPA_LLM_ENABLED=true
EIPA_LLM_BASE_URL=...
EIPA_LLM_MODEL=...
```

Use platform secret management/Vault instead of committing these values.

## CORS

Set the backend allowed frontend origins explicitly for production. Avoid wildcard credentialed CORS.
