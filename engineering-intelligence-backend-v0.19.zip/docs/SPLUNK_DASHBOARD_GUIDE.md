# Splunk Dashboard Guide

## Purpose

Engineering Intelligence supports both the organization's existing Splunk operational dashboard model and a separate AI-assisted investigation view.

## Configured dashboard model

Dashboard definitions live under:

```yaml
eipa:
  monitoring:
    dashboards:
      sso-idp-login:
        title: "Sample SSO IDP Login Monitoring"
        panels:
          - id: authentication-service-calls
            title: "Authentication Service Calls"
            query-ref: authentication-service-calls-demo
            visualization: table
```

The UI must not hardcode these configured panel names. It loads the dashboard definition from the backend.

## Query references

Each `query-ref` maps to an SPL definition under `eipa.splunk.queries`. The backend owns parameter substitution, authorization and Splunk execution.

Do not send unrestricted SPL from the browser to Splunk.

## Supported visualizations

The frontend contract supports:

- `table`
- `single-value`
- `line`
- `bar`
- `pie`
- `status`

## Recommended request flow

`React → Spring Boot → MonitoringDashboardService → Splunk connector/MCP → Splunk`

For failures:

`Panel → View Details → Failure list → Request/Tracking ID → Full Investigation`

## Panel configuration rules

- IDs are stable machine identifiers.
- Titles are user-facing and can change.
- `query-ref` points to a controlled backend query definition.
- Service/environment/time-range values are parameters, not string-concatenated browser SPL.
- Production queries must be bounded by time and result limits.
