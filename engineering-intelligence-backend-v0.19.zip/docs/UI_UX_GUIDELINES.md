# UI / UX Guidelines

## Baseline

Use the v0.17 dark Engineering Intelligence design consistently. The top-level dashboard follows the selected Image 1 layout. Code Analysis intentionally uses the richer Image 2-style layout.

## Information hierarchy

1. **Investigation Overview** answers: what is broken, which service is root cause, how many customers/services are affected, and confidence.
2. **Service Flow** shows the multi-service impact map and allows service-specific drill-down.
3. **Observability** provides Splunk, New Relic, JVM and PCF evidence.
4. **Analysis** provides code, database, changes, blast radius and RCA.
5. **Platform** contains reports, integrations and settings.

## Global context

Every technical page must preserve:

- `investigationId`
- selected `service`
- `environment`
- `timeRange`
- `requestId` / `trackingId` when available
- selected instance/transaction/query/commit when drilling down

The global service selector may show `All Services` for aggregate views. Detail pages must show a concrete service.

## Multiple services

Use role/status consistently:

- `ROOT_CAUSE` — red
- `IMPACTED` — orange
- `AT_RISK` — amber/yellow
- `HEALTHY` — green

Clicking a service in Service Flow or Service Impact Overview must open `ServiceDetailPage`, then allow drill-down to Splunk/New Relic/JVM/PCF/Code/Database for that service.

## Existing Splunk vs AI Splunk

Keep two separate pages under Splunk:

1. **Existing Splunk Dashboard** — panels configured by backend `application.yml` and `query-ref`.
2. **Investigation Splunk Analysis** — Engineering Intelligence error correlation and investigation workflow.

Do not merge these into one giant page.

## Code Analysis

Code Analysis must include:

- service, repository, branch and file context
- file explorer
- selected source file
- highlighted issue line
- issue severity/category/confidence
- related evidence from Splunk/New Relic/recent changes
- recent commits
- real internal actions to file details, recent changes, Splunk correlation and RCA

## Non-technical readability

The landing page should use business language. Avoid making exception names the primary headline when a plain-language explanation is possible. Technical details remain one click away.

## Empty/loading/error states

Every data page must implement visible loading, empty and error states. Never leave a blank panel that looks broken.
