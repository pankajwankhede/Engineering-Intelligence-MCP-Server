# Engineering Intelligence v0.17 Documentation

This folder is the implementation guide for the v0.17 UI/backend baseline.

## Documents

- `UI_UX_GUIDELINES.md` — final dark-theme layout, page hierarchy, drill-down behavior and business/technical presentation rules.
- `ROUTING_AND_ACTIONS.md` — required behavior for every button/link; no production dummy actions.
- `SPLUNK_DASHBOARD_GUIDE.md` — existing configured Splunk panels + separate AI investigation analysis.
- `BACKEND_API_GUIDE.md` — REST contract and service/investigation context rules.
- `DEMO_LIVE_MODE.md` — how to switch demo data off and call the deployed backend.
- `CONNECTOR_GUIDELINES.md` — Splunk, New Relic, PCF/Tanzu, Bitbucket, Oracle, SQL Server and LLM/MCP integration rules.
- `SECURITY_AND_PRODUCTION_GUARDRAILS.md` — secrets, read-only diagnostics, PII/logging and timeout rules.
- `DEVELOPMENT_GUIDELINES.md` — frontend/backend coding conventions and extension checklist.
- `PCF_DEPLOYMENT.md` — deployment/configuration examples.
- `TESTING_CHECKLIST.md` — minimum validation before merging/deploying.

## Final visual baseline

`ui-reference-v0.17.png` is the selected overall dark UI baseline. The Code Analysis area uses the richer file-explorer/source/evidence layout from the alternate mockup while the rest follows the selected Image 1 structure.
