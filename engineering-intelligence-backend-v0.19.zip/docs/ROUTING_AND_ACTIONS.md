# Routing and Action Guidelines

## No dummy links

A clickable element in production must do one of the following:

1. navigate to a real internal drill-down page,
2. open a supported external system deep link,
3. execute a real backend action,
4. or be visibly disabled with an explanation.

Do not render clickable buttons that do nothing.

## Demo mode

In demo mode, the same navigation must work using demo data. Demo mode changes the data source, not the route behavior.

## Core drill-downs

- Existing Splunk panel `View Details` → Splunk Panel Detail
- Existing Splunk panel `Investigate Failures` → Splunk Failure Investigation
- Failed row `Investigate` → Splunk Investigation Analysis with request/tracking context
- Service `View Service Details` → Service Detail
- New Relic `View Transactions` → Transactions
- New Relic `View Errors` → Error Groups
- JVM `View Full JVM Metrics` → Memory/GC
- JVM `View Threads` → Threads
- PCF `View Instance Details` → Instances / Instance Detail
- PCF `View Events` → Events & Deployments
- Code `View File Details` → Code File Detail
- Code `View Recent Changes` → Recent Changes
- Database `View Query Details` → Query Detail
- Database `View Execution Plan` → in-page plan or dedicated plan view
- Recommendation `View RCA Summary` → RCA Summary

## Context preservation

When navigating, never discard the current investigation/service/request context. The current implementation stores context centrally in `AppSelection`; a future React Router migration should move it to route/search params plus state.
