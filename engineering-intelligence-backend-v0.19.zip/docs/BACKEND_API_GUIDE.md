# Backend API Guide

Base path: `/api/v1`

## Platform

- `GET /status`
- `GET /integrations`
- `POST /ai/interpret`

## Investigation

- `POST /investigations`
- `GET /investigations/{id}`
- `GET /investigations/{id}/services`
- `GET /investigations/{id}/monitoring`
- `GET /investigations/{id}/runtime`
- `GET /investigations/{id}/splunk`
- `GET /investigations/{id}/new-relic`
- `GET /investigations/{id}/jvm`
- `GET /investigations/{id}/pcf`
- `GET /investigations/{id}/database`
- `GET /investigations/{id}/code?service=bc-login-service`

## Configured Splunk dashboards

- `GET /monitoring/dashboards`
- `GET /monitoring/dashboards/{dashboardId}`
- `GET /monitoring/dashboards/{dashboardId}/panels/{panelId}?service=...&timeRange=...`
- `GET /monitoring/dashboards/{dashboardId}/panels/{panelId}/failures?service=...&timeRange=...`

## Contract rules

- UI receives normalized data; it does not know connector credentials.
- Connector-specific responses must be translated to stable EIPA models.
- All service-specific endpoints should accept a service context when a single investigation spans multiple services.
- API errors should return a stable error code, message, tracking ID and optional field details.
- Add pagination before returning large event/result sets in production.


## v0.19 manual dashboard load
`GET /api/v1/monitoring/dashboards` returns all configured dashboards.

Panel calls accept `service`, `environment`, and `timeRange` and should be invoked only after the UI user clicks **Load Dashboard**. `service=ALL` is translated to `*` for SPL token replacement.
