# Security and Production Guardrails

- Store tokens/passwords in Vault or platform secrets; never commit them to `application.yml`.
- Frontend environment variables are public at build time; never place secrets in `VITE_*` variables.
- Redact credentials, access tokens, cookies, authorization headers and sensitive customer data from logs and LLM prompts.
- Database investigation is read-only by default.
- Apply timeouts, result limits and circuit breakers to every external connector.
- Validate service/dashboard/panel/query IDs against configuration; do not allow arbitrary connector commands from browser input.
- Propagate `trackingId`, `requestId` and `investigationId` through backend logs.
- Add RBAC for production diagnostic views and audit access to source code/database details.
- Use TLS for all external integrations.
- Treat AI recommendations as advisory; destructive remediation actions require explicit human approval.
