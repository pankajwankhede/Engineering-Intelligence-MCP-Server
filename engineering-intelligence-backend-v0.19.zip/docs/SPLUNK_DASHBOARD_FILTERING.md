# Splunk Dashboard Selection and Manual Loading

## Behavior
- Dashboard, Service, Environment and Time Range are draft selections.
- Changing any dropdown does **not** call the backend.
- `Load Dashboard` commits all four values and then loads the selected dashboard definition and panel results.
- The global header also uses `Apply Filters`; global service/environment/time changes are not applied until this button is clicked.

## APIs
1. `GET /api/v1/monitoring/dashboards` lists dashboards configured under `eipa.monitoring.dashboards`.
2. `GET /api/v1/monitoring/dashboards/{dashboardId}` returns the chosen dashboard definition.
3. Each panel is loaded only after the user clicks Load Dashboard:
   `GET /api/v1/monitoring/dashboards/{dashboardId}/panels/{panelId}?service=ALL&environment=QA&timeRange=Last%2015%20Minutes`

## Rule
Do not add effects that depend directly on draft dropdown state. Backend/MCP/Splunk calls must be triggered by an explicit Apply/Load/Search action.
