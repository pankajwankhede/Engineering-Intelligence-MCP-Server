# Engineering Intelligence Frontend v0.13.0

React + Vite + TypeScript frontend with a dark Engineering Intelligence UI and a single demo/live switch.

## Demo mode (no backend required)

Copy `.env.example` to `.env.local` and keep:

```properties
VITE_DEMO_MODE=true
VITE_API_BASE_URL=
```

Then:

```bash
npm install
npm run dev
```

## Live backend mode

Once the Spring Boot backend is deployed, change only the environment configuration:

```properties
VITE_DEMO_MODE=false
VITE_API_BASE_URL=https://YOUR-BACKEND-ROUTE
```

All pages use the same API layer. React components do not need changes.

## Included pages

- Start Investigation with natural-language input
- Investigation Overview
- Logs & Trace
- Code Analysis
- Service Flow
- API & Consumers
- Database Analysis (Oracle/SQL Server ready)
- PCF / Runtime
- New Relic / Monitoring
- Evidence Timeline
- Recommendations
- Integrations

The header clearly shows `DEMO MODE` or `LIVE BACKEND` so demo data cannot be mistaken for production data.
