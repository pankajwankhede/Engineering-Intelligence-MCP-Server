import { apiClient } from './apiClient'
import { DEMO_CONFIG } from '../config/demo'
import { demoDatabase, demoIntegrations, demoInvestigation, demoMonitoring, demoRuntime, demoStatus } from '../demo/data'
import type { DatabaseAnalysis, IntegrationItem, InvestigationRequest, InvestigationResult, MonitoringAnalysis, PlatformStatus, RuntimeAnalysis } from '../types'

const wait = () => new Promise(resolve => setTimeout(resolve, DEMO_CONFIG.delayMs))

async function demo<T>(value: T): Promise<T> { await wait(); return structuredClone(value) }

export async function getPlatformStatus(): Promise<PlatformStatus> {
  if (DEMO_CONFIG.enabled) return demo(demoStatus)
  return (await apiClient.get<PlatformStatus>('/api/v1/status')).data
}

export async function startInvestigation(request: InvestigationRequest): Promise<InvestigationResult> {
  if (DEMO_CONFIG.enabled) {
    const result = await demo(demoInvestigation)
    const serviceMatch = request.query.match(/(?:in|service)\s+([a-zA-Z0-9_-]+-service|[a-zA-Z0-9_-]+)/i)
    if (serviceMatch?.[1]) result.understanding.service = serviceMatch[1]
    result.understanding.environment = request.environment
    result.understanding.timeRange = request.timeRange
    return result
  }
  return (await apiClient.post<InvestigationResult>('/api/v1/investigations', request)).data
}

export async function getDatabaseAnalysis(id: string): Promise<DatabaseAnalysis> {
  if (DEMO_CONFIG.enabled) return demo(demoDatabase)
  return (await apiClient.get<DatabaseAnalysis>(`/api/v1/investigations/${id}/database`)).data
}

export async function getMonitoringAnalysis(id: string): Promise<MonitoringAnalysis> {
  if (DEMO_CONFIG.enabled) return demo(demoMonitoring)
  return (await apiClient.get<MonitoringAnalysis>(`/api/v1/investigations/${id}/monitoring`)).data
}

export async function getRuntimeAnalysis(id: string): Promise<RuntimeAnalysis> {
  if (DEMO_CONFIG.enabled) return demo(demoRuntime)
  return (await apiClient.get<RuntimeAnalysis>(`/api/v1/investigations/${id}/runtime`)).data
}

export async function getIntegrations(): Promise<IntegrationItem[]> {
  if (DEMO_CONFIG.enabled) return demo(demoIntegrations)
  return (await apiClient.get<IntegrationItem[]>('/api/v1/integrations')).data
}
