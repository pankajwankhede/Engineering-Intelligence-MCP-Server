import axios from 'axios'
import { DEMO_CONFIG } from '../config/demo'

export const apiClient = axios.create({
  baseURL: DEMO_CONFIG.backendBaseUrl || undefined,
  timeout: 30_000,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: false,
})

apiClient.interceptors.response.use(
  response => response,
  error => {
    const message = error?.response?.data?.message || error?.message || 'Backend request failed'
    return Promise.reject(new Error(message))
  },
)
