import type { DatabaseAnalysis, IntegrationItem, InvestigationResult, MonitoringAnalysis, PlatformStatus, RuntimeAnalysis } from '../types'

export const demoStatus: PlatformStatus = {
  backend: 'HEALTHY', mode: 'DEMO', splunk: 'DEMO', bitbucket: 'DEMO', newRelic: 'DEMO', pcf: 'DEMO', oracle: 'DEMO', sqlServer: 'DEMO', llmGateway: 'DEMO',
}

export const demoInvestigation: InvestigationResult = {
  investigationId: 'INV-2026-08-17-0017',
  status: 'COMPLETED',
  understanding: {
    intent: 'Investigate Exception',
    service: 'bc-login-service',
    exception: 'NullPointerException',
    environment: 'PRODUCTION',
    timeRange: 'Last 2 Hours',
    confidence: 96,
  },
  rootCause: {
    title: 'NullPointerException in UserService',
    description: 'customer.getProfile() can return null before getAddress() is called. The error correlates with the latest login transaction failures.',
    confidence: 94,
    file: 'src/main/java/com/company/login/service/UserService.java',
    line: 187,
  },
  impact: { services: 3, failedRequestPercent: 25.4, usersImpacted: 12800 },
  evidence: [
    { source: 'Splunk', summary: '45 matching NullPointerException events in the selected window', status: 'MATCH' },
    { source: 'New Relic', summary: 'Error rate increased to 25.4%; p95 latency reached 840 ms', status: 'MATCH' },
    { source: 'PCF / Tanzu', summary: '1 instance restart detected after the first error', status: 'MATCH' },
    { source: 'Bitbucket', summary: 'Relevant null-handling code found at UserService.java:187', status: 'MATCH' },
    { source: 'Oracle', summary: 'CUSTOMER_PROFILE reads show missing profile rows for affected users', status: 'MATCH' },
  ],
}

export const demoDatabase: DatabaseAnalysis = {
  type: 'ORACLE', database: 'ORCL', schema: 'BCLOGIN', connectionRef: 'logical-prod-readonly', persistenceTechnology: 'SPRING DATA JPA',
  active: 18, idle: 12, waiting: 20, maxConnections: 50,
  longRunningQueries: [
    { sqlId: 'a1b2c3d4', duration: '00:12:45', status: 'RUNNING' },
    { sqlId: 'd4e5f6a7', duration: '00:08:31', status: 'RUNNING' },
    { sqlId: 'f7e6d5c4', duration: '00:06:02', status: 'RUNNING' },
  ],
  blockingSessions: [
    { sid: '12345', blocked: 15, duration: '00:05:12' },
    { sid: '23456', blocked: 8, duration: '00:03:47' },
  ],
  recommendations: ['Consider adding an index on BC_USER.LOGIN_ID.', 'Review long running query a1b2c3d4.', 'Connection pool utilization is within configured capacity.'],
}

export const demoMonitoring: MonitoringAnalysis = {
  requestRate: 256, errorRate: 25.4, failedRequests: 1245, p95LatencyMs: 840,
  throughputTrend: [510, 488, 470, 430, 390, 360, 300, 256],
  errorTrend: [10, 15, 18, 28, 55, 105, 180, 256],
}

export const demoRuntime: RuntimeAnalysis = {
  platform: 'PCF / Tanzu', org: 'engineering', space: 'production', app: 'bc-login-service',
  instances: 4, healthyInstances: 3, memoryMb: 1024, restartsLastHour: 1,
  recentEvents: ['10:19:45 Deployment completed', '10:20:10 All 4 instances healthy', '10:23:28 Health check latency increased', '10:24:08 Instance 2 restarted'],
}

export const demoIntegrations: IntegrationItem[] = [
  { key: 'splunk', name: 'Splunk', category: 'Observability', status: 'DEMO', details: 'Logs, traces and errors' },
  { key: 'newrelic', name: 'New Relic', category: 'Observability', status: 'DEMO', details: 'APM metrics and transactions' },
  { key: 'pcf', name: 'PCF / Tanzu', category: 'Runtime', status: 'DEMO', details: 'Apps, instances, events and deployments' },
  { key: 'bitbucket', name: 'Bitbucket', category: 'Source Control', status: 'DEMO', details: 'Code, commits and pull requests' },
  { key: 'oracle', name: 'Oracle MCP', category: 'Database', status: 'DEMO', details: 'Read-only diagnostic queries' },
  { key: 'sqlserver', name: 'SQL Server MCP', category: 'Database', status: 'DEMO', details: 'Read-only diagnostic queries' },
  { key: 'jdbc', name: 'JDBC / ORM Analyzer', category: 'Database', status: 'DEMO', details: 'JDBC queries and ORM metadata' },
  { key: 'llm', name: 'LLM Gateway', category: 'AI', status: 'DEMO', details: 'Natural language intent + evidence synthesis' },
]
