import { useEffect, useMemo, useState } from 'react'
import { Activity, AlertTriangle, Bot, Boxes, Code2, Database, FileText, Gauge, GitBranch, Network, Play, Search, ServerCog, Settings, Sparkles, Waypoints } from 'lucide-react'
import { DEMO_CONFIG } from './config/demo'
import { getDatabaseAnalysis, getIntegrations, getMonitoringAnalysis, getPlatformStatus, getRuntimeAnalysis, startInvestigation } from './api/platformApi'
import type { DatabaseAnalysis, IntegrationItem, InvestigationResult, MonitoringAnalysis, PlatformStatus, RuntimeAnalysis } from './types'

type Page = 'start' | 'overview' | 'logs' | 'code' | 'flow' | 'api' | 'database' | 'monitoring' | 'runtime' | 'timeline' | 'recommendations' | 'integrations'

const nav: Array<{page: Page; label: string; icon: any; isNew?: boolean}> = [
  { page: 'overview', label: 'Investigation Overview', icon: Gauge },
  { page: 'start', label: 'Start Investigation', icon: Search },
  { page: 'flow', label: 'Service Flow', icon: Waypoints },
  { page: 'logs', label: 'Logs & Trace', icon: FileText },
  { page: 'code', label: 'Code Analysis', icon: Code2 },
  { page: 'api', label: 'API & Consumers', icon: Network },
  { page: 'database', label: 'Database Analysis', icon: Database, isNew: true },
  { page: 'runtime', label: 'PCF / Runtime', icon: ServerCog, isNew: true },
  { page: 'monitoring', label: 'New Relic / Monitoring', icon: Activity, isNew: true },
  { page: 'timeline', label: 'Evidence Timeline', icon: GitBranch },
  { page: 'recommendations', label: 'Recommendations', icon: Sparkles },
  { page: 'integrations', label: 'Integrations', icon: Boxes, isNew: true },
]

const emptyStatus: PlatformStatus = {backend:'HEALTHY',mode:DEMO_CONFIG.enabled?'DEMO':'LIVE',splunk:'DISABLED',bitbucket:'DISABLED',newRelic:'DISABLED',pcf:'DISABLED',oracle:'DISABLED',sqlServer:'DISABLED',llmGateway:'DISABLED'}

export default function App() {
  const [page, setPage] = useState<Page>('start')
  const [query, setQuery] = useState('Find NullPointerException in bc-login-service')
  const [environment, setEnvironment] = useState('PRODUCTION')
  const [timeRange, setTimeRange] = useState('Last 2 Hours')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [status, setStatus] = useState<PlatformStatus>(emptyStatus)
  const [investigation, setInvestigation] = useState<InvestigationResult | null>(null)
  const [database, setDatabase] = useState<DatabaseAnalysis | null>(null)
  const [monitoring, setMonitoring] = useState<MonitoringAnalysis | null>(null)
  const [runtime, setRuntime] = useState<RuntimeAnalysis | null>(null)
  const [integrations, setIntegrations] = useState<IntegrationItem[]>([])

  useEffect(() => { getPlatformStatus().then(setStatus).catch(() => setStatus({...emptyStatus, backend:'DEGRADED'})) }, [])

  async function runInvestigation() {
    setLoading(true); setError('')
    try {
      const inv = await startInvestigation({query, environment, timeRange})
      setInvestigation(inv)
      const [db, mon, run, ints] = await Promise.all([
        getDatabaseAnalysis(inv.investigationId), getMonitoringAnalysis(inv.investigationId), getRuntimeAnalysis(inv.investigationId), getIntegrations(),
      ])
      setDatabase(db); setMonitoring(mon); setRuntime(run); setIntegrations(ints); setPage('overview')
    } catch (e) { setError(e instanceof Error ? e.message : 'Investigation failed') }
    finally { setLoading(false) }
  }

  async function ensureIntegrations() { if (!integrations.length) setIntegrations(await getIntegrations()) }
  useEffect(() => { if (page === 'integrations') ensureIntegrations().catch(()=>{}) }, [page])

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">EI</div><div><strong>Engineering Intelligence</strong><span>Monitoring + Investigation</span></div></div>
      <div className="side-section">INVESTIGATION</div>
      <nav>{nav.map(item => { const Icon=item.icon; return <button key={item.page} className={page===item.page?'nav-item active':'nav-item'} onClick={()=>setPage(item.page)}><Icon size={17}/><span>{item.label}</span>{item.isNew&&<em>NEW</em>}</button>})}</nav>
      <div className="sidebar-bottom"><Settings size={16}/> Settings<div className="version">EIPA v0.13.0</div></div>
    </aside>

    <main>
      <header className="topbar">
        <div className="top-title"><strong>{pageTitle(page)}</strong><span>{investigation ? investigation.investigationId : 'Ready for investigation'}</span></div>
        <div className="statuses">
          <Status label="Backend" value={status.backend}/><Status label="Splunk" value={status.splunk}/><Status label="New Relic" value={status.newRelic}/><Status label="PCF" value={status.pcf}/>
          <span className={DEMO_CONFIG.enabled?'mode demo':'mode live'}>{DEMO_CONFIG.enabled?'DEMO MODE':'LIVE BACKEND'}</span>
        </div>
      </header>

      <section className="content">
        {error && <div className="error-banner"><AlertTriangle size={18}/>{error}</div>}
        {page === 'start' && <StartPage query={query} setQuery={setQuery} environment={environment} setEnvironment={setEnvironment} timeRange={timeRange} setTimeRange={setTimeRange} loading={loading} run={runInvestigation}/>} 
        {page === 'overview' && <Overview investigation={investigation} monitoring={monitoring} runtime={runtime}/>} 
        {page === 'database' && <DatabasePage data={database}/>} 
        {page === 'monitoring' && <MonitoringPage data={monitoring}/>} 
        {page === 'runtime' && <RuntimePage data={runtime}/>} 
        {page === 'integrations' && <IntegrationsPage data={integrations}/>} 
        {['logs','code','flow','api','timeline','recommendations'].includes(page) && <GenericPage page={page} investigation={investigation}/>} 
      </section>
    </main>
  </div>
}

function pageTitle(page: Page){return ({start:'Start Investigation',overview:'Investigation Overview',logs:'Logs & Trace',code:'Code Analysis',flow:'Service Flow',api:'API & Consumers',database:'Database Analysis',monitoring:'New Relic / Monitoring',runtime:'PCF / Runtime',timeline:'Evidence Timeline',recommendations:'Recommendations',integrations:'Integrations'})[page]}

function Status({label,value}:{label:string,value:string}){return <div className="status"><i className={value==='ERROR'||value==='DEGRADED'?'bad':''}/><span>{label}</span><b>{value}</b></div>}

function StartPage(p:any){return <div className="page start-page">
  <div className="hero"><div className="hero-icon"><Bot size={28}/></div><div><h1>Start a New Investigation</h1><p>Ask in natural language. The LLM Gateway interprets the request and the backend coordinates MCP, APM, runtime, code and database evidence.</p></div></div>
  <div className="ask-card"><label>Ask Engineering Intelligence</label><div className="ask-row"><input value={p.query} onChange={(e:any)=>p.setQuery(e.target.value)} placeholder="e.g. Find NullPointerException in bc-login-service"/><button onClick={p.run} disabled={p.loading||!p.query.trim()}><Play size={17}/>{p.loading?'Investigating...':'Start Investigation'}</button></div>
  <div className="filters"><label>Environment<select value={p.environment} onChange={(e:any)=>p.setEnvironment(e.target.value)}><option>PRODUCTION</option><option>QA</option><option>DEV</option></select></label><label>Time Range<select value={p.timeRange} onChange={(e:any)=>p.setTimeRange(e.target.value)}><option>Last 15 Minutes</option><option>Last 2 Hours</option><option>Last 24 Hours</option></select></label></div>
  <div className="examples"><span>Examples</span><button onClick={()=>p.setQuery('Why is bc-login-service failing?')}>Why is bc-login failing?</button><button onClick={()=>p.setQuery('Find NullPointerException in bc-login-service')}>Find NullPointerException</button><button onClick={()=>p.setQuery('Why did login failures increase?')}>Why did login failures increase?</button></div></div>
  <div className="info-grid"><Info title="Natural Language" text="LLM Gateway converts the request into a structured investigation plan."/><Info title="MCP + Direct Connectors" text="Splunk, Bitbucket, New Relic, PCF, Oracle and SQL Server evidence can be queried."/><Info title="Safe Database Access" text="Use read-only MCP/JDBC service accounts and approved diagnostic query templates."/></div>
</div>}

function Overview({investigation,monitoring,runtime}:{investigation:InvestigationResult|null,monitoring:MonitoringAnalysis|null,runtime:RuntimeAnalysis|null}){
 if(!investigation)return <Empty/>
 return <div className="page"><div className="summary-strip"><Metric label="Root Cause Confidence" value={`${investigation.rootCause.confidence}%`}/><Metric label="Impacted Services" value={String(investigation.impact.services)}/><Metric label="Failed Requests" value={`${investigation.impact.failedRequestPercent}%`}/><Metric label="PCF Health" value={runtime?`${runtime.healthyInstances}/${runtime.instances}`:'—'}/></div>
 <div className="grid2"><Card title="AI Understanding"><dl><dt>Intent</dt><dd>{investigation.understanding.intent}</dd><dt>Service</dt><dd>{investigation.understanding.service}</dd><dt>Exception</dt><dd>{investigation.understanding.exception||'—'}</dd><dt>Environment</dt><dd>{investigation.understanding.environment}</dd><dt>Confidence</dt><dd>{investigation.understanding.confidence}%</dd></dl></Card>
 <Card title="Root Cause Candidate"><div className="root-cause"><AlertTriangle size={24}/><h2>{investigation.rootCause.title}</h2><p>{investigation.rootCause.description}</p>{investigation.rootCause.file&&<code>{investigation.rootCause.file}:{investigation.rootCause.line}</code>}</div></Card></div>
 <div className="grid2"><Card title="Evidence Sources"><div className="evidence-list">{investigation.evidence.map(e=><div key={e.source}><span>{e.source}</span><p>{e.summary}</p><b>{e.status}</b></div>)}</div></Card><Card title="Live Signals"><div className="signals"><Metric label="Request Rate" value={monitoring?`${monitoring.requestRate}/s`:'—'}/><Metric label="Error Rate" value={monitoring?`${monitoring.errorRate}%`:'—'}/><Metric label="p95 Latency" value={monitoring?`${monitoring.p95LatencyMs} ms`:'—'}/><Metric label="Users Impacted" value={investigation.impact.usersImpacted.toLocaleString()}/></div></Card></div></div>
}

function DatabasePage({data}:{data:DatabaseAnalysis|null}){if(!data)return <Empty/>;return <div className="page"><div className="summary-strip"><Metric label="Database" value={`${data.type} / ${data.schema}`}/><Metric label="Active" value={String(data.active)}/><Metric label="Waiting" value={String(data.waiting)}/><Metric label="Max Connections" value={String(data.maxConnections)}/></div><div className="grid2"><Card title="Database Context"><dl><dt>Database</dt><dd>{data.database}</dd><dt>Schema</dt><dd>{data.schema}</dd><dt>Connection Ref</dt><dd>{data.connectionRef}</dd><dt>Persistence</dt><dd>{data.persistenceTechnology}</dd></dl></Card><Card title="Long Running Queries"><Table headers={['SQL ID','Duration','Status']} rows={data.longRunningQueries.map(x=>[x.sqlId,x.duration,x.status])}/></Card></div><div className="grid2"><Card title="Blocking Sessions"><Table headers={['Blocking SID','Blocked SIDs','Duration']} rows={data.blockingSessions.map(x=>[x.sid,String(x.blocked),x.duration])}/></Card><Card title="Database Recommendations"><ul className="recommendations">{data.recommendations.map(x=><li key={x}>{x}</li>)}</ul></Card></div></div>}

function MonitoringPage({data}:{data:MonitoringAnalysis|null}){if(!data)return <Empty/>;return <div className="page"><div className="summary-strip"><Metric label="Request Rate" value={`${data.requestRate}/s`}/><Metric label="Error Rate" value={`${data.errorRate}%`}/><Metric label="Failed Requests" value={data.failedRequests.toLocaleString()}/><Metric label="p95 Latency" value={`${data.p95LatencyMs} ms`}/></div><div className="grid2"><Card title="Application Traffic"><Bars values={data.throughputTrend}/></Card><Card title="Error Trend"><Bars values={data.errorTrend}/></Card></div></div>}

function RuntimePage({data}:{data:RuntimeAnalysis|null}){if(!data)return <Empty/>;return <div className="page"><div className="summary-strip"><Metric label="Platform" value={data.platform}/><Metric label="App" value={data.app}/><Metric label="Healthy Instances" value={`${data.healthyInstances}/${data.instances}`}/><Metric label="Restarts (1h)" value={String(data.restartsLastHour)}/></div><div className="grid2"><Card title="Runtime Context"><dl><dt>Org</dt><dd>{data.org}</dd><dt>Space</dt><dd>{data.space}</dd><dt>Memory</dt><dd>{data.memoryMb} MB / instance</dd></dl></Card><Card title="Recent PCF Events"><ul className="timeline-list">{data.recentEvents.map(x=><li key={x}>{x}</li>)}</ul></Card></div></div>}

function IntegrationsPage({data}:{data:IntegrationItem[]}){return <div className="page"><div className="integration-grid">{data.map(x=><Card key={x.key} title={x.name}><div className="integration"><span>{x.category}</span><b className={`pill ${x.status.toLowerCase()}`}>{x.status}</b><p>{x.details}</p></div></Card>)}</div></div>}

function GenericPage({page,investigation}:{page:Page,investigation:InvestigationResult|null}){if(!investigation)return <Empty/>;const content:any={logs:['45 ERROR events matched NullPointerException','Tracking ID correlation across bc-login-service and downstream services','Splunk query execution represented by backend connector'],code:['UserService.java:187 candidate null dereference','Repository analysis via Bitbucket MCP / REST connector','Recent change correlation can be attached to the same evidence model'],flow:['bc-web → bc-login-service → customer-profile-service','Downstream impact calculated from trace/log evidence','Database and runtime nodes participate in RCA correlation'],api:['3 downstream consumers impacted','Failed request percentage: 25.4%','Consumer mapping can come from service catalog + traces'],timeline:['10:23:10 First error detected','10:23:15 New Relic error rate increased','10:24:08 PCF instance restarted','10:24:15 Root cause candidate generated'],recommendations:['Add null guard before customer.getProfile().getAddress()','Add unit test for missing customer profile','Review data integrity for CUSTOMER_PROFILE','Monitor login error rate after fix']};return <div className="page"><Card title={pageTitle(page)}><ul className="generic-list">{content[page].map((x:string)=><li key={x}>{x}</li>)}</ul></Card></div>}

function Empty(){return <div className="empty"><Search size={30}/><h2>No investigation loaded</h2><p>Start an investigation first. In demo mode no backend is required.</p></div>}
function Card({title,children}:{title:string,children:any}){return <section className="card"><div className="card-title">{title}</div>{children}</section>}
function Metric({label,value}:{label:string,value:string}){return <div className="metric"><span>{label}</span><strong>{value}</strong></div>}
function Info({title,text}:{title:string,text:string}){return <div className="info"><strong>{title}</strong><p>{text}</p></div>}
function Table({headers,rows}:{headers:string[],rows:string[][]}){return <div className="table"><div className="tr head">{headers.map(h=><span key={h}>{h}</span>)}</div>{rows.map((r,i)=><div className="tr" key={i}>{r.map((c,j)=><span key={j}>{c}</span>)}</div>)}</div>}
function Bars({values}:{values:number[]}){const max=Math.max(...values);return <div className="bars">{values.map((v,i)=><div key={i} style={{height:`${Math.max(8,(v/max)*100)}%`}}><span>{v}</span></div>)}</div>}
