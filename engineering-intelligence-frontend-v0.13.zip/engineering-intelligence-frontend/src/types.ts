export type ConnectorStatus = 'CONNECTED' | 'DEMO' | 'DISABLED' | 'ERROR'

export interface PlatformStatus {
  backend: 'HEALTHY' | 'DEGRADED'
  mode: 'DEMO' | 'LIVE'
  splunk: ConnectorStatus
  bitbucket: ConnectorStatus
  newRelic: ConnectorStatus
  pcf: ConnectorStatus
  oracle: ConnectorStatus
  sqlServer: ConnectorStatus
  llmGateway: ConnectorStatus
}

export interface InvestigationRequest {
  query: string
  environment: string
  timeRange: string
}

export interface InvestigationResult {
  investigationId: string
  status: string
  understanding: {
    intent: string
    service: string
    exception?: string
    environment: string
    timeRange: string
    confidence: number
  }
  rootCause: {
    title: string
    description: string
    confidence: number
    file?: string
    line?: number
  }
  impact: {
    services: number
    failedRequestPercent: number
    usersImpacted: number
  }
  evidence: Array<{ source: string; summary: string; status: string }>
}

export interface DatabaseAnalysis {
  type: string
  database: string
  schema: string
  connectionRef: string
  persistenceTechnology: string
  active: number
  idle: number
  waiting: number
  maxConnections: number
  longRunningQueries: Array<{ sqlId: string; duration: string; status: string }>
  blockingSessions: Array<{ sid: string; blocked: number; duration: string }>
  recommendations: string[]
}

export interface MonitoringAnalysis {
  requestRate: number
  errorRate: number
  failedRequests: number
  p95LatencyMs: number
  throughputTrend: number[]
  errorTrend: number[]
}

export interface RuntimeAnalysis {
  platform: string
  org: string
  space: string
  app: string
  instances: number
  healthyInstances: number
  memoryMb: number
  restartsLastHour: number
  recentEvents: string[]
}

export interface IntegrationItem {
  key: string
  name: string
  category: string
  status: ConnectorStatus
  endpoint?: string
  details?: string
}
