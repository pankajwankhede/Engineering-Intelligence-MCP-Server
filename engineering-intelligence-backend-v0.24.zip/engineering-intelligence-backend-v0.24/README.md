# Engineering Intelligence Backend v0.19

Spring Boot REST backend matching the v0.19 Image-2 frontend.

## Important configuration
- `eipa.monitoring.dashboards`: defines existing operational dashboard panels.
- each panel has `id`, `title`, `query-ref`, and `visualization`.
- `eipa.splunk.queries`: resolves each `query-ref` to SPL.
- frontend demo mode is separate: `VITE_DEMO_MODE`.
- backend demo/connector mode is controlled by `EIPA_DEMO_ENABLED` and connector flags.

## New monitoring APIs
- `GET /api/v1/monitoring/dashboards`
- `GET /api/v1/monitoring/dashboards/{dashboardId}`
- `GET /api/v1/monitoring/dashboards/{dashboardId}/panels/{panelId}`
- `GET /api/v1/monitoring/dashboards/{dashboardId}/panels/{panelId}/failures`
- `GET /api/v1/investigations/{id}/services`

The supplied implementation returns realistic demo results while preserving the configuration-driven dashboard contract. Replace the connector execution layer with your organization-specific Splunk/MCP, New Relic, PCF, Bitbucket and DB clients when `EIPA_DEMO_ENABLED=false`.

## v0.19 backend update

Code analysis now accepts `?service=...` so the code page can be scoped during multi-service investigations. See `docs/BACKEND_API_GUIDE.md`, `docs/SPLUNK_DASHBOARD_GUIDE.md` and `docs/CONNECTOR_GUIDELINES.md`.


## v0.20 filter execution fix

`Apply Filters` now forces a refresh on every click, even when the selected values are unchanged. In `VITE_DEMO_MODE=true`, refreshes use local demo providers and therefore do not create browser Network/XHR calls. Set `VITE_DEMO_MODE=false` and `VITE_API_BASE_URL` to verify real backend calls.

## v0.23 environment-aware service catalog

Service mappings now live under `src/main/resources/service-catalog/{local|qa|uat|prod}/` and are selected by the active Spring profile. Set `SPRING_PROFILES_ACTIVE=qa` to load the QA catalog. See `docs/SERVICE_CATALOG_GUIDE.md`.

## v0.24 final connector change
All fabricated operational data has been removed from `InvestigationService` and `MonitoringDashboardService`. Live analysis now comes only from configured connectors/MCP adapters. See `docs/FINAL_CONNECTOR_ARCHITECTURE.md`.
