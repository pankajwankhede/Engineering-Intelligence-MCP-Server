package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.config.PlatformProperties;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
public class ConnectorHttpClient {
    private final PlatformProperties properties;
    private final RestClient.Builder restClientBuilder;

    public ConnectorHttpClient(PlatformProperties properties, RestClient.Builder restClientBuilder) {
        this.properties = properties;
        this.restClientBuilder = restClientBuilder;
    }

    public <T> T post(String connectorKey, String operation, Object body, Class<T> responseType) {
        PlatformProperties.Connector connector = connector(connectorKey);
        String path = operationPath(connectorKey, connector, operation);
        try {
            RestClient.RequestBodySpec request = restClientBuilder
                    .baseUrl(required(connector.baseUrl(), "Missing base-url for connector " + connectorKey))
                    .build()
                    .post()
                    .uri(path)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON);
            if (connector.token() != null && !connector.token().isBlank()) {
                request.header(HttpHeaders.AUTHORIZATION, "Bearer " + connector.token());
            }
            T response = request.body(body).retrieve().body(responseType);
            if (response == null) throw new ConnectorException("Empty response from " + connectorKey + " operation " + operation);
            return response;
        } catch (ConnectorException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ConnectorException("Connector call failed: " + connectorKey + "/" + operation, ex);
        }
    }

    public boolean isEnabled(String connectorKey) {
        PlatformProperties.Connector connector = properties.connectors() == null ? null : properties.connectors().get(connectorKey);
        return connector != null && connector.enabled();
    }

    private PlatformProperties.Connector connector(String key) {
        PlatformProperties.Connector connector = properties.connectors() == null ? null : properties.connectors().get(key);
        if (connector == null) throw new ConnectorException("Connector is not configured: " + key);
        if (!connector.enabled()) throw new ConnectorException("Connector is disabled: " + key);
        return connector;
    }

    private String operationPath(String key, PlatformProperties.Connector connector, String operation) {
        if (connector.paths() == null || connector.paths().get(operation) == null || connector.paths().get(operation).isBlank()) {
            throw new ConnectorException("Missing connector path: eipa.connectors." + key + ".paths." + operation);
        }
        return connector.paths().get(operation);
    }

    private static String required(String value, String message) {
        if (value == null || value.isBlank()) throw new ConnectorException(message);
        return value;
    }
}
