package com.company.engineering.intelligence.servicecatalog;

import com.company.engineering.intelligence.config.ServiceCatalogProperties;
import org.springframework.beans.factory.config.YamlMapFactoryBean;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class ServiceCatalogService {
    private final ServiceCatalogProperties properties;
    private final Map<String, ServiceCatalogEntry> entries;

    public ServiceCatalogService(ServiceCatalogProperties properties) {
        this.properties = properties;
        this.entries = Collections.unmodifiableMap(loadCatalog(properties.location()));
    }

    public String environment() {
        return properties.environment();
    }

    public boolean allowDiscoveredServices() {
        return properties.allowDiscoveredServices();
    }

    public List<ServiceCatalogEntry> list() {
        return entries.values().stream()
                .sorted(Comparator.comparing(ServiceCatalogEntry::id))
                .toList();
    }

    public Optional<ServiceCatalogEntry> find(String serviceId) {
        return Optional.ofNullable(entries.get(serviceId));
    }

    public boolean isConfigured(String serviceId) {
        return entries.containsKey(serviceId);
    }

    private Map<String, ServiceCatalogEntry> loadCatalog(String location) {
        if (location == null || location.isBlank()) {
            throw new IllegalStateException("eipa.service-catalog.location must be configured");
        }
        try {
            Resource[] resources = new PathMatchingResourcePatternResolver().getResources(location);
            Map<String, ServiceCatalogEntry> result = new LinkedHashMap<>();
            for (Resource resource : resources) {
                ServiceCatalogEntry entry = parse(resource);
                if (entry.id() == null || entry.id().isBlank()) {
                    throw new IllegalStateException("Missing service.id in " + resource.getDescription());
                }
                if (result.put(entry.id(), entry) != null) {
                    throw new IllegalStateException("Duplicate service catalog id: " + entry.id());
                }
            }
            return result;
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to load service catalog from " + location, ex);
        }
    }

    @SuppressWarnings("unchecked")
    private ServiceCatalogEntry parse(Resource resource) {
        YamlMapFactoryBean yaml = new YamlMapFactoryBean();
        yaml.setResources(resource);
        Map<String, Object> root = yaml.getObject();
        Map<String, Object> service = map(root, "service");

        Map<String, Object> splunk = map(service, "splunk");
        Map<String, Object> nr = map(service, "new-relic");
        Map<String, Object> pcf = map(service, "pcf");
        Map<String, Object> repo = map(service, "repository");

        List<ServiceCatalogEntry.Database> databases = new ArrayList<>();
        Object dbValue = service.get("databases");
        if (dbValue instanceof List<?> list) {
            for (Object item : list) {
                if (item instanceof Map<?, ?> raw) {
                    Map<String, Object> db = (Map<String, Object>) raw;
                    databases.add(new ServiceCatalogEntry.Database(
                            text(db, "id"), text(db, "type"), text(db, "connection-ref")));
                }
            }
        }

        List<String> dependencies = new ArrayList<>();
        Object depValue = service.get("dependencies");
        if (depValue instanceof List<?> list) {
            for (Object item : list) dependencies.add(String.valueOf(item));
        }

        return new ServiceCatalogEntry(
                text(service, "id"),
                text(service, "display-name"),
                text(service, "environment"),
                new ServiceCatalogEntry.Splunk(text(splunk, "index"), text(splunk, "sourcetype"), text(splunk, "service-field"), text(splunk, "trace-field"), text(splunk, "tracking-field"), text(splunk, "request-field")),
                new ServiceCatalogEntry.NewRelic(text(nr, "application-name"), text(nr, "entity-guid")),
                new ServiceCatalogEntry.Pcf(text(pcf, "org"), text(pcf, "space"), text(pcf, "app-name")),
                new ServiceCatalogEntry.Repository(text(repo, "provider"), text(repo, "project"), text(repo, "repository"), text(repo, "default-branch")),
                List.copyOf(databases),
                List.copyOf(dependencies)
        );
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Map<String, Object> source, String key) {
        if (source == null) return Map.of();
        Object value = source.get(key);
        return value instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of();
    }

    private static String text(Map<String, Object> source, String key) {
        if (source == null) return null;
        Object value = source.get(key);
        return value == null ? null : String.valueOf(value);
    }
}
