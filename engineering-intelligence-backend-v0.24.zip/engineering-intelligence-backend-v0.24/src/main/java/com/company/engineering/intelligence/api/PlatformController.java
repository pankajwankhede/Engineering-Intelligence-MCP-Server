package com.company.engineering.intelligence.api;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.*;
import com.company.engineering.intelligence.service.*;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class PlatformController {
    private final PlatformProperties properties;
    private final ConnectorRegistry registry;
    private final InvestigationService investigations;
    private final LlmGateway llmGateway;
    private final MonitoringDashboardService dashboards;

    public PlatformController(PlatformProperties properties, ConnectorRegistry registry, InvestigationService investigations,
                              LlmGateway llmGateway, MonitoringDashboardService dashboards) {
        this.properties = properties;
        this.registry = registry;
        this.investigations = investigations;
        this.llmGateway = llmGateway;
        this.dashboards = dashboards;
    }

    @GetMapping("/status")
    public PlatformStatus status() {
        return new PlatformStatus("HEALTHY", properties.demo().enabled() ? "DEMO" : "LIVE",
                registry.status("splunk"), registry.status("bitbucket"), registry.status("newrelic"),
                registry.status("pcf"), registry.status("oracle"), registry.status("sqlserver"),
                registry.status("llm"));
    }

    @GetMapping("/integrations") public List<IntegrationItem> integrations() { return registry.integrations(); }
    @PostMapping("/ai/interpret") public Interpretation interpret(@RequestBody Map<String,String> body) { return llmGateway.interpret(body.getOrDefault("query", "")); }
    @PostMapping("/investigations") public InvestigationResult start(@Valid @RequestBody InvestigationRequest request) { return investigations.start(request); }
    @GetMapping("/investigations/{id}") public InvestigationResult get(@PathVariable String id) { return investigations.get(id); }

    @GetMapping("/investigations/{id}/services")
    public List<AffectedService> services(@PathVariable String id,
            @RequestParam(defaultValue="ALL") String service,
            @RequestParam String environment,
            @RequestParam String timeRange) {
        return investigations.services(service, environment, timeRange);
    }

    @GetMapping("/investigations/{id}/monitoring")
    public MonitoringAnalysis monitoring(@PathVariable String id,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.monitoring(service, environment, timeRange);
    }
    @GetMapping("/investigations/{id}/runtime")
    public RuntimeAnalysis runtime(@PathVariable String id,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.runtime(service, environment, timeRange);
    }
    @GetMapping("/investigations/{id}/splunk")
    public SplunkAnalysis splunk(@PathVariable String id,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.splunk(service, environment, timeRange);
    }
    @GetMapping("/investigations/{id}/new-relic")
    public NewRelicAnalysis newRelic(@PathVariable String id,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.newRelic(service, environment, timeRange);
    }
    @GetMapping("/investigations/{id}/jvm")
    public JvmAnalysis jvm(@PathVariable String id,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.jvm(service, environment, timeRange);
    }
    @GetMapping("/investigations/{id}/pcf")
    public PcfAnalysis pcf(@PathVariable String id,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.pcf(service, environment, timeRange);
    }
    @GetMapping("/investigations/{id}/database")
    public DatabaseAnalysis database(@PathVariable String id,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange,@RequestParam(defaultValue="ORACLE") String databaseType) {
        return investigations.database(service, environment, timeRange, databaseType);
    }
    @GetMapping("/investigations/{id}/code")
    public CodeAnalysis code(@PathVariable String id,@RequestParam String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.code(service, environment, timeRange);
    }

    // Pre-investigation / Apply Filters endpoints.
    @GetMapping("/operational/services")
    public List<AffectedService> operationalServices(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange) {
        return investigations.services(service, environment, timeRange);
    }
    @GetMapping("/operational/monitoring") public MonitoringAnalysis operationalMonitoring(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return investigations.monitoring(service,environment,timeRange);}
    @GetMapping("/operational/runtime") public RuntimeAnalysis operationalRuntime(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return investigations.runtime(service,environment,timeRange);}
    @GetMapping("/operational/splunk") public SplunkAnalysis operationalSplunk(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return investigations.splunk(service,environment,timeRange);}
    @GetMapping("/operational/new-relic") public NewRelicAnalysis operationalNewRelic(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return investigations.newRelic(service,environment,timeRange);}
    @GetMapping("/operational/jvm") public JvmAnalysis operationalJvm(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return investigations.jvm(service,environment,timeRange);}
    @GetMapping("/operational/pcf") public PcfAnalysis operationalPcf(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return investigations.pcf(service,environment,timeRange);}
    @GetMapping("/operational/database") public DatabaseAnalysis operationalDatabase(@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange,@RequestParam(defaultValue="ORACLE") String databaseType){return investigations.database(service,environment,timeRange,databaseType);}
    @GetMapping("/operational/code") public CodeAnalysis operationalCode(@RequestParam String service,@RequestParam String environment,@RequestParam String timeRange){return investigations.code(service,environment,timeRange);}

    @GetMapping("/monitoring/dashboards") public List<MonitoringDashboardSummary> dashboards(){return dashboards.dashboards();}
    @GetMapping("/monitoring/dashboards/{dashboardId}") public MonitoringDashboardDefinition dashboard(@PathVariable String dashboardId){return dashboards.dashboard(dashboardId);}
    @GetMapping("/monitoring/dashboards/{dashboardId}/panels/{panelId}")
    public ConfiguredPanelResult panel(@PathVariable String dashboardId,@PathVariable String panelId,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return dashboards.panel(dashboardId,panelId,service,environment,timeRange,false);}
    @GetMapping("/monitoring/dashboards/{dashboardId}/panels/{panelId}/failures")
    public ConfiguredPanelResult panelFailures(@PathVariable String dashboardId,@PathVariable String panelId,@RequestParam(defaultValue="ALL") String service,@RequestParam String environment,@RequestParam String timeRange){return dashboards.panel(dashboardId,panelId,service,environment,timeRange,true);}
}
