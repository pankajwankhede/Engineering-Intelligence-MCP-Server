package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class MonitoringDashboardService {
    private final PlatformProperties properties;
    private final ConnectorHttpClient connectors;

    public MonitoringDashboardService(PlatformProperties properties, ConnectorHttpClient connectors) {
        this.properties = properties;
        this.connectors = connectors;
    }

    public List<MonitoringDashboardSummary> dashboards() {
        if (properties.monitoring() == null || properties.monitoring().dashboards() == null) return List.of();
        return properties.monitoring().dashboards().entrySet().stream()
                .map(e -> new MonitoringDashboardSummary(e.getKey(), e.getValue().title(), e.getValue().description(), safePanels(e.getValue()).size()))
                .toList();
    }

    public MonitoringDashboardDefinition dashboard(String id) {
        PlatformProperties.Dashboard d = dashboardConfig(id);
        return new MonitoringDashboardDefinition(id, d.title(), d.description(), safePanels(d).stream()
                .map(p -> new DashboardPanelDefinition(p.id(), p.title(), p.queryRef(), defaulted(p.visualization(), "table"))).toList());
    }

    public ConfiguredPanelResult panel(String dashboardId, String panelId, String service, String environment, String timeRange, boolean failuresOnly) {
        PlatformProperties.Dashboard dashboard = dashboardConfig(dashboardId);
        PlatformProperties.Panel panel = safePanels(dashboard).stream().filter(x -> x.id().equals(panelId)).findFirst()
                .orElseThrow(() -> new ConnectorException("Unknown panel: " + panelId));
        String spl = resolveSpl(panel.queryRef());
        String resolvedService = defaulted(service, "ALL");
        String resolvedEnvironment = required(environment, "environment");
        String resolvedTimeRange = required(timeRange, "timeRange");
        String executableSpl = spl
                .replace("$service$", "ALL".equalsIgnoreCase(resolvedService) ? "*" : resolvedService)
                .replace("$environment$", resolvedEnvironment);

        SplunkPanelSearchRequest request = new SplunkPanelSearchRequest(
                dashboardId, panelId, resolvedService, resolvedEnvironment, resolvedTimeRange, executableSpl, failuresOnly);
        SplunkPanelSearchResponse result = connectors.post("splunk", "panel-search", request, SplunkPanelSearchResponse.class);

        return new ConfiguredPanelResult(
                dashboardId,
                panelId,
                panel.title(),
                panel.queryRef(),
                defaulted(panel.visualization(), "table"),
                resolvedService,
                resolvedEnvironment,
                resolvedTimeRange,
                result.metrics() == null ? List.of() : result.metrics(),
                result.trend() == null ? List.of() : result.trend(),
                result.rows() == null ? List.of() : result.rows(),
                executableSpl);
    }

    private PlatformProperties.Dashboard dashboardConfig(String id) {
        if (properties.monitoring() == null || properties.monitoring().dashboards() == null || !properties.monitoring().dashboards().containsKey(id))
            throw new ConnectorException("Unknown dashboard: " + id);
        return properties.monitoring().dashboards().get(id);
    }

    private List<PlatformProperties.Panel> safePanels(PlatformProperties.Dashboard d) {
        return d.panels() == null ? List.of() : d.panels();
    }

    private String resolveSpl(String ref) {
        if (properties.splunk() != null && properties.splunk().queries() != null && properties.splunk().queries().get(ref) != null)
            return properties.splunk().queries().get(ref).spl();
        throw new ConnectorException("Unknown Splunk query-ref: " + ref);
    }

    private static String defaulted(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String required(String value, String name) {
        if (value == null || value.isBlank()) throw new ConnectorException(name + " is required");
        return value;
    }
}
