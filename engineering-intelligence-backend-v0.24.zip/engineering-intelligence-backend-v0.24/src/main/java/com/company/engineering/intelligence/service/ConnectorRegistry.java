package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.IntegrationItem;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ConnectorRegistry {
    private final PlatformProperties properties;
    public ConnectorRegistry(PlatformProperties properties) { this.properties = properties; }

    public String status(String key) {
                var c = properties.connectors().get(key);
        return c != null && c.enabled() ? "CONNECTED" : "DISABLED";
    }

    public List<IntegrationItem> integrations() {
        List<IntegrationItem> list = new ArrayList<>();
        list.add(item("splunk", "Splunk", "Observability", "Logs, traces and errors"));
        list.add(item("newrelic", "New Relic", "Observability", "APM metrics and transactions"));
        list.add(item("pcf", "PCF / Tanzu", "Runtime", "Apps, health, events and deployments"));
        list.add(item("bitbucket", "Bitbucket", "Source Control", "Code, commits and pull requests"));
        list.add(item("oracle", "Oracle MCP", "Database", "Read-only diagnostic queries"));
        list.add(item("sqlserver", "SQL Server MCP", "Database", "Read-only diagnostic queries"));
        list.add(item("postgresql", "PostgreSQL MCP", "Database", "Read-only diagnostic queries"));
        list.add(item("jdbc", "JDBC / ORM Analyzer", "Database", "JDBC query + ORM metadata diagnostics"));
        list.add(item("mcp", "MCP Orchestrator", "AI / Orchestration", "Investigation orchestration and evidence synthesis"));
        list.add(item("llm", "LLM Gateway", "AI", "Natural language intent interpretation"));
        list.add(item("jvm", "JVM Metrics Connector", "Observability", "JVM memory, GC and thread metrics"));
        return list;
    }

    private IntegrationItem item(String key, String name, String category, String details) {
        var c = properties.connectors().get(key);
        return new IntegrationItem(key, name, category, status(key), c == null ? "" : safe(c.baseUrl()), details);
    }
    private String safe(String value) { return value == null ? "" : value; }
}
