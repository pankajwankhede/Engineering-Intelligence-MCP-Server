package com.company.engineering.intelligence.servicecatalog;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/service-catalog")
public class ServiceCatalogController {
    private final ServiceCatalogService catalog;

    public ServiceCatalogController(ServiceCatalogService catalog) {
        this.catalog = catalog;
    }

    @GetMapping
    public Map<String, Object> summary() {
        return Map.of(
                "environment", catalog.environment(),
                "allowDiscoveredServices", catalog.allowDiscoveredServices(),
                "services", catalog.list()
        );
    }

    @GetMapping("/services")
    public List<ServiceCatalogEntry> services() {
        return catalog.list();
    }

    @GetMapping("/services/{serviceId}")
    public ResponseEntity<ServiceCatalogEntry> service(@PathVariable String serviceId) {
        return catalog.find(serviceId)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
