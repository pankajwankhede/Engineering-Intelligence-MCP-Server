package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.Interpretation;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class LlmGateway {
    private static final Pattern SERVICE = Pattern.compile("(?:in|service)\\s+([a-zA-Z0-9_-]+(?:-service)?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXCEPTION = Pattern.compile("([A-Za-z0-9_]+Exception)", Pattern.CASE_INSENSITIVE);
    private final PlatformProperties properties;
    private final ConnectorHttpClient connectors;

    public LlmGateway(PlatformProperties properties, ConnectorHttpClient connectors) {
        this.properties = properties;
        this.connectors = connectors;
    }

    public Interpretation interpret(String query) {
        if (properties.llm() != null && properties.llm().enabled() && connectors.isEnabled("llm")) {
            return connectors.post("llm", "interpret", new Prompt(query), Interpretation.class);
        }
        String service = find(SERVICE, query);
        String exception = find(EXCEPTION, query);
        String intent = exception == null ? "Investigate Service" : "Investigate Exception";
        return new Interpretation(intent, service, exception, 0);
    }

    private static String find(Pattern pattern, String value) {
        Matcher matcher = pattern.matcher(value == null ? "" : value);
        return matcher.find() ? matcher.group(1) : null;
    }

    private record Prompt(String query) {}
}
