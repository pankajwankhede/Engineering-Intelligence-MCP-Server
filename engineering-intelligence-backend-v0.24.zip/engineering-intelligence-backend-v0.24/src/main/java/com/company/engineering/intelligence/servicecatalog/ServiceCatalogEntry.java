package com.company.engineering.intelligence.servicecatalog;

import java.util.List;

public record ServiceCatalogEntry(
        String id,
        String displayName,
        String environment,
        Splunk splunk,
        NewRelic newRelic,
        Pcf pcf,
        Repository repository,
        List<Database> databases,
        List<String> dependencies
) {
    public record Splunk(String index, String sourcetype, String serviceField, String traceField, String trackingField, String requestField) {}
    public record NewRelic(String applicationName, String entityGuid) {}
    public record Pcf(String org, String space, String appName) {}
    public record Repository(String provider, String project, String repository, String defaultBranch) {}
    public record Database(String id, String type, String connectionRef) {}
}
