package com.company.engineering.intelligence.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "eipa.service-catalog")
public record ServiceCatalogProperties(
        String environment,
        String location,
        boolean allowDiscoveredServices
) {}
