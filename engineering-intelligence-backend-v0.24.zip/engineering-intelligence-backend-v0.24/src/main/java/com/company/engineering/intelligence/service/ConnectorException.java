package com.company.engineering.intelligence.service;

public class ConnectorException extends RuntimeException {
    public ConnectorException(String message) { super(message); }
    public ConnectorException(String message, Throwable cause) { super(message, cause); }
}
