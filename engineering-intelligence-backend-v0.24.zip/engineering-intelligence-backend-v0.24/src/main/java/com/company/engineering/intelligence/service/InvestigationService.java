package com.company.engineering.intelligence.service;

import com.company.engineering.intelligence.config.PlatformProperties;
import com.company.engineering.intelligence.model.Models.*;
import com.company.engineering.intelligence.servicecatalog.ServiceCatalogEntry;
import com.company.engineering.intelligence.servicecatalog.ServiceCatalogService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class InvestigationService {
    private final ConnectorHttpClient connectors;
    private final ServiceCatalogService catalog;
    private final PlatformProperties properties;
    private final Map<String, InvestigationResult> investigations = new ConcurrentHashMap<>();

    public InvestigationService(ConnectorHttpClient connectors, ServiceCatalogService catalog, PlatformProperties properties) {
        this.connectors = connectors;
        this.catalog = catalog;
        this.properties = properties;
    }

    /**
     * Final/live investigation path. The MCP/orchestrator owns evidence collection and RCA synthesis.
     * No service names, metrics, incidents, file names, indexes or error values are fabricated in Java.
     */
    public InvestigationResult start(InvestigationRequest request) {
        InvestigationResult result = connectors.post("mcp", "investigate", request, InvestigationResult.class);
        investigations.put(result.investigationId(), result);
        return result;
    }

    public InvestigationResult get(String investigationId) {
        InvestigationResult result = investigations.get(investigationId);
        if (result == null) throw new ConnectorException("Investigation not found in this instance: " + investigationId);
        return result;
    }

    public List<AffectedService> services(String service, String environment, String timeRange) {
        AffectedService[] response = connectors.post("mcp", "affected-services", context(service, environment, timeRange), AffectedService[].class);
        return List.of(response);
    }

    public MonitoringAnalysis monitoring(String service, String environment, String timeRange) {
        return connectors.post("mcp", "monitoring", context(service, environment, timeRange), MonitoringAnalysis.class);
    }

    public RuntimeAnalysis runtime(String service, String environment, String timeRange) {
        return connectors.post("pcf", "runtime", context(service, environment, timeRange), RuntimeAnalysis.class);
    }

    public SplunkAnalysis splunk(String service, String environment, String timeRange) {
        return connectors.post("splunk", "analysis", context(service, environment, timeRange), SplunkAnalysis.class);
    }

    public NewRelicAnalysis newRelic(String service, String environment, String timeRange) {
        return connectors.post("newrelic", "apm", context(service, environment, timeRange), NewRelicAnalysis.class);
    }

    public JvmAnalysis jvm(String service, String environment, String timeRange) {
        String connector = connectors.isEnabled("jvm") ? "jvm" : "newrelic";
        return connectors.post(connector, "jvm", context(service, environment, timeRange), JvmAnalysis.class);
    }

    public PcfAnalysis pcf(String service, String environment, String timeRange) {
        return connectors.post("pcf", "app", context(service, environment, timeRange), PcfAnalysis.class);
    }

    public DatabaseAnalysis database(String service, String environment, String timeRange, String databaseType) {
        String normalized = normalizeDatabaseType(databaseType);
        String connectorKey = switch (normalized) {
            case "SQL_SERVER" -> "sqlserver";
            case "POSTGRESQL" -> "postgresql";
            default -> "oracle";
        };
        String targetKey = switch (normalized) {
            case "SQL_SERVER" -> "sql-server";
            case "POSTGRESQL" -> "postgresql";
            default -> "oracle";
        };
        PlatformProperties.DatabaseTarget target = properties.databaseTargets() == null ? null : properties.databaseTargets().get(targetKey);
        if (target == null) throw new ConnectorException("Database target is not configured: " + targetKey);
        DatabaseRequest request = new DatabaseRequest(service, environment, timeRange, normalized, target.connectionRef());
        return connectors.post(connectorKey, "analysis", request, DatabaseAnalysis.class);
    }

    public CodeAnalysis code(String service, String environment, String timeRange) {
        ServiceCatalogEntry entry = requireConfiguredService(service);
        String repository = entry.repository() == null ? null : entry.repository().repository();
        String branch = entry.repository() == null ? null : entry.repository().defaultBranch();
        return connectors.post("bitbucket", "code-analysis", new CodeRequest(service, environment, timeRange, repository, branch), CodeAnalysis.class);
    }

    private ServiceCatalogEntry requireConfiguredService(String service) {
        if (service == null || service.isBlank() || "ALL".equalsIgnoreCase(service)) {
            throw new ConnectorException("A specific service is required for this operation");
        }
        return catalog.find(service).orElseThrow(() -> new ConnectorException("Service is not configured in service catalog: " + service));
    }

    private ConnectorContext context(String service, String environment, String timeRange) {
        return new ConnectorContext(defaulted(service, "ALL"), required(environment, "environment"), required(timeRange, "timeRange"));
    }

    private String normalizeDatabaseType(String value) {
        String type = defaulted(value, "ORACLE").trim().toUpperCase(Locale.ROOT).replace('-', '_');
        if ("SQLSERVER".equals(type)) type = "SQL_SERVER";
        if (!List.of("ORACLE", "SQL_SERVER", "POSTGRESQL").contains(type)) {
            throw new ConnectorException("Unsupported databaseType: " + value);
        }
        return type;
    }

    private static String defaulted(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String required(String value, String name) {
        if (value == null || value.isBlank()) throw new ConnectorException(name + " is required");
        return value;
    }
}
