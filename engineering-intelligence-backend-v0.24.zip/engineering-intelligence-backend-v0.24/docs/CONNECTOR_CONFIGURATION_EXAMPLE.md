# Connector Configuration Example

Example environment variables for live mode:

```text
EIPA_DEMO_ENABLED=false
EIPA_MCP_ENABLED=true
EIPA_MCP_BASE_URL=https://engineering-mcp.apps.company.com
EIPA_SPLUNK_ENABLED=true
EIPA_SPLUNK_BASE_URL=https://splunk-adapter.apps.company.com
EIPA_NEW_RELIC_ENABLED=true
EIPA_NEW_RELIC_BASE_URL=https://newrelic-adapter.apps.company.com
EIPA_PCF_ENABLED=true
EIPA_PCF_BASE_URL=https://pcf-adapter.apps.company.com
EIPA_BITBUCKET_ENABLED=true
EIPA_BITBUCKET_BASE_URL=https://bitbucket-adapter.apps.company.com
EIPA_ORACLE_ENABLED=true
EIPA_ORACLE_MCP_BASE_URL=https://oracle-mcp.apps.company.com
```

Operation paths are also configurable. This allows your existing MCP/adapters to use different URLs without changing Java source.
