# Environment-aware Service Catalog

The backend loads service metadata from `src/main/resources/service-catalog/<environment>/`.

## Folder layout

```text
src/main/resources/
├── application.yml
├── application-local.yml
├── application-qa.yml
├── application-uat.yml
├── application-prod.yml
└── service-catalog/
    ├── local/
    ├── qa/
    ├── uat/
    └── prod/
```

Each service has its own YAML file. Example: `service-catalog/qa/bc-login-service.yml`.

## Activate QA

Environment variable:

```text
SPRING_PROFILES_ACTIVE=qa
```

Command line:

```bash
java -jar engineering-intelligence-backend-0.23.0.jar --spring.profiles.active=qa
```

IntelliJ Program arguments:

```text
--spring.profiles.active=qa
```

PCF:

```bash
cf set-env engineering-intelligence-backend SPRING_PROFILES_ACTIVE qa
cf restage engineering-intelligence-backend
```

Spring loads `application.yml` plus `application-qa.yml`. The QA profile points the catalog loader to:

```text
classpath*:service-catalog/qa/*.yml
```

## Discovery behavior

A service does not need to exist in the catalog to be discovered from Splunk/trace correlation. The catalog provides deeper mappings for known services (Splunk, New Relic, PCF, repository and databases). `allow-discovered-services: true` keeps discovery open for services found through trace/tracking/request IDs.

## Endpoints

- `GET /api/v1/service-catalog`
- `GET /api/v1/service-catalog/services`
- `GET /api/v1/service-catalog/services/{serviceId}`
