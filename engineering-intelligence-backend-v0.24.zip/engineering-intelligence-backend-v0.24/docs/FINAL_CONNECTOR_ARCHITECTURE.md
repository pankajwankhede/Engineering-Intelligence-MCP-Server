# Final Connector Architecture (v0.24)

## Goal
The backend no longer fabricates service names, incident metrics, Splunk events, New Relic values, JVM values, PCF values, code findings, database findings, or RCA results in Java.

## Runtime flow
Controller -> InvestigationService / MonitoringDashboardService -> ConnectorHttpClient -> configured connector/MCP adapter -> real platform.

## Connector contracts
All connector URLs and operation paths are externalized under `eipa.connectors.*`.

Required live operations:
- `mcp.investigate` -> `InvestigationResult`
- `mcp.affected-services` -> `AffectedService[]`
- `mcp.monitoring` -> `MonitoringAnalysis`
- `splunk.analysis` -> `SplunkAnalysis`
- `splunk.panel-search` -> `SplunkPanelSearchResponse`
- `newrelic.apm` -> `NewRelicAnalysis`
- `newrelic.jvm` or `jvm.jvm` -> `JvmAnalysis`
- `pcf.runtime` -> `RuntimeAnalysis`
- `pcf.app` -> `PcfAnalysis`
- `bitbucket.code-analysis` -> `CodeAnalysis`
- `oracle/sqlserver/postgresql.analysis` -> `DatabaseAnalysis`
- `llm.interpret` -> `Interpretation`

## Service catalog
Repository name, PCF application, New Relic application/entity, Splunk fields/indexes and database mappings belong in the environment-specific service catalog YAML, not Java.

## Discovered services
Splunk/MCP may return services that are not in the service catalog. They can appear in impact/service-flow results. Operations that require explicit platform mapping (for example repository-specific code analysis) return a clear error until the service is added to the catalog.

## Demo mode
The React frontend can continue using its own demo data. The final backend defaults to `EIPA_DEMO_ENABLED=false` and does not contain fabricated incident data.
