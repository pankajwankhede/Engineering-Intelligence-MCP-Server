# Apply Filters backend contract (v0.21)

No new backend endpoint is required for the v0.21 Apply Filters UI fix. The frontend now calls the existing page-specific APIs only after the user clicks Apply Filters.

For Existing Splunk Dashboard, a click executes the dashboard definition endpoint followed by the configured panel endpoints with the selected service, environment and time range.

The backend must continue to treat these filter values as request parameters and must not assume that a dropdown change itself causes a request.
