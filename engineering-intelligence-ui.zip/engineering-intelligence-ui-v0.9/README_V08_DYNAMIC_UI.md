# v0.8 — Fully Backend-Driven UI

This version removes domain/service-specific demo values from the React source.

## Rules

- No service names, repository names, class names, method names, API paths, consumers, commit IDs, tracking IDs, or incident examples are hardcoded in the UI.
- Investigation pages render only from `InvestigationResult` and supporting backend APIs.
- Code Analysis loads the repository tree and selected file dynamically from `/api/code/services/{service}/...`.
- Recent Changes loads service-specific last-10 commits and pull requests dynamically from `/api/changes/services/{service}`.
- Logs & Trace loads correlated events dynamically from `/api/logs/search` and uses issue-related services from the current investigation.
- Monitoring dashboards/panels/metrics are loaded only from `/api/monitoring/...`.
- There is no frontend demo fallback. If the backend is unavailable, the UI shows a connection/error state rather than fabricated production data.
- The last real investigation response is cached in `sessionStorage` only for page refresh/navigation continuity.

## Start

```bash
npm install
npm run dev
```

Vite proxies `/api` to the backend configured in `vite.config.ts`.
