# v0.9 - No hardcoded business data in React UI

The React application is fully response-driven.

It does not contain hardcoded service names, repository names, class names, method names, endpoints,
consumers, teams, commits, PRs, exceptions, or investigation results.

Every investigation page renders the current `InvestigationResult` and/or dynamic backend endpoints:

- Overview: investigation response
- Service Flow: `serviceFlow`
- Logs & Trace: `/api/logs/search`
- Code Analysis: `/api/code/services/{service}/files` and `/file`
- Call Flow: backend-discovered `callers`
- API & Consumers: backend-discovered endpoints/consumers
- Recent Changes: `/api/changes/services/{service}?limit=10`
- Blast Radius: calculated from backend response
- Timeline: correlated log endpoint
- Recommendations: backend response
- Monitoring: backend monitoring dashboard definitions + live Splunk results

If the backend or connectors are unavailable, the UI shows an error/empty state. It does not invent sample business data.
