# v0.9 Log normalization UI

The Logs & Trace page now renders the canonical event returned by EIPA. It shows the detected log format, parser confidence, code location, trace ID and error code when available. No service-specific values are hardcoded in the UI. Raw Splunk evidence remains visible.
