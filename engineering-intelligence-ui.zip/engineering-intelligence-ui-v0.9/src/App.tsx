import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { InvestigationProvider } from './state';
import { OverviewPage } from './pages/OverviewPage';
import { InvestigatePage } from './pages/InvestigatePage';
import { ProgressPage } from './pages/ProgressPage';
import { LogsPage } from './pages/LogsPage';
import { ServiceFlowPage } from './pages/ServiceFlowPage';
import { CodePage } from './pages/CodePage';
import { CallFlowPage } from './pages/CallFlowPage';
import { ConsumersPage } from './pages/ConsumersPage';
import { ChangesPage } from './pages/ChangesPage';
import { BlastPage } from './pages/BlastPage';
import { TimelinePage } from './pages/TimelinePage';
import { RecommendationsPage } from './pages/RecommendationsPage';
import { ReportsPage, SettingsPage, SimilarPage } from './pages/PlaceholderPages';
import { MonitoringPage } from './pages/monitoring/MonitoringPage';

export default function App(){return <InvestigationProvider><BrowserRouter><Routes><Route element={<Layout/>}><Route path="/" element={<MonitoringPage/>}/><Route path="/monitoring" element={<MonitoringPage/>}/><Route path="/overview" element={<OverviewPage/>}/><Route path="/investigate" element={<InvestigatePage/>}/><Route path="/progress" element={<ProgressPage/>}/><Route path="/service-flow" element={<ServiceFlowPage/>}/><Route path="/logs" element={<LogsPage/>}/><Route path="/code" element={<CodePage/>}/><Route path="/call-flow" element={<CallFlowPage/>}/><Route path="/consumers" element={<ConsumersPage/>}/><Route path="/changes" element={<ChangesPage/>}/><Route path="/blast-radius" element={<BlastPage/>}/><Route path="/timeline" element={<TimelinePage/>}/><Route path="/recommendations" element={<RecommendationsPage/>}/><Route path="/similar" element={<SimilarPage/>}/><Route path="/reports" element={<ReportsPage/>}/><Route path="/settings" element={<SettingsPage/>}/></Route></Routes></BrowserRouter></InvestigationProvider>}
