import { useEffect, useMemo, useState } from 'react';
import { Card, Badge } from '../components/Ui';
import { InvestigationGate } from '../components/InvestigationGate';
import { searchRelatedLogs } from '../services/api';
import type { InvestigationResult, LogEventItem } from '../types';

function DynamicLogsPage({ result }: { result: InvestigationResult }) {
  const relatedServices = useMemo(() => result.serviceFlow.map(x => x.service).filter(Boolean), [result]);
  const [service, setService] = useState('ALL');
  const [level, setLevel] = useState('ALL');
  const [timeRange, setTimeRange] = useState(result.timeRange || '');
  const [query, setQuery] = useState('');
  const [events, setEvents] = useState<LogEventItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!relatedServices.length) return;
    const timer = window.setTimeout(() => {
      setLoading(true); setError('');
      searchRelatedLogs({ services: relatedServices, service, level, query, timeRange, trackingId: result.trackingId, requestId: result.requestId })
        .then(data => setEvents(data.events || []))
        .catch(e => { setEvents([]); setError(e instanceof Error ? e.message : 'Unable to search logs'); })
        .finally(() => setLoading(false));
    }, 300);
    return () => window.clearTimeout(timer);
  }, [relatedServices, service, level, query, timeRange, result.trackingId, result.requestId]);

  return <div className="page"><div className="page-heading"><div><h1>Logs & Trace</h1><p>Correlated events returned for the services discovered in this investigation.</p></div></div>
    <div className="log-context"><span>Services: <b>{relatedServices.join(' → ') || '—'}</b></span><span>Tracking ID: <b>{result.trackingId || '—'}</b></span><span>Request ID: <b>{result.requestId || '—'}</b></span><span>Root Cause Service: <b>{result.rootCause.service || '—'}</b></span></div>
    <Card><div className="filterbar"><select value={service} onChange={e => setService(e.target.value)}><option value="ALL">All issue-related services</option>{relatedServices.map(s => <option key={s} value={s}>{s}</option>)}</select><select value={level} onChange={e => setLevel(e.target.value)}><option value="ALL">All levels</option><option value="ERROR">ERROR</option><option value="WARN">WARN</option><option value="INFO">INFO</option><option value="DEBUG">DEBUG</option></select><input value={timeRange} onChange={e => setTimeRange(e.target.value)} placeholder="Time range, e.g. 30m or 2h"/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search exception, class, method, endpoint, status code, message text, request/tracking ID, or service name" /></div>
      <div className="search-help">The search is sent to the backend with the current investigation IDs and related-service scope. Results update automatically.</div>{error && <div className="error-banner">{error}</div>}
      <div className="table-wrap"><table><thead><tr><th>Time</th><th>Service</th><th>Level</th><th>Message</th><th>Normalized Context</th><th>Evidence / Raw Event</th></tr></thead><tbody>{events.map((r, i) => <tr key={`${r.time}-${r.service}-${i}`}><td>{r.time}</td><td><b>{r.service}</b>{r.service === result.rootCause.service && <div><Badge tone="red">ROOT CAUSE SERVICE</Badge></div>}</td><td><Badge tone={r.level === 'ERROR' ? 'red' : r.level === 'WARN' ? 'orange' : 'blue'}>{r.level}</Badge></td><td>{r.message}</td><td><div className="log-normalized"><span>{r.format || 'UNKNOWN'}</span>{typeof r.parseConfidence === 'number' && <span>Parse {Math.round(r.parseConfidence * 100)}%</span>}{r.className && <span>{r.className}{r.methodName ? `.${r.methodName}()` : ''}{r.lineNumber ? `:${r.lineNumber}` : ''}</span>}{r.traceId && <span>Trace: {r.traceId}</span>}{r.errorCode && <span>Error: {r.errorCode}</span>}</div></td><td className="mono log-raw">{r.raw}</td></tr>)}</tbody></table>{loading && <div className="loading-strip">Searching correlated events…</div>}{!loading && events.length === 0 && <div className="empty">No matching events returned for the current filters.</div>}</div>
    </Card>
  </div>;
}
export function LogsPage(){return <InvestigationGate>{result => <DynamicLogsPage result={result}/>}</InvestigationGate>}
