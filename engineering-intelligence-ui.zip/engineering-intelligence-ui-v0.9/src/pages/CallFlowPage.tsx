import { Badge, Card } from '../components/Ui';
import { InvestigationGate } from '../components/InvestigationGate';

export function CallFlowPage() {
  return <InvestigationGate>{result => {
    const nodes = result.serviceFlow.flatMap(step => (step.callers || []).map(caller => ({
      service: step.service,
      caller,
      role: step.issueFound ? 'ROOT_CAUSE_PATH' : step.status === 'IMPACTED' ? 'RELATED' : 'CALLER'
    })));
    const rootMethod = [result.rootCause.className, result.rootCause.methodName].filter(Boolean).join('.');
    if (rootMethod && !nodes.some(n => n.caller.includes(rootMethod))) nodes.push({ service: result.rootCause.service || '', caller: rootMethod, role: 'ROOT_CAUSE' });
    return <div className="page"><div className="page-heading"><div><h1>Call Flow</h1><p>Method/class relationships returned by the code analysis and aligned to the runtime service flow.</p></div></div>
      <Card>{nodes.length ? <div className="horizontal-call">{nodes.map((n,i)=><div className="call-node-wrap" key={`${n.service}-${n.caller}-${i}`}><div className={`call-node ${n.role.startsWith('ROOT_CAUSE')?'danger':''}`}><b>{n.caller}</b><span>{n.service}</span><Badge tone={n.role.startsWith('ROOT_CAUSE')?'red':'blue'}>{n.role}</Badge></div>{i<nodes.length-1&&<div className="call-edge">→</div>}</div>)}</div> : <div className="empty">No call-flow data returned by the backend.</div>}</Card>
      <div className="two-col"><Card title="Methods by Service">{result.serviceFlow.map(step => <div key={step.service} className="caller-group"><div className="row-line"><b>{step.service}</b><span>{step.callers?.length || 0} discovered call references</span></div>{(step.callers || []).map((c,i)=><div className="row-line nested" key={`${c}-${i}`}><span>{c}</span><Badge tone={step.issueFound?'red':'blue'}>{step.issueFound?'ROOT PATH':'RELATED'}</Badge></div>)}</div>)}</Card><Card title="Root Cause Component"><div className="row-line"><b>Service</b><span>{result.rootCause.service || 'Not confirmed'}</span></div><div className="row-line"><b>Class</b><span>{result.rootCause.className || '—'}</span></div><div className="row-line"><b>Method</b><span>{result.rootCause.methodName || '—'}</span></div><div className="row-line"><b>Repository</b><span>{result.rootCause.repository || '—'}</span></div></Card></div>
    </div>;
  }}</InvestigationGate>;
}
