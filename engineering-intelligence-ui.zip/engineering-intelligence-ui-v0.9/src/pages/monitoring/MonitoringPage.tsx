import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Badge, Card } from '../../components/Ui';
import { getMonitoringDashboardDefinition, getMonitoringDashboards, getMonitoringPanel, investigateMonitoringMetric } from '../../services/api';
import { useInvestigation } from '../../state';
import type { MonitoringDashboardDefinition, MonitoringDashboardSummary, MonitoringPanel, MonitoringRow } from '../../types';

function tone(severity: string): 'red' | 'orange' | 'green' | 'blue' | 'purple' {
  const value = (severity || '').toUpperCase();
  if (value === 'CRITICAL') return 'red';
  if (value === 'HIGH' || value === 'WARNING') return 'orange';
  if (value === 'INFO') return 'blue';
  return 'green';
}

export function MonitoringPage() {
  const [environment, setEnvironment] = useState('');
  const [timeRange, setTimeRange] = useState('');
  const [dashboards, setDashboards] = useState<MonitoringDashboardSummary[]>([]);
  const [dashboardId, setDashboardId] = useState('');
  const [dashboard, setDashboard] = useState<MonitoringDashboardDefinition | null>(null);
  const [selectedPanel, setSelectedPanel] = useState<MonitoringPanel | null>(null);
  const [panelId, setPanelId] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<{panel: MonitoringPanel; row: MonitoringRow} | null>(null);
  const [investigating, setInvestigating] = useState(false);
  const { setResult } = useInvestigation();
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true); setError('');
    getMonitoringDashboards().then(items => {
      setDashboards(items);
      setDashboardId(items[0]?.dashboardId || '');
    }).catch(e => setError(e instanceof Error ? e.message : 'Unable to load monitoring dashboards')).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!dashboardId) { setDashboard(null); setPanelId(''); setSelectedPanel(null); return; }
    setLoading(true); setError('');
    getMonitoringDashboardDefinition(dashboardId).then(next => {
      setDashboard(next);
      setPanelId(next.panels?.[0]?.panelId || '');
    }).catch(e => setError(e instanceof Error ? e.message : 'Unable to load dashboard definition')).finally(() => setLoading(false));
  }, [dashboardId]);

  useEffect(() => {
    if (!dashboardId || !panelId) { setSelectedPanel(null); return; }
    setLoading(true); setError('');
    getMonitoringPanel(dashboardId, panelId, environment, timeRange).then(setSelectedPanel).catch(e => setError(e instanceof Error ? e.message : 'Unable to load monitoring panel')).finally(() => setLoading(false));
  }, [dashboardId, panelId, environment, timeRange]);

  const summary = useMemo(() => {
    const rows = selectedPanel?.rows || [];
    const failures = rows.filter(r => r.action === 'INVESTIGATE' && r.count > 0);
    return { panels: dashboard?.panels.length || 0, metrics: rows.length, actionable: failures.length, totalFailures: failures.reduce((a,r)=>a+r.count,0) };
  }, [dashboard, selectedPanel]);

  const investigate = async () => {
    if (!dashboard || !selected) return;
    setInvestigating(true); setError('');
    try {
      const result = await investigateMonitoringMetric({ dashboardId: dashboard.dashboardId, panelId: selected.panel.panelId, row: selected.row, environment, timeRange });
      setResult(result); setSelected(null); navigate('/overview');
    } catch (e) { setError(e instanceof Error ? e.message : 'Unable to start investigation'); }
    finally { setInvestigating(false); }
  };

  return <div className="page monitoring-page"><div className="page-heading"><div><h1>Monitoring <span className="breadcrumb">{dashboard?.title ? `/ ${dashboard.title}` : ''}</span></h1><p>Dashboards, panels, metric labels and counts are supplied entirely by the backend configuration and Splunk result.</p></div><button disabled={!panelId} onClick={() => { const current=panelId; setPanelId(''); window.setTimeout(()=>setPanelId(current),0); }}>↻ Refresh</button></div>
    <Card className="monitor-filter-card"><div className="monitor-selector-grid"><label className="field"><span>Dashboard</span><select value={dashboardId} onChange={e=>setDashboardId(e.target.value)} disabled={!dashboards.length}><option value="">Select dashboard</option>{dashboards.map(item=><option key={item.dashboardId} value={item.dashboardId}>{item.title}</option>)}</select></label><label className="field"><span>Panel</span><select value={panelId} onChange={e=>setPanelId(e.target.value)} disabled={!dashboard?.panels?.length}><option value="">Select panel</option>{dashboard?.panels?.map(panel=><option key={panel.panelId} value={panel.panelId}>{panel.title}</option>)}</select></label><label className="field"><span>Environment</span><input value={environment} onChange={e=>setEnvironment(e.target.value)} placeholder="Optional backend filter"/></label><label className="field"><span>Time Range</span><input value={timeRange} onChange={e=>setTimeRange(e.target.value)} placeholder="Optional bounded range"/></label></div></Card>
    {error&&<div className="error-banner">{error}</div>}
    <div className="metrics-grid four monitoring-summary"><Card><div className="metric-label">Available Panels</div><div className="metric-value">{summary.panels}</div></Card><Card><div className="metric-label">Panel Metrics</div><div className="metric-value">{summary.metrics}</div></Card><Card className="tone-red"><div className="metric-label">Actionable Metrics</div><div className="metric-value">{summary.actionable}</div></Card><Card className="tone-orange"><div className="metric-label">Actionable Events</div><div className="metric-value">{summary.totalFailures}</div></Card></div>
    {loading?<Card><div className="empty">Loading monitoring data…</div></Card>:selectedPanel?<Card title={selectedPanel.title} className="monitor-panel selected-monitor-panel"><div className="panel-description">{selectedPanel.description}</div><div className="query-ref">Query ref: <code>{selectedPanel.queryReference}</code></div><table className="monitor-table"><thead><tr><th>#</th><th>Metric</th><th>Count</th><th>Action</th></tr></thead><tbody>{selectedPanel.rows.map((row,idx)=><tr key={`${row.label}-${idx}`} className={row.action==='INVESTIGATE'&&row.count>0?'clickable-failure':''} onClick={()=>row.count>0&&setSelected({panel:selectedPanel,row})}><td>{idx+1}</td><td>{row.label}</td><td><b>{row.count}</b></td><td><Badge tone={tone(row.severity)}>{row.action}</Badge></td></tr>)}</tbody></table></Card>:<Card><div className="empty">Select a backend-configured dashboard and panel.</div></Card>}
    {selected&&<div className="investigation-overlay" onClick={()=>!investigating&&setSelected(null)}><aside className="investigation-drawer" onClick={e=>e.stopPropagation()}><button className="drawer-close" onClick={()=>setSelected(null)}>×</button><div className="drawer-kicker">Investigation Mode</div><h2>{selected.row.label}</h2><Badge tone={tone(selected.row.severity)}>{selected.row.severity}</Badge><dl className="drawer-details"><dt>Count</dt><dd>{selected.row.count}</dd><dt>Dashboard</dt><dd>{dashboard?.title||dashboardId}</dd><dt>Panel</dt><dd>{selected.panel.title}</dd><dt>Environment</dt><dd>{environment||'Backend default'}</dd><dt>Time Range</dt><dd>{timeRange||'Backend default'}</dd><dt>Category</dt><dd>{selected.row.investigationCategory||'General'}</dd></dl>{selected.row.action==='INVESTIGATE'?<button className="primary-button drawer-action" onClick={investigate} disabled={investigating}>{investigating?'Investigating…':'Investigate with EIPA →'}</button>:<button className="primary-button drawer-action" onClick={()=>{setSelected(null);navigate('/logs')}}>Open Drilldown →</button>}</aside></div>}
  </div>;
}
