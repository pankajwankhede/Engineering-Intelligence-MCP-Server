import { useEffect, useMemo, useState } from 'react';
import { Badge, Card, Metric } from '../components/Ui';
import { InvestigationGate } from '../components/InvestigationGate';
import { getServiceChangeHistory } from '../services/api';
import type { InvestigationResult, RecentChange, ServiceChangeHistory } from '../types';

function DynamicChangesPage({ result }: { result: InvestigationResult }) {
  const rootService = result.rootCause.service || result.serviceFlow.find(x => x.issueFound)?.service || result.entryService || result.serviceFlow[0]?.service || '';
  const [service, setService] = useState(rootService);
  const [history, setHistory] = useState<ServiceChangeHistory | null>(null);
  const [commitId, setCommitId] = useState('');
  const [prId, setPrId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!service) return;
    let active = true;
    setLoading(true); setError(''); setHistory(null); setCommitId(''); setPrId('');
    getServiceChangeHistory(service, 10).then(data => {
      if (!active) return;
      setHistory(data);
      setCommitId(data.commits?.[0]?.commit || '');
    }).catch(e => active && setError(e instanceof Error ? e.message : 'Unable to load change history')).finally(() => active && setLoading(false));
    return () => { active = false; };
  }, [service]);

  const selectedCommit = useMemo<RecentChange | undefined>(() => history?.commits.find(c => c.commit === commitId) || history?.commits[0], [history, commitId]);
  const selectedPr = useMemo(() => history?.pullRequests.find(pr => pr.id === prId), [history, prId]);

  return <div className="page"><div className="page-heading"><div><h1>Recent Changes</h1><p>Select any service from the current incident, then inspect the last commits, pull requests and changed resources returned by the backend repository connector.</p></div></div>
    <Card><div className="change-selectors"><label><span>Service involved in issue</span><select value={service} onChange={e => setService(e.target.value)}>{result.serviceFlow.map(s => <option key={s.service} value={s.service}>{s.service}{s.team ? ` · ${s.team}` : ''}</option>)}</select></label><label><span>Last 10 commits</span><select value={commitId} onChange={e => setCommitId(e.target.value)} disabled={!history?.commits?.length}>{history?.commits?.length ? history.commits.map(c => <option key={c.commit} value={c.commit}>{c.commit} · {c.message}</option>) : <option value="">No commits returned</option>}</select></label><label><span>Pull Request</span><select value={prId} onChange={e => setPrId(e.target.value)} disabled={!history?.pullRequests?.length}><option value="">Select PR (optional)</option>{history?.pullRequests?.map(pr => <option key={pr.id} value={pr.id}>{pr.id} · {pr.title}</option>)}</select></label></div></Card>
    <div className="service-change-banner"><b>{history?.service || service || '—'}</b><span>{history?.team || 'Owner not returned'}</span><span>{history?.repository || 'Repository not returned'}</span><span>{loading ? 'Refreshing…' : `${history?.commits?.length || 0} commits loaded`}</span></div>
    {error && <div className="error-banner">{error}</div>}
    {selectedPr && <Card title="Selected Pull Request"><div className="pr-grid"><div><b>{selectedPr.id}</b><h3>{selectedPr.title}</h3></div><div><span>Author</span><b>{selectedPr.author}</b></div><div><span>Branches</span><b>{selectedPr.sourceBranch} → {selectedPr.destinationBranch}</b></div><div><span>Status</span><Badge tone={selectedPr.state === 'MERGED' ? 'green' : 'orange'}>{selectedPr.state}</Badge></div></div></Card>}
    {!selectedCommit ? <Card><div className="empty">{loading ? 'Loading change history…' : 'No commit data returned for the selected service.'}</div></Card> : <><div className="metrics-grid four"><Metric label="Selected Commit" value={selectedCommit.commit} detail={selectedCommit.author}/><Metric label="Resources Changed" value={selectedCommit.totalResources} tone="blue"/><Metric label="Incident Related" value={selectedCommit.incidentRelatedResources} tone="red"/><Metric label="Correlation" value={selectedCommit.correlation} detail={`Risk: ${selectedCommit.risk}`} tone="orange"/></div><div className="two-col"><Card title="Resource Types">{Object.keys(selectedCommit.resourceTypeCounts || {}).length ? <div className="resource-types">{Object.entries(selectedCommit.resourceTypeCounts).map(([k,v])=><div key={k}><span>{k.replaceAll('_',' ')}</span><b>{v}</b></div>)}</div> : <div className="empty">No resource-type summary returned.</div>}</Card><Card title="Commit Context"><h2>{selectedCommit.message}</h2><p><b>Service:</b> {service}</p><p><b>Repository:</b> {history?.repository || '—'}</p><p><b>Author:</b> {selectedCommit.author}</p><p><b>Timestamp:</b> {selectedCommit.timestamp ? new Date(selectedCommit.timestamp).toLocaleString() : '—'}</p><Badge tone={selectedCommit.correlation === 'HIGH' ? 'red' : selectedCommit.correlation === 'MEDIUM' ? 'orange' : 'blue'}>{selectedCommit.correlation} CORRELATION</Badge></Card></div><Card title={`Resources Involved (${selectedCommit.totalResources})`}><div className="table-wrap"><table><thead><tr><th>Resource</th><th>Type</th><th>Relevance</th><th>Incident Related</th><th>Diff</th></tr></thead><tbody>{selectedCommit.resources?.map(r=><tr key={r.path} className={r.incidentRelated?'highlight-row':''}><td className="mono">{r.path}</td><td><Badge>{r.type}</Badge></td><td><Badge tone={r.relevance==='HIGH'?'red':r.relevance==='MEDIUM'?'orange':'blue'}>{r.relevance}</Badge></td><td>{r.incidentRelated?'✓ Yes':'No'}</td><td><span className="plus">+{r.additions}</span> <span className="minus">-{r.deletions}</span></td></tr>)}</tbody></table></div></Card></>}
  </div>;
}
export function ChangesPage(){return <InvestigationGate>{result => <DynamicChangesPage result={result}/>}</InvestigationGate>}
