import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '../components/Ui';
import { startInvestigation } from '../services/api';
import { useInvestigation } from '../state';
import type { InvestigationRequest } from '../types';

const fields = [
  ['trackingId', 'Tracking ID', 'Enter tracking/correlation identifier'],
  ['requestId', 'Request ID', 'Enter request identifier'],
  ['traceId', 'Trace ID', 'Enter distributed trace identifier'],
  ['service', 'Service', 'Enter service name if known'],
  ['apiUrl', 'API URL', 'Enter endpoint path or URL'],
  ['errorOrException', 'Error / Exception', 'Enter exception, error code, or message text']
] as const;

export function InvestigatePage() {
  const [mode, setMode] = useState<(typeof fields)[number][0] | 'description'>('trackingId');
  const [form, setForm] = useState<InvestigationRequest>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { setResult } = useInvestigation();
  const navigate = useNavigate();

  const update = (key: keyof InvestigationRequest, value: string) => setForm(prev => ({ ...prev, [key]: value }));
  const submit = async () => {
    setLoading(true); setError(''); navigate('/progress');
    try {
      const result = await startInvestigation(form);
      setResult(result);
      navigate('/overview');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to start investigation');
      navigate('/investigate');
    } finally { setLoading(false); }
  };

  return <div className="page narrow-page">
    <div className="page-heading"><div><h1>Start a New Investigation</h1><p>Provide any identifier or symptom you know. The backend discovers the relevant services, logs and repositories.</p></div></div>
    <Card>
      <div className="tabs">{fields.map(([key, label]) => <button key={key} className={mode === key ? 'tab active' : 'tab'} onClick={() => setMode(key)}>{label}</button>)}<button className={mode === 'description' ? 'tab active' : 'tab'} onClick={() => setMode('description')}>Natural Language</button></div>
      <div className="form-grid">
        {mode === 'description' ? <label className="field span-2"><span>Describe the problem</span><textarea value={form.description || ''} onChange={e => update('description', e.target.value)} placeholder="Describe the production symptom, approximate time, affected action, or error message." /></label> : (() => {
          const field = fields.find(f => f[0] === mode)!;
          return <label className="field span-2"><span>{field[1]}</span><input value={(form as Record<string,string | undefined>)[field[0]] || ''} onChange={e => update(field[0], e.target.value)} placeholder={field[2]} /></label>;
        })()}
        <label className="field"><span>Environment</span><input value={form.environment || ''} onChange={e => update('environment', e.target.value)} placeholder="Environment, for example production or QA" /></label>
        <label className="field"><span>Time Range</span><input value={form.timeRange || ''} onChange={e => update('timeRange', e.target.value)} placeholder="Bounded range, for example 30m, 2h, 1d" /></label>
      </div>
      <div className="what-next"><b>What happens next?</b><ol><li>Run bounded searches against configured observability sources.</li><li>Discover entry, related and downstream services.</li><li>Resolve each service to its configured repository.</li><li>Analyze logs, code, callers, APIs, consumers and recent changes.</li><li>Return evidence-backed root cause and impact.</li></ol></div>
      {error && <div className="error-banner">{error}</div>}
      <button className="primary-button" onClick={submit} disabled={loading}>{loading ? 'Starting…' : '▶ Start Investigation'}</button>
    </Card>
  </div>;
}
