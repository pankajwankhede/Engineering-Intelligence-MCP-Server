import { Badge, Card, Metric } from '../components/Ui';
import { InvestigationGate } from '../components/InvestigationGate';

export function ConsumersPage() {
  return <InvestigationGate>{result => {
    const consumerRows = result.serviceFlow.flatMap(s => (s.consumers || []).map(consumer => ({ consumer, provider: s.service, status: s.status })));
    const uniqueConsumers = Array.from(new Map(consumerRows.map(x => [`${x.consumer}|${x.provider}`, x])).values());
    const endpointRows = result.serviceFlow.flatMap(s => (s.apiEndpoints || []).map(endpoint => ({ endpoint, service: s.service, issueFound: s.issueFound })));
    return <div className="page"><div className="page-heading"><div><h1>API & Consumers</h1><p>Consumer and endpoint relationships returned for the current investigation.</p></div></div>
      <div className="metrics-grid four"><Metric label="Affected Endpoints" value={endpointRows.length}/><Metric label="Known Consumer Links" value={uniqueConsumers.length} tone="green"/><Metric label="Services in Flow" value={result.serviceFlow.length} tone="orange"/><Metric label="Impacted Teams" value={result.impactedTeams.length} tone="red"/></div>
      <div className="two-col"><Card title="Consumers">{uniqueConsumers.length ? <table><thead><tr><th>Consumer</th><th>Provider Service</th><th>Provider Status</th></tr></thead><tbody>{uniqueConsumers.map((r,i)=><tr key={`${r.consumer}-${r.provider}-${i}`}><td>{r.consumer}</td><td>{r.provider}</td><td><Badge tone={r.status==='FAILED'?'red':r.status==='IMPACTED'?'orange':'blue'}>{r.status}</Badge></td></tr>)}</tbody></table> : <div className="empty">No consumer data returned.</div>}</Card><Card title="Affected API Endpoints">{endpointRows.length ? endpointRows.map((e,i)=><div className="endpoint" key={`${e.service}-${e.endpoint}-${i}`}><Badge tone={e.issueFound?'red':'blue'}>{e.service}</Badge><b>{e.endpoint}</b></div>) : <div className="empty">No API endpoint data returned.</div>}</Card></div>
    </div>;
  }}</InvestigationGate>;
}
