import { useEffect, useMemo, useState } from 'react';
import { Badge, Card, Progress } from '../components/Ui';
import { InvestigationGate } from '../components/InvestigationGate';
import { getCodeFile, getCodeFiles } from '../services/api';
import type { CodeFileContent, CodeFileInfo, InvestigationResult } from '../types';

function DynamicCodePage({ result }: { result: InvestigationResult }) {
  const defaultStep = result.serviceFlow.find(x => x.issueFound) || result.serviceFlow.find(x => x.status === 'FAILED') || result.serviceFlow[0];
  const [service, setService] = useState(defaultStep?.service || result.entryService || '');
  const [files, setFiles] = useState<CodeFileInfo[]>([]);
  const [selectedPath, setSelectedPath] = useState('');
  const [file, setFile] = useState<CodeFileContent | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const selectedStep = useMemo(() => result.serviceFlow.find(s => s.service === service), [result, service]);

  useEffect(() => {
    if (!service) return;
    let active = true;
    setLoading(true); setError(''); setFiles([]); setFile(null); setSelectedPath('');
    getCodeFiles(service).then(items => {
      if (!active) return;
      setFiles(items);
      const targetName = selectedStep?.failure?.fileName;
      const target = items.find(x => x.displayName === targetName) || items[0];
      if (target) setSelectedPath(target.path);
    }).catch(e => active && setError(e instanceof Error ? e.message : 'Unable to load repository files')).finally(() => active && setLoading(false));
    return () => { active = false; };
  }, [service, selectedStep?.failure?.fileName]);

  useEffect(() => {
    if (!service || !selectedPath) return;
    let active = true;
    setLoading(true); setError('');
    const highlight = selectedStep?.failure?.fileName && selectedPath.endsWith(selectedStep.failure.fileName) ? selectedStep.failure.lineNumber : undefined;
    getCodeFile(service, selectedPath, highlight).then(data => active && setFile(data)).catch(e => active && setError(e instanceof Error ? e.message : 'Unable to load selected file')).finally(() => active && setLoading(false));
    return () => { active = false; };
  }, [service, selectedPath, selectedStep?.failure?.fileName, selectedStep?.failure?.lineNumber]);

  const lines = file?.content?.split('\n') || [];
  return <div className="page"><div className="page-heading"><div><h1>Code Analysis</h1><p>Select any service and repository file returned by the backend. File content is loaded on demand from the mapped source repository.</p></div></div>
    <Card><div className="filterbar"><select value={service} onChange={e => setService(e.target.value)}>{result.serviceFlow.map(s => <option key={s.service} value={s.service}>{s.service} · {s.repository || s.team}</option>)}</select></div></Card>
    <div className="code-context-bar"><span>Service: <b>{service || '—'}</b></span><span>Repository: <b>{file?.repository || selectedStep?.repository || '—'}</b></span><span>Branch: <b>{file?.branch || '—'}</b></span><span>Selected File: <b>{file?.path || selectedPath || '—'}</b></span></div>
    {error && <div className="error-banner">{error}</div>}
    <div className="code-layout"><Card title="File Explorer"><div className="file-list">{files.length ? files.map(item => <button className={`file-item ${item.path === selectedPath ? 'active' : ''}`} key={item.path} onClick={() => setSelectedPath(item.path)}><span className="file-type">{item.type}</span><span>{item.displayName}</span></button>) : <div className="empty">{loading ? 'Loading repository tree…' : 'No files returned.'}</div>}</div></Card>
      <Card title={file ? `Code (${file.path})` : 'Code'}><pre className="code-lines"><code>{lines.map((line, index) => { const n = index + 1; const root = file?.highlightedLine === n; return <span key={n} className={`code-line ${root ? 'root-line' : ''}`}><span className="line-no">{n}</span><span>{line || ' '}</span>{root && <span className="root-tag">ROOT CAUSE LINE</span>}</span>; })}</code></pre>{loading && <div className="loading-strip">Loading source from backend…</div>}</Card>
      <Card title="Analysis"><Badge tone={selectedStep?.componentAnalysis?.issueFound ? 'red' : 'green'}>{selectedStep?.componentAnalysis?.issueFound ? 'ISSUE FOUND' : 'NO CONFIRMED CODE ISSUE'}</Badge><h4>Class Purpose</h4><p>{selectedStep?.componentAnalysis?.classPurpose || 'No class-purpose analysis returned.'}</p><h4>Method Purpose</h4><p>{selectedStep?.componentAnalysis?.methodPurpose || 'No method-purpose analysis returned.'}</p><h4>Finding</h4><p>{selectedStep?.componentAnalysis?.issue || result.rootCause.reason || 'No finding returned.'}</p><h4>Confidence</h4><Progress value={(result.rootCause.confidence || 0) * 100}/><p>{Math.round((result.rootCause.confidence || 0) * 100)}%</p></Card>
    </div>
  </div>;
}

export function CodePage(){return <InvestigationGate>{result => <DynamicCodePage result={result}/>}</InvestigationGate>}
