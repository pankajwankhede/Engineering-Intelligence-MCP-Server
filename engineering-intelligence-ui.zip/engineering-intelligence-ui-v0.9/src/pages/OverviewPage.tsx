import { useNavigate } from 'react-router-dom';
import { Badge, Card, Metric, Progress } from '../components/Ui';
import { InvestigationGate } from '../components/InvestigationGate';

export function OverviewPage() {
  const navigate = useNavigate();
  return <InvestigationGate>{result => {
    const failed = result.serviceFlow.find(s => s.issueFound) || result.serviceFlow.find(s => s.status === 'FAILED');
    const change = result.recentChanges?.[0];
    const uniqueConsumers = new Set(result.serviceFlow.flatMap(s => s.consumers || []));
    const uniqueEndpoints = new Set(result.serviceFlow.flatMap(s => s.apiEndpoints || []));
    const callItems = result.serviceFlow.flatMap(s => (s.callers || []).map(c => ({ service: s.service, caller: c })));
    const rootLabel = [result.rootCause.className, result.rootCause.methodName].filter(Boolean).join('.');
    return <div className="page">
      <div className="page-heading"><div><h1>Investigation: {result.investigationId} <Badge tone={result.status === 'COMPLETED' ? 'green' : result.status === 'FAILED' ? 'red' : 'orange'}>{result.status}</Badge></h1><p>{result.trackingId || result.requestId || result.traceId || result.entryService || 'Investigation context'} · {result.environment || 'Environment not supplied'} · {result.timeRange || 'Time range from backend'}</p></div><div className="actions"><button onClick={() => navigate('/investigate')}>New Investigation</button></div></div>
      <div className="metrics-grid six">
        <Metric label="Entry Point" value={result.entryService || 'Not identified'} detail={result.environment} />
        <Metric label="Root Cause Service" value={result.rootCause.service || 'Not confirmed'} detail={result.rootCause.ownerTeam} tone="red" />
        <Metric label="Root Cause" value={failed?.failure?.exception || 'See analysis'} detail={rootLabel || result.rootCause.reason} tone="orange" />
        <Metric label="Confidence" value={`${Math.round((result.rootCause.confidence || 0) * 100)}%`} detail={<Progress value={(result.rootCause.confidence || 0) * 100} />} tone="green" />
        <Metric label="Services in Flow" value={result.serviceFlow.length} detail={`${result.impactedTeams.length} teams`} tone="purple" />
        <Metric label="Recent Change" value={change ? `${change.totalResources} resources` : 'No correlated change'} detail={change ? `${change.incidentRelatedResources} incident-related` : undefined} tone="orange" />
      </div>
      <div className="overview-grid">
        <Card title="Request / Service Flow"><div className="vertical-flow">{result.serviceFlow.map((s, i) => <div key={`${s.service}-${i}`}><div className={`service-node ${s.issueFound ? 'failed' : s.status === 'IMPACTED' ? 'impacted' : 'healthy'}`}><div><b>{s.service}</b><small>{s.repository || s.team}</small></div><Badge tone={s.issueFound ? 'red' : s.status === 'IMPACTED' ? 'blue' : 'green'}>{s.status}</Badge></div>{i < result.serviceFlow.length - 1 && <div className="flow-arrow">↓</div>}</div>)}</div></Card>
        <Card title="Root Cause Summary" className="wide-card"><div className="root-summary"><div>{result.rootCause.service && <Badge tone="red">ROOT CAUSE SERVICE</Badge>}<h2>{result.rootCause.service || 'Root cause not confirmed'}</h2><dl><dt>Exception</dt><dd>{failed?.failure?.exception || '—'}</dd><dt>Class</dt><dd>{result.rootCause.className || '—'}</dd><dt>Method</dt><dd>{result.rootCause.methodName || '—'}</dd><dt>File / Line</dt><dd>{failed?.failure?.fileName || '—'}{result.rootCause.lineNumber ? `:${result.rootCause.lineNumber}` : ''}</dd><dt>Repository</dt><dd>{result.rootCause.repository || failed?.repository || '—'}</dd></dl></div><div className="root-reason"><b>Evidence-backed finding</b><p>{result.rootCause.reason || 'No root-cause explanation returned by the backend.'}</p><button onClick={() => navigate('/code')}>Open Code Analysis</button></div></div></Card>
        <Card title="Impact Overview"><div className="impact-number">{result.serviceFlow.length}<span>services in flow</span></div><div className="mini-grid"><div><b>{uniqueConsumers.size}</b><span>Known Consumers</span></div><div><b>{uniqueEndpoints.size}</b><span>Affected Endpoints</span></div></div></Card>
      </div>
      <div className="bottom-grid">
        <Card title="Call Flow">{callItems.length ? <div className="call-list">{callItems.slice(0, 8).map((x, i) => <div key={`${x.service}-${x.caller}-${i}`}>● <b>{x.caller}</b> <span>{x.service}</span></div>)}</div> : <div className="empty">No method call data returned.</div>}</Card>
        <Card title="Recent Change">{change ? <><h3>{change.commit}</h3><p>{change.message}</p><div className="mini-grid"><div><b>{change.totalResources}</b><span>Resources Changed</span></div><div><b>{change.incidentRelatedResources}</b><span>Incident Related</span></div></div><Badge tone={change.correlation === 'HIGH' ? 'red' : change.correlation === 'MEDIUM' ? 'orange' : 'blue'}>{change.correlation} CORRELATION</Badge></> : <div className="empty">No recent change correlation returned.</div>}</Card>
        <Card title="Recommendations">{result.recommendations?.length ? <ol className="recommend-list">{result.recommendations.slice(0, 5).map((x, i) => <li key={`${i}-${x}`}>{x}</li>)}</ol> : <div className="empty">No recommendations returned.</div>}</Card>
      </div>
    </div>;
  }}</InvestigationGate>;
}
