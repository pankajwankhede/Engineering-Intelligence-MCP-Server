import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { InvestigationResult } from './types';

interface InvestigationContextValue {
  result: InvestigationResult | null;
  setResult: (result: InvestigationResult | null) => void;
}

const STORAGE_KEY = 'engineering-intelligence:last-investigation';
const InvestigationContext = createContext<InvestigationContextValue | undefined>(undefined);

export function InvestigationProvider({ children }: { children: ReactNode }) {
  const [result, setResultState] = useState<InvestigationResult | null>(() => {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) as InvestigationResult : null;
    } catch {
      return null;
    }
  });

  const setResult = (next: InvestigationResult | null) => {
    setResultState(next);
    try {
      if (next) sessionStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      else sessionStorage.removeItem(STORAGE_KEY);
    } catch {
      // Storage is optional; the app still works without it.
    }
  };

  useEffect(() => {
    if (!result) return;
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(result)); } catch { /* no-op */ }
  }, [result]);

  return <InvestigationContext.Provider value={{ result, setResult }}>{children}</InvestigationContext.Provider>;
}

export function useInvestigation() {
  const context = useContext(InvestigationContext);
  if (!context) throw new Error('useInvestigation must be used inside InvestigationProvider');
  return context;
}
