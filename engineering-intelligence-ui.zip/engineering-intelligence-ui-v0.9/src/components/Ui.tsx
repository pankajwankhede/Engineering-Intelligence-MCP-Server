import type { ReactNode } from 'react';

export function Card({ title, children, className = '' }: { title?: string; children: ReactNode; className?: string }) {
  return <section className={`card ${className}`}>{title && <div className="card-title">{title}</div>}{children}</section>;
}

export function Metric({ label, value, detail, tone = 'blue' }: { label: string; value: ReactNode; detail?: ReactNode; tone?: string }) {
  return <Card className={`metric tone-${tone}`}><div className="metric-label">{label}</div><div className="metric-value">{value}</div>{detail && <div className="metric-detail">{detail}</div>}</Card>;
}

export function Badge({ children, tone = 'blue' }: { children: ReactNode; tone?: string }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function Progress({ value }: { value: number }) {
  return <div className="progress"><span style={{ width: `${Math.min(100, Math.max(0, value))}%` }} /></div>;
}

export function Empty({ text }: { text: string }) {
  return <div className="empty">{text}</div>;
}
