import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from './Ui';
import { useInvestigation } from '../state';
import type { InvestigationResult } from '../types';

export function InvestigationGate({ children }: { children: (result: InvestigationResult) => ReactNode }) {
  const { result } = useInvestigation();
  const navigate = useNavigate();
  if (result) return <>{children(result)}</>;
  return <div className="page narrow-page">
    <Card>
      <div className="empty-state-block">
        <h2>No investigation loaded</h2>
        <p>Start an investigation or open one from Monitoring. All page content is populated from the backend response.</p>
        <button className="primary-button" onClick={() => navigate('/investigate')}>Start Investigation</button>
      </div>
    </Card>
  </div>;
}
